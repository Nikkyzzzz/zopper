/**
 * Aetna Student Health chatbot widget.
 *
 * Embed on any page with:
 *   <script src="https://your-backend-host/widget/widget.js"
 *           data-api-url="https://your-backend-host/api/chat"></script>
 *
 * Renders a floating chat bubble in the bottom-right corner that expands
 * into a chat panel talking to the FastAPI backend.
 */
(function () {
  "use strict";

  // Minimal, dependency-free Markdown renderer for assistant replies (the
  // LLM consistently outputs **bold**, "- "/"* " bullets, "1. " numbered
  // lists, and "## " headings). Text is HTML-escaped first, so this can
  // only ever produce the tags this function itself adds.
  function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function renderMarkdown(text) {
    var lines = escapeHtml(text)
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, function (_, label, url) {
        var safeUrl = url.replace(/"/g, "&quot;");
        return '<a href="' + safeUrl + '" target="_blank" rel="noopener noreferrer">' + label + "</a>";
      })
      .split("\n");
    var html = "";
    var inList = false;
    lines.forEach(function (line, i) {
      var heading = line.match(/^#{1,6}\s+(.*)$/);
      var item = line.match(/^\s*(?:[-*]|\d+\.)\s+(.*)$/);
      if (item) {
        if (!inList) {
          html += '<ul style="margin:4px 0;padding-left:18px;">';
          inList = true;
        }
        html += "<li>" + item[1] + "</li>";
      } else {
        if (inList) {
          html += "</ul>";
          inList = false;
        }
        html += heading ? "<strong>" + heading[1] + "</strong>\n" : line + (i < lines.length - 1 ? "\n" : "");
      }
    });
    if (inList) html += "</ul>";
    return html;
  }

  var scriptTag = document.currentScript;
  // Default to an API on the same origin the widget script was loaded from
  // (e.g. the backend serving both /widget/widget.js and /api/chat). Pass
  // data-api-url explicitly when the backend lives on a different host.
  var DEFAULT_API_URL = scriptTag ? new URL("/api/chat", scriptTag.src).href : "/api/chat";
  var API_URL = (scriptTag && scriptTag.getAttribute("data-api-url")) || DEFAULT_API_URL;
  var SCHOOLS_URL = API_URL.replace(/\/api\/chat$/, "/api/schools");
  var EXTRACT_CARD_URL = API_URL.replace(/\/api\/chat$/, "/api/extract-card");

  var CARD_FIELD_LABELS = [
    ["member_name", "Name"],
    ["member_id", "Member ID"],
    ["plan_name", "Plan"],
    ["group_number", "Group #"],
    ["payer_number", "Payer #"],
    ["pcp_election", "PCP"],
    ["issuer_name", "Issuer"],
    ["phone_number", "Phone"],
  ];

  function formatCardMessage(fields) {
    var lines = CARD_FIELD_LABELS.filter(function (pair) {
      return fields[pair[0]];
    }).map(function (pair) {
      return pair[1] + ": " + fields[pair[0]];
    });
    if (lines.length === 0) {
      return "I couldn't read any details from that card image. Try a clearer photo with the whole card in frame.";
    }
    return "Here's what I found on your ID card:\n" + lines.join("\n") + "\n\nDouble-check these against the physical card before using them for anything official.";
  }

  var history = []; // {role, content}

  // greeting | gate | school | visa | queue | done
  var waiverStep = "greeting";
  var waiverAnswers = {};
  var selectedSchool = null;
  var selectedVisa = null;
  var questionQueue = [];
  var queueIndex = 0;
  var schools = [];
  var activeQuickReplyWrap = null;

  fetch(SCHOOLS_URL)
    .then(function (res) {
      return res.json();
    })
    .then(function (data) {
      schools = data;
    })
    .catch(function () {
      schools = [];
    });

  var GENERIC_DEMO_SOURCES = [
    { title: "Frequently asked questions | Aetna Student Health", url: "https://www.aetnastudenthealth.com/en/insurance-basics/faqs.html" },
    { title: "How to Waive University Health Insurance in the US (ISOA)", url: "https://www.isoa.org/blog/how-to-waive-university-health-insurance-in-the-us" },
  ];
  var UT_AUSTIN_SOURCE = {
    title: "UT Austin's actual student health insurance waiver policy (real, school-specific example)",
    url: "https://global.utexas.edu/isss/advising-services/insurance/waivers",
  };

  var GREETING =
    "Hi! I can answer questions about Aetna Student Health plans, benefits, and how to use them. What would you like to know? Or, if you want to check whether you can waive the university's insurance, use the button below.";
  var WAIVER_QUESTION =
    "Do you already have your own health insurance that might qualify for a waiver of the university's plan (for example, coverage through a parent's plan)?";
  var NOT_ELIGIBLE_NO_INSURANCE =
    "Since you don't currently have your own comparable health insurance, you likely wouldn't be eligible to waive the university's plan, so you'd stay covered under it automatically. Waiver requirements are set by your specific school, so if you think this doesn't apply to you, contact your school directly.";

  // --- Question definitions used to build a per-school, per-visa queue ---
  var ASK_DEDUCTIBLE = { key: "deductible", type: "number", content: "What's your plan's deductible amount in USD? Just type the number (e.g. 500)." };
  var ASK_COINSURANCE = { key: "coinsurance", type: "number", content: "What's your plan's coinsurance percentage? Just type the number (e.g. 20 for 20%)." };
  var ASK_COVERAGE = { key: "fullCoverage", type: "yesno", content: "Does your plan cover the full semester or academic year (not just partial dates)?" };
  var ASK_TRAVEL_PLAN = { key: "isTravelPlan", type: "yesno", content: "Is your plan a travel, international-only, or short-term insurance plan, rather than a standard ongoing health plan?" };
  var ASK_MENTAL_HEALTH = { key: "mentalHealth", type: "yesno", content: "Does your plan include mental health coverage?" };
  var ASK_EVACUATION_REPATRIATION = { key: "evacuationRepatriation", type: "yesno", content: "Does your plan include emergency medical evacuation and repatriation coverage?" };
  var ASK_ACA = { key: "acaCompliant", type: "yesno", content: "Is your plan ACA-compliant (meets Affordable Care Act standards)?" };
  var ASK_PREEXISTING = { key: "preExisting", type: "yesno", content: "Does your plan cover pre-existing conditions (no exclusions for them)?" };
  var ASK_UNLIMITED_MAX_BENEFITS = { key: "unlimitedMaxBenefits", type: "yesno", content: "Does your plan have unlimited maximum benefits (no cap on the total amount it will pay out)?" };
  var ASK_OUTPATIENT = { key: "outpatientCovered", type: "yesno", content: "Does your plan cover outpatient care, emergency room visits, and hospitalization?" };
  var ASK_J1_MEDICAL = { key: "meetsJ1Medical", type: "yesno", content: "Federal J-1 requirement: does your plan include at least $100,000 in medical benefits per accident or illness?" };
  var ASK_J1_REPATRIATION = { key: "meetsJ1Repatriation", type: "yesno", content: "Federal J-1 requirement: does your plan include at least $25,000 for repatriation of remains?" };
  var ASK_J1_EVACUATION = { key: "meetsJ1Evacuation", type: "yesno", content: "Federal J-1 requirement: does your plan include at least $50,000 for medical evacuation back to your home country?" };

  function buildQuestionQueue(school, visa) {
    var queue = [ASK_DEDUCTIBLE];
    if (school.max_coinsurance_percent != null) queue.push(ASK_COINSURANCE);
    queue.push(ASK_COVERAGE);
    if (!school.travel_or_short_term_plans_accepted) queue.push(ASK_TRAVEL_PLAN);
    queue.push(ASK_MENTAL_HEALTH);
    if (school.requires_evacuation_repatriation && visa !== "J-1") queue.push(ASK_EVACUATION_REPATRIATION);
    if (school.aca_compliance_required) queue.push(ASK_ACA);
    if (school.requires_unlimited_max_benefits) queue.push(ASK_UNLIMITED_MAX_BENEFITS);
    if (school.requires_no_preexisting_exclusions) queue.push(ASK_PREEXISTING);

    if (visa === "F-1") queue.push(ASK_OUTPATIENT);
    else if (visa === "J-1") queue.push(ASK_J1_MEDICAL, ASK_J1_REPATRIATION, ASK_J1_EVACUATION);

    return queue;
  }

  function schoolSources(school) {
    if (school.source_url) return [{ title: school.name + "'s waiver policy", url: school.source_url }];
    return GENERIC_DEMO_SOURCES;
  }

  function parseYesNo(text) {
    var t = text.trim().toLowerCase();
    if (/^(y|yes|yeah|yep|sure|correct)\b/.test(t)) return true;
    if (/^(n|no|nope|nah)\b/.test(t)) return false;
    return null;
  }

  function parseVisaChoice(text) {
    var t = text.toLowerCase();
    if (/\bj-?1\b/.test(t)) return "J-1";
    if (/\bf-?1\b/.test(t)) return "F-1";
    if (/\bus\b|u\.s\.?|american|domestic/.test(t)) return "US";
    return null;
  }

  function buildJ1NotAllowedText(school) {
    if (school.is_real) {
      return (
        school.name +
        "'s actual published policy states that J-1 exchange students are generally not eligible to waive its student health insurance plan at all, regardless of what other coverage you have. You'd need to contact your school's international student office directly rather than pursue a waiver."
      );
    }
    return (
      "In this demo, " +
      school.name +
      "'s example policy doesn't allow J-1 visa holders to waive its plan at all, regardless of other coverage. (This particular school is invented for the demo, but it reflects something real: actual schools like UT Austin do restrict or disallow J-1 waivers entirely.) You'd need to contact your school's international student office directly."
    );
  }

  function buildResultText(school, visa, answers) {
    var checks = [
      {
        label: "Deductible ($" + answers.deductible + " vs. " + school.name + "'s max of $" + school.max_deductible + ")",
        pass: isFinite(answers.deductible) && answers.deductible <= school.max_deductible,
      },
    ];
    if (school.max_coinsurance_percent != null) {
      checks.push({
        label: "Coinsurance (" + answers.coinsurance + "% vs. max " + school.max_coinsurance_percent + "%)",
        pass: isFinite(answers.coinsurance) && answers.coinsurance <= school.max_coinsurance_percent,
      });
    }
    checks.push({ label: "Covers the full semester/academic year", pass: answers.fullCoverage });
    if (!school.travel_or_short_term_plans_accepted) {
      checks.push({ label: "Is not a travel/short-term/international-only plan", pass: answers.isTravelPlan === false });
    }
    checks.push({ label: "Includes mental health coverage", pass: answers.mentalHealth });
    if (school.requires_evacuation_repatriation && visa !== "J-1") {
      checks.push({ label: "Includes emergency evacuation and repatriation coverage", pass: answers.evacuationRepatriation });
    }
    if (school.aca_compliance_required) {
      checks.push({ label: "ACA-compliant", pass: answers.acaCompliant });
    }
    if (school.requires_unlimited_max_benefits) {
      checks.push({ label: "Has unlimited maximum benefits", pass: answers.unlimitedMaxBenefits });
    }
    if (school.requires_no_preexisting_exclusions) {
      checks.push({ label: "Covers pre-existing conditions (no exclusions)", pass: answers.preExisting });
    }

    if (visa === "F-1") {
      checks.push({ label: "Covers outpatient care, ER visits, and hospitalization", pass: answers.outpatientCovered });
    } else if (visa === "J-1") {
      checks.push({ label: "Meets $100k medical minimum (J-1 federal requirement)", pass: answers.meetsJ1Medical });
      checks.push({ label: "Meets $25k repatriation minimum (J-1 federal requirement)", pass: answers.meetsJ1Repatriation });
      checks.push({ label: "Meets $50k evacuation minimum (J-1 federal requirement)", pass: answers.meetsJ1Evacuation });
    }

    var allPass = checks.every(function (c) {
      return c.pass;
    });
    var lines = checks
      .map(function (c) {
        return (c.pass ? "✅ " : "❌ ") + c.label;
      })
      .join("\n");
    var exampleNote = school.is_real ? "" : " (example criteria)";
    var deadlineNote = school.deadline ? " (" + school.deadline + ")" : "";
    var verdict = allPass
      ? "Based on what you've told me, your plan looks like it would meet " +
        school.name +
        "'s requirements" +
        exampleNote +
        ". Next step: submit your proof documents (insurance ID, policy details, benefits summary) before the deadline" +
        deadlineNote +
        "."
      : "Based on what you've told me, your plan doesn't meet all of " +
        school.name +
        "'s requirements" +
        exampleNote +
        ". See which item(s) above didn't pass. You may want to check with your insurer about upgrading coverage, or contact your school's insurance office directly.";
    return lines + "\n\n" + verdict;
  }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      if (key === "style") {
        Object.assign(node.style, attrs[key]);
      } else if (key.indexOf("on") === 0) {
        node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
      } else {
        node.setAttribute(key, attrs[key]);
      }
    });
    (children || []).forEach(function (child) {
      node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
    });
    return node;
  }

  var launcher = el(
    "button",
    {
      "aria-label": "Open chat assistant",
      style: {
        position: "fixed",
        bottom: "20px",
        right: "20px",
        width: "60px",
        height: "60px",
        borderRadius: "50%",
        border: "none",
        background: "#7d2e8b",
        color: "#fff",
        fontSize: "26px",
        cursor: "pointer",
        boxShadow: "0 4px 14px rgba(0,0,0,0.25)",
        zIndex: 999999,
      },
    },
    ["💬"]
  );

  var messagesEl = el("div", {
    style: {
      flex: "1",
      overflowY: "auto",
      padding: "12px",
      display: "flex",
      flexDirection: "column",
      gap: "8px",
      background: "#f7f5fa",
    },
  });

  var input = el("input", {
    type: "text",
    placeholder: "Ask about your plan, benefits, or coverage...",
    style: {
      flex: "1",
      border: "1px solid #ccc",
      borderRadius: "18px",
      padding: "8px 14px",
      fontSize: "14px",
      outline: "none",
    },
  });

  var sendBtn = el(
    "button",
    {
      style: {
        border: "none",
        background: "#7d2e8b",
        color: "#fff",
        borderRadius: "18px",
        padding: "8px 16px",
        marginLeft: "8px",
        cursor: "pointer",
        fontSize: "14px",
      },
      onClick: function () {
        sendMessage();
      },
    },
    ["Send"]
  );

  var fileInput = el("input", {
    type: "file",
    accept: "image/*",
    style: { display: "none" },
    onChange: function () {
      handleCardUpload();
    },
  });

  var uploadBtn = el(
    "button",
    {
      title: "Upload your insurance ID card",
      "aria-label": "Upload your insurance ID card",
      style: {
        border: "1px solid #ccc",
        background: "#fff",
        color: "#7d2e8b",
        borderRadius: "50%",
        width: "36px",
        height: "36px",
        flex: "none",
        marginRight: "8px",
        cursor: "pointer",
        fontSize: "16px",
      },
      onClick: function () {
        fileInput.click();
      },
    },
    ["📎"]
  );

  var panel = el(
    "div",
    {
      style: {
        position: "fixed",
        bottom: "90px",
        right: "20px",
        width: "420px",
        maxWidth: "92vw",
        height: "620px",
        maxHeight: "85vh",
        background: "#fff",
        borderRadius: "12px",
        boxShadow: "0 8px 30px rgba(0,0,0,0.3)",
        display: "none",
        flexDirection: "column",
        overflow: "hidden",
        zIndex: 999999,
        fontFamily: "Arial, Helvetica, sans-serif",
      },
    },
    [
      el(
        "div",
        {
          style: {
            background: "#7d2e8b",
            color: "#fff",
            padding: "12px 14px",
            fontWeight: "bold",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          },
        },
        [
          "Aetna Student Health Assistant",
          el(
            "button",
            {
              "aria-label": "Close chat",
              style: {
                background: "none",
                border: "none",
                color: "#fff",
                fontSize: "18px",
                cursor: "pointer",
              },
              onClick: function () {
                togglePanel(false);
              },
            },
            ["✕"]
          ),
        ]
      ),
      messagesEl,
      el(
        "div",
        {
          style: {
            display: "flex",
            padding: "10px",
            borderTop: "1px solid #eee",
            background: "#fff",
          },
        },
        [fileInput, uploadBtn, input, sendBtn]
      ),
    ]
  );

  document.body.appendChild(panel);
  document.body.appendChild(launcher);

  function togglePanel(forceOpen) {
    var isOpen = panel.style.display === "flex";
    var next = typeof forceOpen === "boolean" ? forceOpen : !isOpen;
    panel.style.display = next ? "flex" : "none";
    if (next && messagesEl.children.length === 0) {
      addBubble("assistant", GREETING);
      addQuickReplies([{ label: "📋 Check my waiver eligibility", value: "start-waiver" }]);
    }
  }

  function addQuickReplies(options) {
    var wrap = el("div", { style: { display: "flex", gap: "8px", flexWrap: "wrap", alignSelf: "flex-start" } });
    options.forEach(function (opt) {
      var btn = el(
        "button",
        {
          style: {
            border: "1px solid #7d2e8b",
            background: "#fff",
            color: "#7d2e8b",
            borderRadius: "14px",
            padding: "6px 16px",
            fontSize: "13px",
            cursor: "pointer",
          },
          onClick: function () {
            wrap.remove();
            activeQuickReplyWrap = null;
            var handler = STEP_HANDLERS[waiverStep];
            if (handler) handler(opt.value);
          },
        },
        [opt.label]
      );
      wrap.appendChild(btn);
    });
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    activeQuickReplyWrap = wrap;
    return wrap;
  }

  function addSchoolDropdown() {
    var select = el("select", {
      style: {
        flex: "1",
        minWidth: "0",
        border: "1px solid #ccc",
        borderRadius: "8px",
        padding: "6px 8px",
        fontSize: "13px",
      },
    });
    select.appendChild(el("option", { value: "", disabled: "", selected: "" }, ["Choose your school..."]));
    schools.forEach(function (s) {
      select.appendChild(el("option", { value: s.id }, [s.name]));
    });

    var wrap = el("div", { style: { display: "flex", gap: "8px", alignSelf: "flex-start", maxWidth: "100%" } });
    var confirmBtn = el(
      "button",
      {
        style: {
          border: "none",
          background: "#7d2e8b",
          color: "#fff",
          borderRadius: "14px",
          padding: "6px 14px",
          fontSize: "13px",
          cursor: "pointer",
          flex: "none",
        },
        onClick: function () {
          if (!select.value) return;
          wrap.remove();
          handleSchoolAnswer(select.value);
        },
      },
      ["Continue"]
    );

    wrap.appendChild(select);
    wrap.appendChild(confirmBtn);
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return wrap;
  }

  var YES_NO_OPTIONS = [
    { label: "Yes", value: "yes" },
    { label: "No", value: "no" },
  ];

  function say(role, text) {
    addBubble(role, text);
    history.push({ role: role, content: text });
  }

  function currentQuestion() {
    return questionQueue[queueIndex];
  }

  function askCurrentQuestion() {
    var q = currentQuestion();
    say("assistant", q.content);
    if (q.type === "yesno") addQuickReplies(YES_NO_OPTIONS);
    else input.focus();
  }

  function advanceQueueAfterAnswer() {
    if (queueIndex + 1 < questionQueue.length) {
      queueIndex += 1;
      askCurrentQuestion();
    } else {
      finishWithResult();
    }
  }

  function handleStartWaiver() {
    say("user", "Check my waiver eligibility");
    say("assistant", WAIVER_QUESTION);
    addQuickReplies(YES_NO_OPTIONS);
    waiverStep = "gate";
  }

  function handleGateAnswer(value, userLabel) {
    var label = userLabel || (value === "no" ? "No" : "Yes");
    if (value === "no") {
      say("user", label);
      say("assistant", NOT_ELIGIBLE_NO_INSURANCE);
      addSources(GENERIC_DEMO_SOURCES.slice(0, 1));
      waiverStep = "done";
      return;
    }
    say("user", label);
    say("assistant", "Let's check your plan against your specific school's waiver criteria. Which school are you at?");
    addSchoolDropdown();
    waiverStep = "school";
  }

  function handleSchoolAnswer(schoolId) {
    var school = schools.filter(function (s) {
      return s.id === schoolId;
    })[0];
    if (!school) return;
    selectedSchool = school;
    say("user", school.name);
    say("assistant", "Got it, " + school.name + ". Are you a US student, or an international student on an F-1 or J-1 visa?");
    addQuickReplies([
      { label: "US Student", value: "US" },
      { label: "F-1 Visa", value: "F-1" },
      { label: "J-1 Visa", value: "J-1" },
    ]);
    waiverStep = "visa";
  }

  function handleVisaAnswer(value, userLabel) {
    selectedVisa = value;
    say("user", userLabel || (value === "US" ? "US Student" : value + " Visa"));

    if (value === "J-1" && !selectedSchool.j1_waiver_allowed) {
      say("assistant", buildJ1NotAllowedText(selectedSchool));
      addSources(selectedSchool.is_real ? schoolSources(selectedSchool) : [UT_AUSTIN_SOURCE]);
      waiverStep = "done";
      return;
    }

    questionQueue = buildQuestionQueue(selectedSchool, value);
    queueIndex = 0;
    waiverAnswers = {};
    waiverStep = "queue";
    askCurrentQuestion();
  }

  function handleQueueButtonAnswer(value, userLabel) {
    var q = currentQuestion();
    if (!q) return;
    say("user", userLabel || (value === "yes" ? "Yes" : "No"));
    waiverAnswers[q.key] = value === "yes";
    advanceQueueAfterAnswer();
  }

  function finishWithResult() {
    say("assistant", buildResultText(selectedSchool, selectedVisa, waiverAnswers));
    addSources(schoolSources(selectedSchool));
    waiverStep = "done";
  }

  var STEP_HANDLERS = {
    greeting: handleStartWaiver,
    gate: handleGateAnswer,
    school: handleSchoolAnswer,
    visa: handleVisaAnswer,
    queue: handleQueueButtonAnswer,
  };

  launcher.addEventListener("click", function () {
    togglePanel();
  });

  function setBubbleContent(bubble, role, text) {
    if (role === "assistant") {
      bubble.innerHTML = renderMarkdown(text);
    } else {
      bubble.textContent = text;
    }
  }

  function formatTime(date) {
    return date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  }

  function timeCaption(align) {
    return el("div", { style: { fontSize: "15px", color: "#888", marginTop: "2px", padding: "0 4px", alignSelf: align } }, [formatTime(new Date())]);
  }

  function addBubble(role, text) {
    var bubbleStyle = {
      alignSelf: role === "user" ? "flex-end" : "flex-start",
      background: role === "user" ? "#7d2e8b" : "#ffffff",
      color: role === "user" ? "#fff" : "#222",
      border: role === "user" ? "none" : "1px solid #e0dbe5",
      padding: "8px 12px",
      borderRadius: "14px",
      maxWidth: role === "user" ? "92%" : "80%",
      fontSize: "14px",
      lineHeight: "1.4",
      whiteSpace: "pre-wrap",
      overflowWrap: "anywhere",
    };

    if (role === "user") {
      var userBubble = el("div", { style: bubbleStyle });
      userBubble.dataset.role = role;
      setBubbleContent(userBubble, role, text);
      var userCol = el("div", { style: { display: "flex", flexDirection: "column", alignItems: "flex-end" } }, [
        userBubble,
        timeCaption("flex-end"),
      ]);
      messagesEl.appendChild(userCol);
      messagesEl.scrollTop = messagesEl.scrollHeight;
      return userBubble;
    }

    var avatar = el(
      "div",
      {
        style: {
          flex: "none",
          width: "28px",
          height: "28px",
          borderRadius: "50%",
          background: "linear-gradient(135deg, #c77dd1, #7d2e8b)",
          color: "#fff",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "14px",
          marginTop: "2px",
        },
      },
      ["♥"]
    );
    bubbleStyle.maxWidth = "calc(80% - 36px)";
    var bubble = el("div", { style: bubbleStyle });
    bubble.dataset.role = role;
    setBubbleContent(bubble, role, text);
    var assistantCol = el("div", { style: { display: "flex", flexDirection: "column", alignItems: "flex-start" } }, [
      bubble,
      timeCaption("flex-start"),
    ]);
    var row = el(
      "div",
      { style: { display: "flex", gap: "8px", alignItems: "flex-start", alignSelf: "flex-start", maxWidth: "100%" } },
      [avatar, assistantCol]
    );
    messagesEl.appendChild(row);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return bubble;
  }

  function addSources(sources) {
    if (!sources || sources.length === 0) return;
    var links = sources.map(function (s) {
      return el("a", { href: s.url, target: "_blank", rel: "noopener", style: { color: "#7d2e8b", display: "block", fontSize: "12px" } }, [s.title]);
    });
    var wrap = el(
      "div",
      { style: { alignSelf: "flex-start", fontSize: "12px", color: "#666", maxWidth: "80%" } },
      ["Learn more:"].concat(links)
    );
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function addUploadSuggestion() {
    var wrap = el("div", { style: { display: "flex", alignSelf: "flex-start" } });
    var btn = el(
      "button",
      {
        style: {
          border: "1px solid #7d2e8b",
          background: "#fff",
          color: "#7d2e8b",
          borderRadius: "14px",
          padding: "6px 16px",
          fontSize: "13px",
          cursor: "pointer",
        },
        onClick: function () {
          fileInput.click();
        },
      },
      ["📎 Upload your ID card"]
    );
    wrap.appendChild(btn);
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function sendMessage() {
    var text = input.value.trim();
    if (!text) return;
    input.value = "";

    if (waiverStep === "queue" && currentQuestion() && currentQuestion().type === "number") {
      var cleaned = text.replace(/[^0-9.]/g, "");
      var amount = parseFloat(cleaned);
      say("user", text);
      if (!cleaned || !isFinite(amount)) {
        say(
          "assistant",
          "That doesn't look like a number. Please type just the numeric amount (e.g. 500). If you're not sure, check your insurance card or policy documents; you can also upload your card with the 📎 button and I'll try to read it."
        );
        return;
      }
      waiverAnswers[currentQuestion().key] = amount;
      advanceQueueAfterAnswer();
      return;
    }

    if (waiverStep === "gate" || (waiverStep === "queue" && currentQuestion() && currentQuestion().type === "yesno")) {
      var yn = parseYesNo(text);
      if (yn === null) {
        say("user", text);
        say("assistant", 'Sorry, I didn\'t catch that. Please tap Yes or No above, or type "yes" or "no".');
        return;
      }
      if (activeQuickReplyWrap) {
        activeQuickReplyWrap.remove();
        activeQuickReplyWrap = null;
      }
      if (waiverStep === "gate") handleGateAnswer(yn ? "yes" : "no", text);
      else handleQueueButtonAnswer(yn ? "yes" : "no", text);
      return;
    }

    if (waiverStep === "visa") {
      var visa = parseVisaChoice(text);
      if (!visa) {
        say("user", text);
        say("assistant", "Sorry, I didn't catch that. Please choose US Student, F-1 Visa, or J-1 Visa from the buttons above, or type one of those.");
        return;
      }
      if (activeQuickReplyWrap) {
        activeQuickReplyWrap.remove();
        activeQuickReplyWrap = null;
      }
      handleVisaAnswer(visa, text);
      return;
    }

    addBubble("user", text);
    history.push({ role: "user", content: text });

    var typing = addBubble("assistant", "...");

    fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, history: history.slice(0, -1) }),
    })
      .then(function (res) {
        if (!res.ok) {
          return res
            .json()
            .catch(function () {
              return {};
            })
            .then(function (errData) {
              throw new Error(errData && errData.detail ? errData.detail : "Request failed: " + res.status);
            });
        }
        return res.json();
      })
      .then(function (data) {
        setBubbleContent(typing, "assistant", data.reply);
        history.push({ role: "assistant", content: data.reply });
        addSources(data.sources);
        if (data.suggest_card_upload) addUploadSuggestion();
      })
      .catch(function (err) {
        var detail = err && err.message ? err.message : "unknown error";
        setBubbleContent(typing, "assistant", "Sorry, something went wrong: " + detail + ". Please try again or use Contact Us.");
      });
  }

  function handleCardUpload() {
    var file = fileInput.files && fileInput.files[0];
    fileInput.value = ""; // allow re-selecting the same file later
    if (!file) return;

    addBubble("user", "📎 Uploaded: " + file.name);

    var typing = addBubble("assistant", "...");
    var formData = new FormData();
    formData.append("file", file);

    fetch(EXTRACT_CARD_URL, { method: "POST", body: formData })
      .then(function (res) {
        if (!res.ok) {
          return res
            .json()
            .catch(function () {
              return {};
            })
            .then(function (errData) {
              throw new Error(errData && errData.detail ? errData.detail : "Request failed: " + res.status);
            });
        }
        return res.json();
      })
      .then(function (fields) {
        setBubbleContent(typing, "assistant", formatCardMessage(fields));
      })
      .catch(function (err) {
        var detail = err && err.message ? err.message : "unknown error";
        setBubbleContent(typing, "assistant", "Sorry, I couldn't read that card: " + detail);
      });
  }

  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter") sendMessage();
  });
})();
