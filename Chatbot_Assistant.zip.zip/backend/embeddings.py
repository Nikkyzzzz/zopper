"""
Provider-agnostic text embeddings.

Used by backend/build_index.py (to embed every scraped/knowledge-base chunk
once, at index-build time) and backend/retrieval.py (to embed a user's query
into that same vector space on every request) — replacing the earlier
TF-IDF + cosine-similarity retrieval so questions match semantically
similar content even when the wording doesn't share keywords.

The provider used to build an index is recorded inside the index itself
(see build_index.py) so retrieval always re-embeds queries with the same
model the index was built with, regardless of what EMBEDDING_PROVIDER is
later set to in .env.
"""

import time
from functools import lru_cache

from fastapi import HTTPException

from backend.config import (
    GEMINI_API_KEY,
    GEMINI_EMBEDDING_MODEL,
    OPENAI_API_KEY,
    OPENAI_EMBEDDING_MODEL,
)

MAX_API_RETRIES = 3
RETRY_BACKOFF_SECONDS = 2.0
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_BATCH_SIZE = 100  # Gemini's embed_content caps a single request at 100 inputs


@lru_cache
def _gemini_client():
    from google import genai

    if not GEMINI_API_KEY:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY is not set. Add it to your .env file.")
    return genai.Client(api_key=GEMINI_API_KEY)


@lru_cache
def _openai_client():
    from openai import OpenAI

    if not OPENAI_API_KEY:
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY is not set. Add it to your .env file.")
    return OpenAI(api_key=OPENAI_API_KEY)


def _embed_gemini_batch(client, batch: list[str]) -> list[list[float]]:
    from google.genai import errors as genai_errors

    delay = RETRY_BACKOFF_SECONDS
    for attempt in range(MAX_API_RETRIES):
        is_last_attempt = attempt == MAX_API_RETRIES - 1
        try:
            response = client.models.embed_content(model=GEMINI_EMBEDDING_MODEL, contents=batch)
            return [e.values for e in response.embeddings]
        except genai_errors.APIError as exc:
            if exc.code not in _RETRYABLE_STATUS_CODES or is_last_attempt:
                raise HTTPException(status_code=502, detail=f"Gemini embeddings error: {exc}") from exc
        except Exception as exc:  # network failures, etc.
            if is_last_attempt:
                raise HTTPException(status_code=502, detail=f"Gemini embeddings request failed: {exc}") from exc
        time.sleep(delay)
        delay *= 2


def _embed_openai_batch(client, batch: list[str]) -> list[list[float]]:
    import openai

    delay = RETRY_BACKOFF_SECONDS
    for attempt in range(MAX_API_RETRIES):
        is_last_attempt = attempt == MAX_API_RETRIES - 1
        try:
            response = client.embeddings.create(model=OPENAI_EMBEDDING_MODEL, input=batch)
            return [d.embedding for d in response.data]
        except openai.APIStatusError as exc:
            if exc.status_code not in _RETRYABLE_STATUS_CODES or is_last_attempt:
                raise HTTPException(status_code=502, detail=f"OpenAI embeddings error: {exc}") from exc
        except Exception as exc:  # network failures, etc.
            if is_last_attempt:
                raise HTTPException(status_code=502, detail=f"OpenAI embeddings request failed: {exc}") from exc
        time.sleep(delay)
        delay *= 2


def embed_texts(texts: list[str], provider: str) -> list[list[float]]:
    """Embed a list of texts with the given provider, batching as needed."""
    provider = provider.strip().lower()
    if provider == "gemini":
        client = _gemini_client()
        embed_batch = _embed_gemini_batch
    elif provider == "openai":
        client = _openai_client()
        embed_batch = _embed_openai_batch
    else:
        raise HTTPException(status_code=400, detail=f"Unknown embeddings provider '{provider}'.")

    vectors: list[list[float]] = []
    for i in range(0, len(texts), _BATCH_SIZE):
        vectors.extend(embed_batch(client, texts[i : i + _BATCH_SIZE]))
    return vectors
