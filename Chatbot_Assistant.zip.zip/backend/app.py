"""
FastAPI backend for the Aetna Student Health chatbot.

Exposes POST /api/chat, which:
0. Runs a hard-coded safety/escalation check first (backend/safety.py) for
   medical emergencies, crisis/self-harm, and abuse — if triggered, a fixed
   reply is returned immediately and the model is never called.
1. Otherwise retrieves the most relevant chunks of scraped site content for
   the user's message (TF-IDF cosine similarity).
2. Sends those chunks + conversation history to an LLM (Gemini, see
   backend/llm.py) as grounding context. The model also has a
   search_providers tool backed by the real NPI Registry (backend/providers.py).
3. Returns the model's answer plus the source pages it drew on.

Also exposes GET /api/providers/search for direct provider lookups without
a model call.

Run with:
    uvicorn backend.app:app --reload --port 8731
"""

import logging
import threading
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from backend import llm
from backend.card_intent import mentions_card_details
from backend.config import ALLOWED_ORIGINS
from backend.conversation_log import log_exchange
from backend.prompts import SYSTEM_PROMPT
from backend.providers import search_providers
from backend.retrieval import Retriever
from backend.safety import check_safety
from backend.schools import SCHOOLS

logger = logging.getLogger("aetna.chat")

app = FastAPI(title="Aetna Student Health Chatbot API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_methods=["POST", "GET", "OPTIONS"],
    allow_headers=["*"],
)

WIDGET_DIR = Path(__file__).resolve().parent.parent / "widget"
if WIDGET_DIR.exists():
    app.mount("/widget", StaticFiles(directory=WIDGET_DIR), name="widget")

_retriever: Retriever | None = None
_retriever_lock = threading.Lock()


def get_retriever() -> Retriever:
    global _retriever
    if _retriever is None:
        with _retriever_lock:
            if _retriever is None:  # re-check: another request may have built it while we waited
                try:
                    _retriever = Retriever()
                except FileNotFoundError as exc:
                    raise HTTPException(
                        status_code=500,
                        detail="Knowledge base index not found. Run backend/build_index.py first.",
                    ) from exc
    return _retriever


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(..., min_length=1, max_length=4000)


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    history: list[ChatMessage] = Field(default_factory=list, max_length=20)
    provider: Literal["gemini", "openai"] | None = Field(
        default=None,
        description="Override the default LLM provider for this request (gemini or openai).",
    )

    @field_validator("message")
    @classmethod
    def message_not_blank(cls, v: str) -> str:
        stripped = v.strip()
        if not stripped:
            raise ValueError("message must not be blank")
        return stripped


class Source(BaseModel):
    title: str
    url: str


class ChatResponse(BaseModel):
    reply: str
    sources: list[Source]
    escalation: bool = Field(
        default=False,
        description="True when the reply came from the hard-coded safety layer, not the model.",
    )
    suggest_card_upload: bool = Field(
        default=False,
        description="True when the user's message asked about something printed on their own ID card "
        "(member ID, group number, etc.) — the UI should surface the upload-card option.",
    )


class ProviderResult(BaseModel):
    npi: str | None = None
    name: str
    credential: str = ""
    specialty: str = ""
    address: str = ""
    phone: str = ""


class CardDetails(BaseModel):
    member_name: str | None = None
    member_id: str | None = None
    plan_name: str | None = None
    group_number: str | None = None
    payer_number: str | None = None
    pcp_election: str | None = None
    issuer_name: str | None = None
    phone_number: str | None = None


MAX_CARD_IMAGE_BYTES = 8 * 1024 * 1024  # 8MB


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/")
def root():
    return {"status": "ok", "message": "Aetna Student Health Chatbot API. See /api/health and /api/chat."}


@app.get("/api/schools")
def get_schools():
    """Demo dataset of university-specific waiver requirements, used to drive
    the school-selection step in the waiver-eligibility walkthrough. Only
    "ut-austin" is a real, verified policy — see backend/schools.py."""
    return SCHOOLS


@app.get("/api/providers/search", response_model=list[ProviderResult])
def providers_search(
    specialty: str = "",
    city: str = "",
    state: str = "",
    postal_code: str = "",
    last_name: str = "",
    first_name: str = "",
):
    """Direct REST access to the same NPI Registry lookup the chat tool
    uses — handy for testing without spending a model call."""
    return search_providers(
        specialty=specialty, city=city, state=state,
        postal_code=postal_code, last_name=last_name, first_name=first_name,
    )


@app.post("/api/extract-card", response_model=CardDetails)
async def extract_card(file: UploadFile = File(...), provider: Literal["gemini", "openai"] | None = None):
    """Read a photo of an insurance ID card and extract its fields using the
    LLM provider's vision support. Nothing here is persisted — the image and
    extracted fields are processed in memory and returned directly; they are
    never written to disk, the conversation log, or anywhere else."""
    if not (file.content_type or "").startswith("image/"):
        raise HTTPException(status_code=400, detail="Please upload an image file (JPEG, PNG, etc.).")

    image_bytes = await file.read()
    if not image_bytes:
        raise HTTPException(status_code=400, detail="The uploaded file was empty.")
    if len(image_bytes) > MAX_CARD_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="Image is too large (max 8MB).")

    try:
        fields = llm.extract_card_details(image_bytes, file.content_type, provider=provider)
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error extracting card details")
        raise HTTPException(status_code=502, detail="Couldn't read that card image. Please try again.")

    return CardDetails(**fields)


@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    # Hard-coded safety layer runs before any model call, unconditionally —
    # so it can't be argued around and doesn't depend on the model reliably
    # following an instruction.
    escalation_reply = check_safety(req.message)
    if escalation_reply:
        log_exchange(req.message, escalation_reply, sources=[], provider=None, escalation=True)
        return ChatResponse(reply=escalation_reply, sources=[], escalation=True)

    retriever = get_retriever()

    results = retriever.search(req.message, top_k=6)

    if results:
        context_block = "\n\n---\n\n".join(
            f"Source: {r['title']} ({r['url']})\n{r['text']}" for r in results
        )
    else:
        logger.info("No knowledge-base matches for query: %r", req.message)
        context_block = "(No relevant content found in the knowledge base for this question.)"

    user_content = f"Context:\n{context_block}\n\nUser question: {req.message}"

    messages = [{"role": m.role, "content": m.content} for m in req.history]
    messages.append({"role": "user", "content": user_content})

    try:
        reply_text = llm.generate_reply(SYSTEM_PROMPT, messages, provider=req.provider)
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error generating a reply")
        raise HTTPException(status_code=502, detail="The assistant is temporarily unavailable. Please try again.")

    seen = set()
    sources = []
    for r in results:
        if r["url"] not in seen:
            seen.add(r["url"])
            sources.append(Source(title=r["title"], url=r["url"]))

    suggest_card_upload = mentions_card_details(req.message)

    log_exchange(
        req.message,
        reply_text,
        sources=[s.model_dump() for s in sources],
        provider=req.provider,
        escalation=False,
    )
    return ChatResponse(reply=reply_text, sources=sources, suggest_card_upload=suggest_card_upload)
