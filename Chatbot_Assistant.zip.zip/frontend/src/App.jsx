import { useEffect, useRef, useState } from 'react'
import './App.css'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8731/api/chat'
const API_BASE = API_URL.replace(/\/api\/chat$/, '')
const SCHOOLS_URL = `${API_BASE}/api/schools`
const EXTRACT_CARD_URL = `${API_BASE}/api/extract-card`

// Minimal, dependency-free Markdown renderer for assistant replies (the LLM
// consistently outputs **bold**, "- "/"* " bullets, "1. " numbered lists,
// and "## " headings — plain-text rendering showed these literally). Text
// is HTML-escaped first, so this can only ever produce the tags this
// function itself adds — it can't be used to inject real markup.
function escapeHtml(text) {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function renderMarkdown(text) {
  const lines = escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, label, url) => {
      const safeUrl = url.replace(/"/g, '&quot;')
      return `<a href="${safeUrl}" target="_blank" rel="noopener noreferrer">${label}</a>`
    })
    .split('\n')
  let html = ''
  let inList = false
  lines.forEach((line, i) => {
    const heading = line.match(/^#{1,6}\s+(.*)$/)
    const item = line.match(/^\s*(?:[-*]|\d+\.)\s+(.*)$/)
    if (item) {
      if (!inList) {
        html += '<ul style="margin:4px 0;padding-left:18px;">'
        inList = true
      }
      html += `<li>${item[1]}</li>`
    } else {
      if (inList) {
        html += '</ul>'
        inList = false
      }
      html += heading ? `<strong>${heading[1]}</strong>\n` : line + (i < lines.length - 1 ? '\n' : '')
    }
  })
  if (inList) html += '</ul>'
  return html
}

const CARD_FIELD_LABELS = {
  member_name: 'Name',
  member_id: 'Member ID',
  plan_name: 'Plan',
  group_number: 'Group #',
  payer_number: 'Payer #',
  pcp_election: 'PCP',
  issuer_name: 'Issuer',
  phone_number: 'Phone',
}

// Shared constant messages (GREETING, WAIVER_QUESTION, the ASK_* queue
// questions, etc.) are singleton objects reused across every conversation —
// they can't carry a hardcoded time. withTime() clones a message and stamps
// it with "now" at the moment it's actually shown, whether it's a constant
// or a freshly built object.
function withTime(msg) {
  return { ...msg, time: new Date() }
}

function formatTime(date) {
  return date ? date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : ''
}

function formatCardMessage(fields) {
  const lines = Object.entries(CARD_FIELD_LABELS)
    .filter(([key]) => fields[key])
    .map(([key, label]) => `${label}: ${fields[key]}`)
  if (lines.length === 0) {
    return "I couldn't read any details from that card image. Try a clearer photo with the whole card in frame."
  }
  return `Here's what I found on your ID card:\n${lines.join('\n')}\n\nDouble-check these against the physical card before using them for anything official.`
}

const GREETING_ID = 'greeting'
const WAIVER_GATE_ID = 'waiver-gate'
const SCHOOL_SELECT_ID = 'waiver-school-select'
const VISA_SELECT_ID = 'waiver-visa-select'
const QUEUE_QUESTION_ID = 'waiver-queue-question'

const YES_NO_BUTTONS = [
  { label: 'Yes', value: 'yes' },
  { label: 'No', value: 'no' },
]

const GREETING = {
  id: GREETING_ID,
  role: 'assistant',
  content:
    "Hi! I can answer questions about Aetna Student Health plans, benefits, and how to use them. What would you like to know? Or, if you want to check whether you can waive the university's insurance, use the button below.",
  sources: [],
  buttons: [{ label: '📋 Check my waiver eligibility', value: 'start-waiver' }],
}

const WAIVER_QUESTION = {
  id: WAIVER_GATE_ID,
  role: 'assistant',
  content:
    "Do you already have your own health insurance that might qualify for a waiver of the university's plan (for example, coverage through a parent's plan)?",
  sources: [],
  buttons: YES_NO_BUTTONS,
}

const NOT_ELIGIBLE_NO_INSURANCE = {
  role: 'assistant',
  content:
    "Since you don't currently have your own comparable health insurance, you likely wouldn't be eligible to waive the university's plan, so you'd stay covered under it automatically. Waiver requirements are set by your specific school, so if you think this doesn't apply to you, contact your school directly.",
  sources: [
    { title: 'Frequently asked questions | Aetna Student Health', url: 'https://www.aetnastudenthealth.com/en/insurance-basics/faqs.html' },
  ],
}

const GENERIC_DEMO_SOURCES = [
  { title: 'Frequently asked questions | Aetna Student Health', url: 'https://www.aetnastudenthealth.com/en/insurance-basics/faqs.html' },
  { title: 'How to Waive University Health Insurance in the US (ISOA)', url: 'https://www.isoa.org/blog/how-to-waive-university-health-insurance-in-the-us' },
]

const UT_AUSTIN_SOURCE = {
  title: "UT Austin's actual student health insurance waiver policy (real, school-specific example)",
  url: 'https://global.utexas.edu/isss/advising-services/insurance/waivers',
}

// --- Question definitions used to build a per-school, per-visa queue ---

const ASK_DEDUCTIBLE = { key: 'deductible', type: 'number', content: "What's your plan's deductible amount in USD? Just type the number (e.g. 500)." }
const ASK_COINSURANCE = { key: 'coinsurance', type: 'number', content: "What's your plan's coinsurance percentage? Just type the number (e.g. 20 for 20%)." }
const ASK_COVERAGE = { key: 'fullCoverage', type: 'yesno', content: 'Does your plan cover the full semester or academic year (not just partial dates)?' }
const ASK_TRAVEL_PLAN = { key: 'isTravelPlan', type: 'yesno', content: 'Is your plan a travel, international-only, or short-term insurance plan, rather than a standard ongoing health plan?' }
const ASK_MENTAL_HEALTH = { key: 'mentalHealth', type: 'yesno', content: 'Does your plan include mental health coverage?' }
const ASK_EVACUATION_REPATRIATION = { key: 'evacuationRepatriation', type: 'yesno', content: 'Does your plan include emergency medical evacuation and repatriation coverage?' }
const ASK_ACA = { key: 'acaCompliant', type: 'yesno', content: 'Is your plan ACA-compliant (meets Affordable Care Act standards)?' }
const ASK_PREEXISTING = { key: 'preExisting', type: 'yesno', content: 'Does your plan cover pre-existing conditions (no exclusions for them)?' }
const ASK_UNLIMITED_MAX_BENEFITS = { key: 'unlimitedMaxBenefits', type: 'yesno', content: 'Does your plan have unlimited maximum benefits (no cap on the total amount it will pay out)?' }
const ASK_OUTPATIENT = { key: 'outpatientCovered', type: 'yesno', content: 'Does your plan cover outpatient care, emergency room visits, and hospitalization?' }
const ASK_J1_MEDICAL = { key: 'meetsJ1Medical', type: 'yesno', content: 'Federal J-1 requirement: does your plan include at least $100,000 in medical benefits per accident or illness?' }
const ASK_J1_REPATRIATION = { key: 'meetsJ1Repatriation', type: 'yesno', content: 'Federal J-1 requirement: does your plan include at least $25,000 for repatriation of remains?' }
const ASK_J1_EVACUATION = { key: 'meetsJ1Evacuation', type: 'yesno', content: 'Federal J-1 requirement: does your plan include at least $50,000 for medical evacuation back to your home country?' }

function buildQuestionQueue(school, visa) {
  const queue = [ASK_DEDUCTIBLE]
  if (school.max_coinsurance_percent != null) queue.push(ASK_COINSURANCE)
  queue.push(ASK_COVERAGE)
  if (!school.travel_or_short_term_plans_accepted) queue.push(ASK_TRAVEL_PLAN)
  queue.push(ASK_MENTAL_HEALTH)
  if (school.requires_evacuation_repatriation && visa !== 'J-1') queue.push(ASK_EVACUATION_REPATRIATION)
  if (school.aca_compliance_required) queue.push(ASK_ACA)
  if (school.requires_unlimited_max_benefits) queue.push(ASK_UNLIMITED_MAX_BENEFITS)
  if (school.requires_no_preexisting_exclusions) queue.push(ASK_PREEXISTING)

  if (visa === 'F-1') queue.push(ASK_OUTPATIENT)
  else if (visa === 'J-1') queue.push(ASK_J1_MEDICAL, ASK_J1_REPATRIATION, ASK_J1_EVACUATION)

  return queue
}

function parseYesNo(text) {
  const t = text.trim().toLowerCase()
  if (/^(y|yes|yeah|yep|sure|correct)\b/.test(t)) return true
  if (/^(n|no|nope|nah)\b/.test(t)) return false
  return null
}

function parseVisaChoice(text) {
  const t = text.toLowerCase()
  if (/\bj-?1\b/.test(t)) return 'J-1'
  if (/\bf-?1\b/.test(t)) return 'F-1'
  if (/\bus\b|u\.s\.?|american|domestic/.test(t)) return 'US'
  return null
}

function schoolSources(school) {
  if (school.source_url) return [{ title: `${school.name}'s waiver policy`, url: school.source_url }]
  return GENERIC_DEMO_SOURCES
}

function buildJ1NotAllowedMessage(school) {
  const content = school.is_real
    ? `${school.name}'s actual published policy states that J-1 exchange students are generally not eligible to waive its student health insurance plan at all, regardless of what other coverage you have. You'd need to contact your school's international student office directly rather than pursue a waiver.`
    : `In this demo, ${school.name}'s example policy doesn't allow J-1 visa holders to waive its plan at all, regardless of other coverage. (This particular school is invented for the demo, but it reflects something real: actual schools like UT Austin do restrict or disallow J-1 waivers entirely.) You'd need to contact your school's international student office directly.`

  return {
    role: 'assistant',
    content,
    sources: school.is_real ? schoolSources(school) : [UT_AUSTIN_SOURCE],
  }
}

function buildResultMessage(school, visa, answers) {
  const checks = [
    {
      label: `Deductible ($${answers.deductible} vs. ${school.name}'s max of $${school.max_deductible})`,
      pass: Number.isFinite(answers.deductible) && answers.deductible <= school.max_deductible,
    },
  ]
  if (school.max_coinsurance_percent != null) {
    checks.push({
      label: `Coinsurance (${answers.coinsurance}% vs. max ${school.max_coinsurance_percent}%)`,
      pass: Number.isFinite(answers.coinsurance) && answers.coinsurance <= school.max_coinsurance_percent,
    })
  }
  checks.push({ label: 'Covers the full semester/academic year', pass: answers.fullCoverage })
  if (!school.travel_or_short_term_plans_accepted) {
    checks.push({ label: 'Is not a travel/short-term/international-only plan', pass: answers.isTravelPlan === false })
  }
  checks.push({ label: 'Includes mental health coverage', pass: answers.mentalHealth })
  if (school.requires_evacuation_repatriation && visa !== 'J-1') {
    checks.push({ label: 'Includes emergency evacuation and repatriation coverage', pass: answers.evacuationRepatriation })
  }
  if (school.aca_compliance_required) {
    checks.push({ label: 'ACA-compliant', pass: answers.acaCompliant })
  }
  if (school.requires_unlimited_max_benefits) {
    checks.push({ label: 'Has unlimited maximum benefits', pass: answers.unlimitedMaxBenefits })
  }
  if (school.requires_no_preexisting_exclusions) {
    checks.push({ label: 'Covers pre-existing conditions (no exclusions)', pass: answers.preExisting })
  }

  if (visa === 'F-1') {
    checks.push({ label: 'Covers outpatient care, ER visits, and hospitalization', pass: answers.outpatientCovered })
  } else if (visa === 'J-1') {
    checks.push({ label: 'Meets $100k medical minimum (J-1 federal requirement)', pass: answers.meetsJ1Medical })
    checks.push({ label: 'Meets $25k repatriation minimum (J-1 federal requirement)', pass: answers.meetsJ1Repatriation })
    checks.push({ label: 'Meets $50k evacuation minimum (J-1 federal requirement)', pass: answers.meetsJ1Evacuation })
  }

  const allPass = checks.every((c) => c.pass)
  const lines = checks.map((c) => `${c.pass ? '✅' : '❌'} ${c.label}`).join('\n')
  const verdict = allPass
    ? `Based on what you've told me, your plan looks like it would meet ${school.name}'s requirements${school.is_real ? '' : ' (example criteria)'}. Next step: submit your proof documents (insurance ID, policy details, benefits summary) before the deadline${school.deadline ? ` (${school.deadline})` : ''}.`
    : `Based on what you've told me, your plan doesn't meet all of ${school.name}'s requirements${school.is_real ? '' : ' (example criteria)'}. See which item(s) above didn't pass. You may want to check with your insurer about upgrading coverage, or contact your school's insurance office directly.`

  return {
    role: 'assistant',
    content: `${lines}\n\n${verdict}`,
    sources: schoolSources(school),
  }
}

export default function App() {
  const [messages, setMessages] = useState([withTime(GREETING)])
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [chatOpen, setChatOpen] = useState(false)
  const [schools, setSchools] = useState([])
  const [waiverStep, setWaiverStep] = useState('greeting') // greeting | gate | school | visa | queue | done
  const [selectedSchool, setSelectedSchool] = useState(null)
  const [selectedVisa, setSelectedVisa] = useState(null)
  const [questionQueue, setQuestionQueue] = useState([])
  const [queueIndex, setQueueIndex] = useState(0)
  const [waiverAnswers, setWaiverAnswers] = useState({})
  const [schoolChoice, setSchoolChoice] = useState('')
  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)
  const fileInputRef = useRef(null)

  useEffect(() => {
    fetch(SCHOOLS_URL)
      .then((res) => res.json())
      .then(setSchools)
      .catch(() => setSchools([]))
  }, [])

  useEffect(() => {
    if (chatOpen) messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, chatOpen])

  useEffect(() => {
    if (chatOpen) inputRef.current?.focus()
  }, [chatOpen])

  function stripButtons(prev, id) {
    return prev.map((m) => (m.id === id ? { ...m, buttons: null, schoolSelect: false } : m))
  }

  function currentQuestion() {
    return questionQueue[queueIndex]
  }

  function advanceQueueAfterAnswer(nextAnswers) {
    if (queueIndex + 1 < questionQueue.length) {
      const next = questionQueue[queueIndex + 1]
      setMessages((p) => [
        ...stripButtons(p, QUEUE_QUESTION_ID),
        withTime({ id: QUEUE_QUESTION_ID, role: 'assistant', content: next.content, sources: [], buttons: next.type === 'yesno' ? YES_NO_BUTTONS : null }),
      ])
      setQueueIndex((i) => i + 1)
      if (next.type === 'number') inputRef.current?.focus()
    } else {
      setMessages((p) => [...stripButtons(p, QUEUE_QUESTION_ID), withTime(buildResultMessage(selectedSchool, selectedVisa, nextAnswers))])
      setWaiverStep('done')
    }
  }

  async function sendMessage() {
    const text = input.trim()
    if (!text || sending) return

    if (waiverStep === 'queue' && currentQuestion()?.type === 'number') {
      const cleaned = text.replace(/[^0-9.]/g, '')
      const amount = parseFloat(cleaned)
      setInput('')
      setMessages((p) => [...p, withTime({ role: 'user', content: text })])
      if (!cleaned || !Number.isFinite(amount)) {
        setMessages((p) => [
          ...p,
          withTime({
            role: 'assistant',
            content: "That doesn't look like a number. Please type just the numeric amount (e.g. 500). If you're not sure, check your insurance card or policy documents; you can also upload your card with the 📎 button and I'll try to read it.",
            sources: [],
          }),
        ])
        return
      }
      // Compute the next answers snapshot directly (not via a setState
      // updater) before advancing the queue — advanceQueueAfterAnswer has
      // side effects (setMessages/setQueueIndex/setWaiverStep), and calling
      // it from inside an updater breaks under StrictMode's deliberate
      // double-invocation of updaters, silently desyncing queueIndex.
      const next = { ...waiverAnswers, [currentQuestion().key]: amount }
      setWaiverAnswers(next)
      advanceQueueAfterAnswer(next)
      return
    }

    if (waiverStep === 'gate' || (waiverStep === 'queue' && currentQuestion()?.type === 'yesno')) {
      const parsed = parseYesNo(text)
      setInput('')
      if (parsed === null) {
        setMessages((p) => [
          ...p,
          withTime({ role: 'user', content: text }),
          withTime({ role: 'assistant', content: 'Sorry, I didn\'t catch that. Please tap Yes or No above, or type "yes" or "no".', sources: [] }),
        ])
        return
      }
      if (waiverStep === 'gate') handleGateAnswer(parsed ? 'yes' : 'no', text)
      else handleQueueButtonAnswer(parsed ? 'yes' : 'no', text)
      return
    }

    if (waiverStep === 'visa') {
      const visa = parseVisaChoice(text)
      setInput('')
      if (!visa) {
        setMessages((p) => [
          ...p,
          withTime({ role: 'user', content: text }),
          withTime({ role: 'assistant', content: 'Sorry, I didn\'t catch that. Please choose US Student, F-1 Visa, or J-1 Visa from the buttons above, or type one of those.', sources: [] }),
        ])
        return
      }
      handleVisaAnswer(visa, text)
      return
    }

    const history = messages
      .filter((m) => m.role === 'user' || m.role === 'assistant')
      .map((m) => ({ role: m.role, content: m.content }))

    setMessages((prev) => [...prev, withTime({ role: 'user', content: text })])
    setInput('')
    setSending(true)

    try {
      const res = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history }),
      })
      if (!res.ok) {
        let detail = `Request failed (${res.status})`
        try {
          const errData = await res.json()
          if (errData?.detail) detail = errData.detail
        } catch {
          // response body wasn't JSON — keep the generic detail
        }
        throw new Error(detail)
      }
      const data = await res.json()
      setMessages((prev) => [
        ...prev,
        withTime({
          role: 'assistant',
          content: data.reply,
          sources: data.sources || [],
          escalation: data.escalation,
          suggestCardUpload: data.suggest_card_upload,
        }),
      ])
    } catch (err) {
      const detail = err instanceof Error && err.message ? err.message : 'unknown error'
      setMessages((prev) => [
        ...prev,
        withTime({
          role: 'assistant',
          content: `Sorry, something went wrong: ${detail}. Please try again or use Contact Us.`,
          sources: [],
        }),
      ])
    } finally {
      setSending(false)
    }
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter') sendMessage()
  }

  async function handleCardUpload(e) {
    const file = e.target.files?.[0]
    e.target.value = '' // allow re-selecting the same file later
    if (!file) return

    setMessages((prev) => [...prev, withTime({ role: 'user', content: `📎 Uploaded: ${file.name}` })])
    setSending(true)

    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch(EXTRACT_CARD_URL, { method: 'POST', body: formData })
      if (!res.ok) {
        let detail = `Request failed (${res.status})`
        try {
          const errData = await res.json()
          if (errData?.detail) detail = errData.detail
        } catch {
          // response body wasn't JSON — keep the generic detail
        }
        throw new Error(detail)
      }
      const fields = await res.json()
      setMessages((prev) => [...prev, withTime({ role: 'assistant', content: formatCardMessage(fields), sources: [] })])
    } catch (err) {
      const detail = err instanceof Error && err.message ? err.message : 'unknown error'
      setMessages((prev) => [...prev, withTime({ role: 'assistant', content: `Sorry, I couldn't read that card: ${detail}`, sources: [] })])
    } finally {
      setSending(false)
    }
  }

  function handleStartWaiver() {
    setMessages((prev) => [
      ...stripButtons(prev, GREETING_ID),
      withTime({ role: 'user', content: 'Check my waiver eligibility' }),
      withTime(WAIVER_QUESTION),
    ])
    setWaiverStep('gate')
  }

  function handleGateAnswer(value, userLabel) {
    const label = userLabel ?? (value === 'no' ? 'No' : 'Yes')
    if (value === 'no') {
      setMessages((prev) => [...stripButtons(prev, WAIVER_GATE_ID), withTime({ role: 'user', content: label }), withTime(NOT_ELIGIBLE_NO_INSURANCE)])
      setWaiverStep('done')
      return
    }
    setMessages((prev) => [
      ...stripButtons(prev, WAIVER_GATE_ID),
      withTime({ role: 'user', content: label }),
      withTime({
        id: SCHOOL_SELECT_ID,
        role: 'assistant',
        content: "Let's check your plan against your specific school's waiver criteria. Which school are you at?",
        sources: [],
        schoolSelect: true,
      }),
    ])
    setWaiverStep('school')
  }

  function handleSchoolAnswer(schoolId) {
    const school = schools.find((s) => s.id === schoolId)
    if (!school) return
    setSelectedSchool(school)
    setSchoolChoice('')
    setMessages((prev) => [
      ...stripButtons(prev, SCHOOL_SELECT_ID),
      withTime({ role: 'user', content: school.name }),
      withTime({
        id: VISA_SELECT_ID,
        role: 'assistant',
        content: `Got it, ${school.name}. Are you a US student, or an international student on an F-1 or J-1 visa?`,
        sources: [],
        buttons: [
          { label: 'US Student', value: 'US' },
          { label: 'F-1 Visa', value: 'F-1' },
          { label: 'J-1 Visa', value: 'J-1' },
        ],
      }),
    ])
    setWaiverStep('visa')
  }

  function handleVisaAnswer(value, userLabel) {
    setSelectedVisa(value)
    const label = userLabel ?? (value === 'US' ? 'US Student' : `${value} Visa`)

    if (value === 'J-1' && !selectedSchool.j1_waiver_allowed) {
      setMessages((prev) => [...stripButtons(prev, VISA_SELECT_ID), withTime({ role: 'user', content: label }), withTime(buildJ1NotAllowedMessage(selectedSchool))])
      setWaiverStep('done')
      return
    }

    const queue = buildQuestionQueue(selectedSchool, value)
    setQuestionQueue(queue)
    setQueueIndex(0)
    setWaiverAnswers({})
    const first = queue[0]
    setMessages((prev) => [
      ...stripButtons(prev, VISA_SELECT_ID),
      withTime({ role: 'user', content: label }),
      withTime({ id: QUEUE_QUESTION_ID, role: 'assistant', content: first.content, sources: [], buttons: first.type === 'yesno' ? YES_NO_BUTTONS : null }),
    ])
    setWaiverStep('queue')
    if (first.type === 'number') inputRef.current?.focus()
  }

  function handleQueueButtonAnswer(value, userLabel) {
    const q = currentQuestion()
    if (!q) return
    const parsed = value === 'yes'
    const label = userLabel ?? (value === 'yes' ? 'Yes' : 'No')
    setMessages((p) => [...stripButtons(p, QUEUE_QUESTION_ID), withTime({ role: 'user', content: label })])
    const next = { ...waiverAnswers, [q.key]: parsed }
    setWaiverAnswers(next)
    advanceQueueAfterAnswer(next)
  }

  const BUTTON_HANDLERS = {
    greeting: handleStartWaiver,
    gate: handleGateAnswer,
    school: handleSchoolAnswer,
    visa: handleVisaAnswer,
    queue: handleQueueButtonAnswer,
  }

  return (
    <div className="chat-page">
      <div className="hero">
        <div className="hero-text">
          <h1>Welcome to Aetna Student Health</h1>
          <p>
            Health plans created with you in mind. We're here to support your
            well-being. With expert care. Extra support. A simple experience.
            Choose your school to get started with enrollment, waiver options,
            and more.
          </p>
        </div>
      </div>

      {chatOpen && (
        <div className="chat-panel">
          <header className="chat-header">
            Aetna Student Health Assistant
            <button className="chat-close" aria-label="Close chat" onClick={() => setChatOpen(false)}>
              ✕
            </button>
          </header>

          <div className="chat-messages">
            {messages.map((m, i) => (
              <div key={i} className={`bubble-row ${m.role}`}>
                {m.role === 'assistant' && <div className="avatar">♥</div>}
                <div className="bubble-content">
                  {m.role === 'assistant' ? (
                    <div
                      className={`bubble ${m.role} ${m.escalation ? 'escalation' : ''}`}
                      dangerouslySetInnerHTML={{ __html: renderMarkdown(m.content) }}
                    />
                  ) : (
                    <div className={`bubble ${m.role}`}>{m.content}</div>
                  )}
                  {m.time && <div className="msg-time">{formatTime(m.time)}</div>}
                  {m.sources && m.sources.length > 0 && (
                    <div className="sources">
                      Learn more:
                      {m.sources.map((s) => (
                        <a key={s.url} href={s.url} target="_blank" rel="noopener noreferrer">
                          {s.title}
                        </a>
                      ))}
                    </div>
                  )}
                  {m.buttons && (
                    <div className="quick-replies">
                      {m.buttons.map((b) => (
                        <button key={b.value} onClick={() => BUTTON_HANDLERS[waiverStep]?.(b.value)}>
                          {b.label}
                        </button>
                      ))}
                    </div>
                  )}
                  {m.schoolSelect && (
                    <div className="school-select-row">
                      <select value={schoolChoice} onChange={(e) => setSchoolChoice(e.target.value)}>
                        <option value="" disabled>
                          Choose your school...
                        </option>
                        {schools.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name}
                          </option>
                        ))}
                      </select>
                      <button onClick={() => schoolChoice && handleSchoolAnswer(schoolChoice)} disabled={!schoolChoice}>
                        Continue
                      </button>
                    </div>
                  )}
                  {m.suggestCardUpload && (
                    <div className="quick-replies">
                      <button onClick={() => fileInputRef.current?.click()}>📎 Upload your ID card</button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {sending && (
              <div className="bubble-row assistant">
                <div className="avatar">♥</div>
                <div className="bubble assistant typing">...</div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="chat-input-row">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              hidden
              onChange={handleCardUpload}
            />
            <button
              type="button"
              className="upload-btn"
              title="Upload your insurance ID card"
              aria-label="Upload your insurance ID card"
              onClick={() => fileInputRef.current?.click()}
              disabled={sending}
            >
              📎
            </button>
            <input
              ref={inputRef}
              type="text"
              placeholder="Ask about your plan, benefits, or coverage..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={sending}
            />
            <button onClick={sendMessage} disabled={sending}>
              Send
            </button>
          </div>
        </div>
      )}

      <button
        className="chat-launcher"
        aria-label={chatOpen ? 'Close chat' : 'Open chat'}
        onClick={() => setChatOpen((open) => !open)}
      >
        {chatOpen ? '✕' : '💬'}
      </button>
    </div>
  )
}
