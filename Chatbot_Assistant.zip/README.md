# Aetna Student Health Chatbot

A chatbot for [aetnastudenthealth.com](https://www.aetnastudenthealth.com/) that
helps students with their Aetna Student Health plan. It ships as a full-page
React app and as an embeddable widget, both backed by one FastAPI service.

What it does:

| Feature | How it works | Uses the LLM? |
|---|---|---|
| Answers questions about plans, benefits, and forms | Retrieval over content scraped from the site, then an LLM writes the answer, streamed word by word | Yes |
| Finds real doctors, dentists, and specialists | The LLM calls a search tool backed by the public NPI Registry | Yes |
| Reads an insurance ID card (photo or PDF) | LLM vision extracts member ID, group number, plan, and more; nothing is stored | Yes (vision) |
| Checks whether a student can waive their university's plan | Rule-based questions per school, pass/fail checklist, downloadable pre-check summary | No |
| Helps with a waiver that's already submitted | Fixed next steps for pending, approved, or denied (by reason) | No |
| Handles emergencies, crisis, and abuse messages | Fixed reply with real resources (911, 988, hotlines) before any model call | No |

The bot only answers from the scraped content, points students to Contact Us
or member log-in for anything account-specific, and never claims a provider
is in-network. It **does not submit or approve waivers**: the school's
insurance administrator and audit team decide every waiver after verifying
coverage with the insurer.

For diagrams and the full design (including the real-world waiver audit
process and how this could connect to an audit team), see
`Chatbot_Flow_and_Architecture.docx`.

## How it works

### Chat answers

1. **Scraper** (`scraper/`) fetches a curated list of site pages into
   `data/pages/*.json`, and `scraper/pdf_scrape.py` downloads the PDFs those
   pages link to (claim forms, brochures, notices) and extracts their text
   into `data/pdf_docs/*.json`, so the bot can explain what a form asks for.
   Scanned, image-only PDFs are skipped (no OCR).
2. **Index builder** (`backend/build_index.py`) splits the pages, PDFs, and
   `data/waiver/*.json` notes into ~800-character chunks and embeds them into
   `data/index.pkl`. The provider that built the index is recorded in it, and
   queries are always embedded with that same provider.
3. **Safety layer** (`backend/safety.py`) checks every message with plain
   regex before anything else. Emergency, crisis/self-harm, and abuse
   messages get a fixed reply with real resources, and the model is never
   called.
4. **Retrieval** (`backend/retrieval.py`) picks the 6 most relevant chunks
   (similarity of at least 0.4, no more than 3 from one page).
5. **LLM** (`backend/llm.py`, prompt in `backend/prompts.py`) writes the
   answer from those chunks, OpenAI or Gemini, at temperature 0.2. For "find
   me a doctor" questions it can call the `search_providers` tool
   (`backend/providers.py`, NPI Registry), up to 3 rounds.
6. **Streaming:** the React app and widget use `POST /api/chat/stream`, so
   the first words appear in about 1.5 seconds instead of after the whole
   answer is ready. The reply ends with its source links, and a card-upload
   suggestion when the student asked about something printed on their own
   card (`backend/card_intent.py`).
7. **Errors:** if OpenAI or Gemini fails (bad key, quota, outage), the full
   error goes to the server log and students only see "the assistant is
   temporarily unavailable" (`backend/errors.py`).
8. Every exchange is appended to `data/conversations.db` (see Known
   limitations).

### ID card reader

`POST /api/extract-card` accepts a photo (up to 8 MB) or a PDF (up to 15 MB;
page 1 is rendered to an image with PyMuPDF). The LLM's vision reads 8
fields and returns them straight to the browser. Nothing is written to disk
or the log.

### Waiver tools (in the browser, no LLM)

All waiver logic lives in one file, `widget/waiver-rules.js`, shared by the
React app and the widget. It runs in the student's browser: answers are never
stored or sent to the backend.

- **Eligibility walkthrough.** The student picks a school (list from
  `GET /api/schools`) and a visa type (US, F-1, J-1), then answers mostly
  Yes/No questions built from that school's rules. A question is only asked
  when the school actually has that requirement. The result is a checklist of
  passes and fails, plus warnings that don't change the verdict, and on a pass
  the deadline and the documents the auditor will ask for.
- **Audit checks for every school**, modeled on published waiver denial
  reasons (Gallagher Student Health, UnitedHealthcare StudentResources,
  Wellfleet, Aetna Student Health schools): coverage active; real insurance
  rather than a health-share, indemnity, accident-only, or emergency-only
  plan; and whether the school plan was already used (a warning).
- **Federal J-1 rules** (22 CFR 62.14): $100k medical, $25k repatriation,
  $50k evacuation, deductible of $500 or less, coinsurance of 25% or less,
  insurer rated A- or better.
- **Deadlines are checked automatically** against today's date for schools
  with real dates, using the next open term. If a once-a-year deadline has
  passed (Emory), the walkthrough ends when the school is chosen. The
  student is only asked when a school has no dates or its next term isn't
  posted yet. A deadline counts as open through the end of its date.
- **Pre-check summary.** After a result, "Download my pre-check summary"
  opens a print-ready page (every question and answer, the checklist, the
  documents list) that the student can Save as PDF and attach to their real
  waiver. It's clearly marked "not a waiver approval".
- **Waiver status helper.** "Help with my waiver status" gives next steps for
  pending, approved, or denied waivers (by the reason in the denial email).
  Typed messages like "my waiver was denied" or "code 1003" get the same
  answers without calling the LLM. Reason codes follow Gallagher's published
  list; other administrators may use different codes.

### Schools

| School | Type | Notes |
|---|---|---|
| University of Texas at Austin | Real | PPACA-compliant, US-based insurer; evacuation/repatriation can be bought through AHP instead; J-1 students can't waive; deadlines per term |
| University of Texas at Dallas | Real | PPACA-compliant, unlimited benefits, no pre-existing limits; government-sponsored plans reviewed individually; spring dates not posted yet |
| Emory University | Real | Mirrors Emory's 13-item auditor waiver checklist (Georgia-only Medicaid, care in Atlanta, contraceptives and preventive care at 100%, coverage through July 31, 2027); once-a-year deadline, August 14, 2026 |
| 4 example schools | Demo | Fictional and clearly labeled; show how requirements vary |

## Setup

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env` and add your API key(s):

```
LLM_PROVIDER=openai           # or "gemini": the default provider for chat
EMBEDDING_PROVIDER=openai     # or "gemini": builds and queries the search index

OPENAI_API_KEY=...            # https://platform.openai.com/api-keys
OPENAI_MODEL=gpt-4o-mini
GEMINI_API_KEY=...            # https://aistudio.google.com/apikey
GEMINI_MODEL=gemini-3.6-flash

ALLOWED_ORIGINS=*             # which websites may call the API (restrict in production)
```

- `EMBEDDING_PROVIDER` is separate from `LLM_PROVIDER`. With the defaults you
  only need an OpenAI key; to run on Gemini alone, set both to `gemini` and
  rebuild the index.
- Changing `EMBEDDING_PROVIDER` requires rebuilding the index, because the
  index can only be searched with the provider that built it.
- A single request can override the chat provider with `"provider": "gemini"`
  (or `"openai"`) in the request body, for example if one hits a rate limit.
- The backend reads `.env` once at startup: restart it after changing a key.

## Build the knowledge base

```bash
python scraper/scrape.py        # site pages   -> data/pages/*.json
python scraper/pdf_scrape.py    # linked PDFs  -> data/pdf_docs/*.json
python -m backend.build_index   # all of it    -> data/index.pkl
```

`data/index.pkl` isn't included in the repo or the zip, so run the last
command once on a fresh setup (it calls the embeddings API for every chunk,
batched, at a small cost). Re-run all three when the site content changes,
for example each plan year.

## Run it

Backend (port 8731):

```bash
uvicorn backend.app:app --reload --port 8731
```

Check it's alive: `GET http://localhost:8731/api/health` returns
`{"status": "ok"}`.

React app (port 5173):

```bash
cd frontend
npm install
npm run dev
```

The app reads the backend URL from `VITE_API_URL` in `frontend/.env`
(default `http://localhost:8731/api/chat`); copy `frontend/.env.example` to
point it elsewhere.

Widget preview: open [widget/demo.html](widget/demo.html) in a browser (from
disk works) or go to `http://localhost:8731/widget/demo.html`.

## API

| Endpoint | Purpose | Uses the LLM? |
|---|---|---|
| `GET /api/health` | Health check | No |
| `GET /api/schools` | School waiver rules for the walkthrough | No |
| `GET /api/providers/search` | Direct NPI provider search, for testing | No |
| `POST /api/chat` | Answer a question, returned all at once | Yes, unless the safety layer replies |
| `POST /api/chat/stream` | Same, streamed while it's written | Yes, unless the safety layer replies |
| `POST /api/extract-card` | Read an insurance ID card | Yes (vision) |
| `/widget/*` | Static widget files | No |

Chat requests take `{"message": "...", "history": [...], "provider": "openai"}`
(history and provider are optional; history is up to 20 messages of up to
4,000 characters each, and the UIs trim it for you).

`/api/chat/stream` returns newline-delimited JSON events:

```
{"type": "delta", "text": "Your plan"}                 the next piece of the answer
{"type": "done", "reply": "...", "sources": [...],     the complete answer and its sources
 "escalation": false, "suggest_card_upload": false}
{"type": "error", "detail": "..."}                     the model failed after streaming began
```

Problems found before streaming starts (invalid request, missing index,
provider failure during search) are ordinary HTTP errors.

Examples:

```bash
curl -N -X POST http://localhost:8731/api/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"message": "How do I get my ID card?"}'

# doctor search through the model's tool
curl -X POST http://localhost:8731/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Find me a family medicine doctor near Boston, MA"}'

# direct NPI search, no model call
curl "http://localhost:8731/api/providers/search?specialty=Dentist&city=Chicago&state=IL"
```

## Adding or updating a school

Each school is one JSON file in `data/college_req_waiver/`. Copy an existing
file and set the fields that match the school's published policy (leave the
rest `false` or `null`, and a question is only asked when its field is set):

| Fields | Meaning |
|---|---|
| `id`, `name`, `is_real`, `source_url` | Identity; real schools must link their policy page |
| `max_deductible`, `max_coinsurance_percent`, `max_out_of_pocket` | Cost limits |
| `travel_or_short_term_plans_accepted`, `rejects_catastrophic_plans`, `accepted_medicaid_state` | Plan types |
| `requires_us_based_insurer`, `aca_compliance_required`, `requires_local_nonemergency_coverage`, `campus_area` | Insurer and network (`campus_area` names the region, e.g. "Atlanta, GA") |
| `requires_prescription_coverage`, `requires_preventive_care`, `preventive_care_at_no_cost`, `requires_maternity_coverage`, `maternity_female_students_only`, `requires_contraceptive_coverage`, `requires_substance_use_coverage`, `requires_unlimited_max_benefits`, `requires_no_preexisting_exclusions` | Benefits |
| `requires_evacuation_repatriation`, `evacuation_repatriation_fallback` | International coverage; the fallback names where students can buy it instead of failing |
| `j1_waiver_allowed`, `accepts_government_sponsored_plans` | Visa rules and sponsored plans |
| `deadline_dates` (`term`, `date` as YYYY-MM-DD, `time`), `annual_waiver_only`, `deadline`, `coverage_through` | Deadlines per term, whether waiving is once a year, a text fallback, and the required coverage end date |

The backend reads these files once at startup, so **restart it after any
change**. Update `deadline_dates` each term as schools post new dates.

## Embedding on the real site

Add this to the site's HTML, before `</body>`:

```html
<script src="https://YOUR-BACKEND-HOST/widget/widget.js"
        data-api-url="https://YOUR-BACKEND-HOST/api/chat"></script>
```

The widget derives the streaming, schools, and card URLs from
`data-api-url`, and loads `waiver-rules.js` from its own folder. Adding the
tag needs publish access to aetnastudenthealth.com or its CMS.

## Deployment notes

- **Backend:** any Python host works (Render, Railway, Fly.io, a VM). Set the
  variables from `.env.example` as environment variables there; don't commit
  `.env`. Build `data/index.pkl` once (see above).
- **React app:** set `VITE_API_URL` to the real backend before
  `npm run build`, because the URL is baked into the build in
  `frontend/dist`.
- **Widget:** serve `widget/widget.js` and `widget/waiver-rules.js` from the
  same folder (FastAPI already serves `widget/` at `/widget`). If
  `waiver-rules.js` is missing, chat still works but the waiver buttons never
  appear.
- **CORS:** set `ALLOWED_ORIGINS` to the real site's domain instead of `*`.
- **Proxies:** if the backend sits behind nginx or similar, make sure it
  doesn't buffer `/api/chat/stream` (the endpoint sends
  `X-Accel-Buffering: no` for nginx).
- **Content refresh:** re-run the scraper and index build when the site
  changes.

## Known limitations

- **No authentication and no rate limiting.** Anyone who can reach the API
  can call it and use your API credits. Add both before a pilot.
- **The chat log is local and unencrypted** (`data/conversations.db`). Before
  real use: encryption at rest, access control, a retention policy, and a
  check with legal/compliance on whether messages could contain PHI.
- **ID card images go to the LLM provider** to be read, even though nothing
  is stored afterwards. Get sign-off before a pilot.
- **No waiver submission or status lookup.** The chatbot pre-checks and
  guides; it isn't connected to the school, the insurance administrator, or
  an audit system.
- **The chat's knowledge base doesn't cover every school's waiver rules.** The
  walkthrough knows all configured schools, but the LLM only knows what's in
  `data/pages`, `data/pdf_docs`, and `data/waiver` (for example, it has no
  Emory content).
- **The first question after a restart is slow** (about 8 seconds) because
  the search index loads on first use.
- **Prompts and safety replies** haven't been reviewed by legal, compliance,
  or clinical staff.
- **No automated tests in the repo yet.**

## Project structure

```
.env.example         template for .env (API keys, providers, allowed origins)
requirements.txt     Python dependencies
scraper/
  urls.py            curated list of pages to scrape
  scrape.py          fetches and cleans page content
  pdf_scrape.py      finds linked PDFs, downloads them, extracts their text
backend/
  app.py             FastAPI app and all endpoints (chat, chat/stream, extract-card, schools, providers)
  config.py          loads .env; single source of truth for settings
  prompts.py         system prompt
  safety.py          emergency / crisis / abuse check
  retrieval.py       loads the index, similarity search
  embeddings.py      OpenAI / Gemini embeddings for indexing and queries
  build_index.py     chunks content and builds data/index.pkl
  llm.py             OpenAI / Gemini chat (normal and streaming), provider-search tool loop, card vision
  providers.py       NPI Registry search
  card_intent.py     detects "what's on my card" questions
  errors.py          provider errors: logged in full, shown to students as a plain message
  schools.py         loads data/college_req_waiver/*.json
  conversation_log.py  SQLite chat log
widget/
  widget.js          embeddable chat widget
  waiver-rules.js    waiver walkthrough, deadlines, status helper, pre-check summary (shared with the React app)
  demo.html          local page for previewing the widget
frontend/
  src/App.jsx        React app: landing page and chat panel
  vite.config.js     lets the dev server read ../widget/waiver-rules.js
data/
  pages/             scraped site content
  pdf_docs/          text extracted from linked PDFs
  waiver/            waiver process notes for the chat's knowledge base
  college_req_waiver/  one JSON file per school (waiver rules)
  index.pkl          generated search index (not in git; build it)
  conversations.db   chat log (not in git)
```
