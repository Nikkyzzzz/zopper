# Aetna Student Health Chatbot

A Q&A chatbot for [aetnastudenthealth.com](https://www.aetnastudenthealth.com/) that
answers questions using content scraped from the site itself, plus an embeddable
widget you can drop onto any page.

## How it works

1. **Scraper** (`scraper/`) fetches a curated list of Aetna Student Health pages
   (plans, FAQs, benefits, how to use your plan, etc.) and saves cleaned text
   to `data/pages/*.json`.
2. **Index builder** (`backend/build_index.py`) splits that text into chunks
   and builds a TF-IDF search index (`data/index.pkl`) — no external embedding
   API needed.
3. **Safety layer** (`backend/safety.py`) checks every message for medical
   emergencies, crisis/self-harm, and abuse *before* any model call, using
   plain regex — not the model's judgment. A match short-circuits straight
   to a fixed, real-resource reply (911, 988, Crisis Text Line, the National
   Domestic Violence Hotline, RAINN).
4. **Backend** (`backend/app.py`, FastAPI) exposes `POST /api/chat`. For each
   non-escalated message it retrieves the most relevant chunks, hands them to
   an LLM (Gemini or OpenAI — see `backend/llm.py`) as grounding context, and
   returns the model's answer plus the source page links it used. The model
   also has a `search_providers` tool (`backend/providers.py`) backed by the
   real, public NPI Registry — no scraping, no key needed — for "find me a
   doctor/dentist" questions. It's also exposed directly at
   `GET /api/providers/search` for testing without a model call.
5. **Widget** (`widget/widget.js`) is a small embeddable chat bubble that
   calls the backend. Drop it on any page with a `<script>` tag.

The bot only answers from the scraped content (never invents plan details),
points users to Contact Us / member log-in for anything account-specific,
and a provider search result confirms a real, licensed provider only — never
that they're in-network for the user's specific plan.

## Setup

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env` and add a key for whichever provider you want
to use — you only need one, but both can be configured at once:

```
LLM_PROVIDER=gemini           # or "openai" — picks the default

GEMINI_API_KEY=...            # https://aistudio.google.com/apikey
OPENAI_API_KEY=...            # https://platform.openai.com/api-keys
```

`LLM_PROVIDER` sets the server-wide default. A single request can also
override it by passing `"provider": "openai"` (or `"gemini"`) in the
`POST /api/chat` body — handy for switching providers without restarting
the server (e.g. if one hits a rate limit).

## Build the knowledge base

```bash
python scraper/scrape.py       # fetches pages into data/pages/*.json
python backend/build_index.py  # builds data/index.pkl
```

Re-run both any time you want to refresh the content from the live site
(e.g. plans/benefits change each academic year).

## Run the backend

```bash
uvicorn backend.app:app --reload --port 8731
```

Check it's alive: `GET http://localhost:8731/api/health` → `{"status": "ok"}`.

Test a question:

```bash
curl -X POST http://localhost:8731/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "How do I get my ID card?"}'

# or force OpenAI for this one request:
curl -X POST http://localhost:8731/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "How do I get my ID card?", "provider": "openai"}'

# provider search, via the model (uses the search_providers tool):
curl -X POST http://localhost:8731/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Find me a family medicine doctor near Boston, MA"}'

# provider search, direct (no model call):
curl "http://localhost:8731/api/providers/search?specialty=Dentist&city=Chicago&state=IL"
```

## Try the widget locally

Open [widget/demo.html](widget/demo.html) in a browser (with the backend
running on port 8731) — a simple pink hero page ("Welcome to Aetna Student
Health") with the floating chat bubble pinned bottom-right, exactly as it'd
look embedded on a real page.

## React frontend

`frontend/` is a standalone React (Vite) app that mirrors the widget's own
UX — the same pink hero landing section as `widget/demo.html`, plus a
floating chat button that opens the same chat panel as an overlay — talking
to the same `POST /api/chat` endpoint. Useful for a shareable full-page
preview instead of embedding the widget script into an existing page.

```bash
cd frontend
npm install
npm run dev
```

Opens at `http://localhost:5173` (or the next free port). It reads the
backend URL from `VITE_API_URL` in `frontend/.env` (defaults to
`http://localhost:8731/api/chat`) — copy `.env.example` if you need to point
it elsewhere. Run the backend (above) first so the page has something to
call.

## Embedding on the real site

Once deployed, add this to the site's HTML (footer, before `</body>`):

```html
<script src="https://YOUR-BACKEND-HOST/widget/widget.js"
        data-api-url="https://YOUR-BACKEND-HOST/api/chat"></script>
```

You'd need publish access to aetnastudenthealth.com (or its CMS) to actually
add this tag — this repo gives you the widget and backend to deploy, but I
can't edit Aetna's production site myself.

## Deployment notes

- **Backend**: any host that runs Python works (Render, Railway, Fly.io, an
  EC2/VM, etc.). Set `LLM_PROVIDER`, the matching API key
  (`GEMINI_API_KEY` and/or `OPENAI_API_KEY`), and `ALLOWED_ORIGINS`
  (comma-separated origins allowed to call the API, e.g.
  `https://www.aetnastudenthealth.com`) as environment variables there —
  don't commit `.env`.
- **Widget**: serve `widget/widget.js` as a static file from the same host
  (FastAPI can serve it, or use a CDN/static bucket).
- **CORS**: `ALLOWED_ORIGINS` in `.env` controls which origins may call
  `/api/chat`. Restrict it to the real site's domain in production instead of `*`.
- **Content refresh**: since this scrapes a real third-party site, re-run the
  scraper periodically (or before each deploy) so answers stay current with
  plan-year changes.

## Known limitations

- **No authentication, no rate limiting.** Anyone who can reach the API can
  call it. Fine for local testing/demo; add both before a real pilot.
- **Conversation logging is basic, local, and unencrypted.** Every exchange
  (message, reply, sources, provider, escalation flag) is appended to
  `data/conversations.db` (SQLite, git-ignored) — see `backend/conversation_log.py`.
  This is a dev/QA log, not a compliance-grade store: before any real pilot,
  add encryption at rest, access controls, and a retention policy, and
  confirm with legal/compliance whether logged messages could contain PHI.
- **No waiver/enrollment status lookups.** The bot can explain *how*
  enrollment or a waiver works from the site's public content, but it can't
  check a specific student's status — that would need an authenticated
  student session and a real backend record, neither of which exist here.
- **The system prompt and escalation copy haven't been reviewed by
  legal/compliance/clinical staff** — do that before any real student sees this.

## Project structure

```
scraper/
  urls.py          curated list of pages to scrape
  scrape.py        fetches + cleans page content
backend/
  config.py         loads .env, single source of truth for all settings
  prompts.py        system prompt content, kept separate from routing code
  build_index.py    chunks content + builds TF-IDF index
  retrieval.py      loads index, does similarity search
  safety.py         hard-coded emergency/crisis/abuse escalation check
  providers.py      real provider search via the NPI Registry
  llm.py            provider abstraction (Gemini / OpenAI) + tool-use loop
  conversation_log.py  local SQLite logging of chat exchanges
  app.py            FastAPI app: POST /api/chat, GET /api/providers/search
widget/
  widget.js        embeddable chat widget
  demo.html        local mockup of the real homepage, for previewing the widget
frontend/
  src/App.jsx      pink hero landing + floating chat panel (mirrors the widget), calls the same API
data/
  pages/*.json     scraped page content (tracked in git)
  index.pkl        generated search index (not tracked, rebuild via build_index.py)
  conversations.db logged chat exchanges (not tracked — see Known limitations)
```
