/**
 * Aetna Student Health chatbot widget.
 *
 * Embed on any page with:
 *   <script src="https://your-backend-host/widget/widget.js"
 *           data-api-url="https://your-backend-host/api/chat"></script>
 *
 * Renders a floating chat bubble in the bottom-right corner that expands
 * into a chat panel talking to the FastAPI backend.
 */
(function () {
  "use strict";

  var scriptTag = document.currentScript;
  // Default to an API on the same origin the widget script was loaded from
  // (e.g. the backend serving both /widget/widget.js and /api/chat). Pass
  // data-api-url explicitly when the backend lives on a different host.
  var DEFAULT_API_URL = scriptTag ? new URL("/api/chat", scriptTag.src).href : "/api/chat";
  var API_URL = (scriptTag && scriptTag.getAttribute("data-api-url")) || DEFAULT_API_URL;

  var history = []; // {role, content}

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      if (key === "style") {
        Object.assign(node.style, attrs[key]);
      } else if (key.indexOf("on") === 0) {
        node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
      } else {
        node.setAttribute(key, attrs[key]);
      }
    });
    (children || []).forEach(function (child) {
      node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
    });
    return node;
  }

  var launcher = el(
    "button",
    {
      "aria-label": "Open chat assistant",
      style: {
        position: "fixed",
        bottom: "20px",
        right: "20px",
        width: "60px",
        height: "60px",
        borderRadius: "50%",
        border: "none",
        background: "#7d2e8b",
        color: "#fff",
        fontSize: "26px",
        cursor: "pointer",
        boxShadow: "0 4px 14px rgba(0,0,0,0.25)",
        zIndex: 999999,
      },
    },
    ["💬"]
  );

  var messagesEl = el("div", {
    style: {
      flex: "1",
      overflowY: "auto",
      padding: "12px",
      display: "flex",
      flexDirection: "column",
      gap: "8px",
      background: "#f7f5fa",
    },
  });

  var input = el("input", {
    type: "text",
    placeholder: "Ask about your plan, benefits, or coverage...",
    style: {
      flex: "1",
      border: "1px solid #ccc",
      borderRadius: "18px",
      padding: "8px 14px",
      fontSize: "14px",
      outline: "none",
    },
  });

  var sendBtn = el(
    "button",
    {
      style: {
        border: "none",
        background: "#7d2e8b",
        color: "#fff",
        borderRadius: "18px",
        padding: "8px 16px",
        marginLeft: "8px",
        cursor: "pointer",
        fontSize: "14px",
      },
      onClick: function () {
        sendMessage();
      },
    },
    ["Send"]
  );

  var panel = el(
    "div",
    {
      style: {
        position: "fixed",
        bottom: "90px",
        right: "20px",
        width: "340px",
        maxWidth: "90vw",
        height: "460px",
        maxHeight: "70vh",
        background: "#fff",
        borderRadius: "12px",
        boxShadow: "0 8px 30px rgba(0,0,0,0.3)",
        display: "none",
        flexDirection: "column",
        overflow: "hidden",
        zIndex: 999999,
        fontFamily: "Arial, Helvetica, sans-serif",
      },
    },
    [
      el(
        "div",
        {
          style: {
            background: "#7d2e8b",
            color: "#fff",
            padding: "12px 14px",
            fontWeight: "bold",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          },
        },
        [
          "Aetna Student Health Assistant",
          el(
            "button",
            {
              "aria-label": "Close chat",
              style: {
                background: "none",
                border: "none",
                color: "#fff",
                fontSize: "18px",
                cursor: "pointer",
              },
              onClick: function () {
                togglePanel(false);
              },
            },
            ["✕"]
          ),
        ]
      ),
      messagesEl,
      el(
        "div",
        {
          style: {
            display: "flex",
            padding: "10px",
            borderTop: "1px solid #eee",
            background: "#fff",
          },
        },
        [input, sendBtn]
      ),
    ]
  );

  document.body.appendChild(panel);
  document.body.appendChild(launcher);

  function togglePanel(forceOpen) {
    var isOpen = panel.style.display === "flex";
    var next = typeof forceOpen === "boolean" ? forceOpen : !isOpen;
    panel.style.display = next ? "flex" : "none";
    if (next && messagesEl.children.length === 0) {
      addBubble(
        "assistant",
        "Hi! I can answer questions about Aetna Student Health plans, benefits, and how to use them. What would you like to know?"
      );
    }
  }

  launcher.addEventListener("click", function () {
    togglePanel();
  });

  function addBubble(role, text) {
    var bubble = el(
      "div",
      {
        style: {
          alignSelf: role === "user" ? "flex-end" : "flex-start",
          background: role === "user" ? "#7d2e8b" : "#ffffff",
          color: role === "user" ? "#fff" : "#222",
          border: role === "user" ? "none" : "1px solid #e0dbe5",
          padding: "8px 12px",
          borderRadius: "14px",
          maxWidth: "80%",
          fontSize: "14px",
          lineHeight: "1.4",
          whiteSpace: "pre-wrap",
        },
      },
      [text]
    );
    messagesEl.appendChild(bubble);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return bubble;
  }

  function addSources(sources) {
    if (!sources || sources.length === 0) return;
    var links = sources.map(function (s) {
      return el("a", { href: s.url, target: "_blank", rel: "noopener", style: { color: "#7d2e8b", display: "block", fontSize: "12px" } }, [s.title]);
    });
    var wrap = el(
      "div",
      { style: { alignSelf: "flex-start", fontSize: "12px", color: "#666", maxWidth: "80%" } },
      ["Learn more:"].concat(links)
    );
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function sendMessage() {
    var text = input.value.trim();
    if (!text) return;
    input.value = "";
    addBubble("user", text);
    history.push({ role: "user", content: text });

    var typing = addBubble("assistant", "...");

    fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, history: history.slice(0, -1) }),
    })
      .then(function (res) {
        if (!res.ok) {
          return res
            .json()
            .catch(function () {
              return {};
            })
            .then(function (errData) {
              throw new Error(errData && errData.detail ? errData.detail : "Request failed: " + res.status);
            });
        }
        return res.json();
      })
      .then(function (data) {
        typing.textContent = data.reply;
        history.push({ role: "assistant", content: data.reply });
        addSources(data.sources);
      })
      .catch(function (err) {
        var detail = err && err.message ? err.message : "unknown error";
        typing.textContent = "Sorry, something went wrong: " + detail + ". Please try again or use Contact Us.";
      });
  }

  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter") sendMessage();
  });
})();
