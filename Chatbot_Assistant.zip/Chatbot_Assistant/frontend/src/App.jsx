import { useEffect, useRef, useState } from 'react'
import './App.css'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8731/api/chat'

const GREETING = {
  role: 'assistant',
  content:
    'Hi! I can answer questions about Aetna Student Health plans, benefits, and how to use them. What would you like to know?',
  sources: [],
}

export default function App() {
  const [messages, setMessages] = useState([GREETING])
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [chatOpen, setChatOpen] = useState(false)
  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)

  useEffect(() => {
    if (chatOpen) messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, chatOpen])

  useEffect(() => {
    if (chatOpen) inputRef.current?.focus()
  }, [chatOpen])

  async function sendMessage() {
    const text = input.trim()
    if (!text || sending) return

    const history = messages
      .filter((m) => m.role === 'user' || m.role === 'assistant')
      .map((m) => ({ role: m.role, content: m.content }))

    setMessages((prev) => [...prev, { role: 'user', content: text }])
    setInput('')
    setSending(true)

    try {
      const res = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history }),
      })
      if (!res.ok) {
        let detail = `Request failed (${res.status})`
        try {
          const errData = await res.json()
          if (errData?.detail) detail = errData.detail
        } catch {
          // response body wasn't JSON — keep the generic detail
        }
        throw new Error(detail)
      }
      const data = await res.json()
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: data.reply,
          sources: data.sources || [],
          escalation: data.escalation,
        },
      ])
    } catch (err) {
      const detail = err instanceof Error && err.message ? err.message : 'unknown error'
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: `Sorry, something went wrong: ${detail}. Please try again or use Contact Us.`,
          sources: [],
        },
      ])
    } finally {
      setSending(false)
    }
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter') sendMessage()
  }

  return (
    <div className="chat-page">
      <div className="hero">
        <div className="hero-text">
          <h1>Welcome to Aetna Student Health</h1>
          <p>
            Health plans created with you in mind. We're here to support your
            well-being. With expert care. Extra support. A simple experience.
            Choose your school to get started with enrollment, waiver options,
            and more.
          </p>
        </div>
      </div>

      {chatOpen && (
        <div className="chat-panel">
          <header className="chat-header">
            Aetna Student Health Assistant
            <button className="chat-close" aria-label="Close chat" onClick={() => setChatOpen(false)}>
              ✕
            </button>
          </header>

          <div className="chat-messages">
            {messages.map((m, i) => (
              <div key={i} className={`bubble-row ${m.role}`}>
                <div className={`bubble ${m.role} ${m.escalation ? 'escalation' : ''}`}>
                  {m.content}
                </div>
                {m.sources && m.sources.length > 0 && (
                  <div className="sources">
                    Learn more:
                    {m.sources.map((s) => (
                      <a key={s.url} href={s.url} target="_blank" rel="noopener noreferrer">
                        {s.title}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
            {sending && (
              <div className="bubble-row assistant">
                <div className="bubble assistant typing">...</div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="chat-input-row">
            <input
              ref={inputRef}
              type="text"
              placeholder="Ask about your plan, benefits, or coverage..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={sending}
            />
            <button onClick={sendMessage} disabled={sending}>
              Send
            </button>
          </div>
        </div>
      )}

      <button
        className="chat-launcher"
        aria-label={chatOpen ? 'Close chat' : 'Open chat'}
        onClick={() => setChatOpen((open) => !open)}
      >
        {chatOpen ? '✕' : '💬'}
      </button>
    </div>
  )
}
