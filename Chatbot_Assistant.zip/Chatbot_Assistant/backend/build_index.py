"""
Builds the retrieval index for the chatbot:
1. Reads scraped pages from data/pages/*.json
2. Splits each page's text into overlapping chunks
3. Fits a TF-IDF vectorizer over all chunks
4. Saves chunks + vectorizer + matrix to data/index.pkl

Run this once after scraping, and again any time the scraped content changes.

Usage:
    python backend/build_index.py
"""

import json
import pickle
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
PAGES_DIR = DATA_DIR / "pages"
INDEX_PATH = DATA_DIR / "index.pkl"

CHUNK_SIZE = 800  # characters
CHUNK_OVERLAP = 150


def chunk_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping chunks, breaking on paragraph boundaries where possible."""
    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
    chunks = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 1 <= size:
            current = f"{current}\n{para}".strip()
        else:
            if current:
                chunks.append(current)
            # start new chunk, carrying overlap from the tail of the previous one
            tail = current[-overlap:] if current else ""
            current = f"{tail}\n{para}".strip()
            # if a single paragraph is itself longer than size, hard-split it
            while len(current) > size:
                chunks.append(current[:size])
                current = current[size - overlap:]

    if current:
        chunks.append(current)

    return chunks


def main():
    page_files = sorted(PAGES_DIR.glob("*.json"))
    if not page_files:
        raise SystemExit(f"No scraped pages found in {PAGES_DIR}. Run scraper/scrape.py first.")

    chunks = []  # list of {"url", "title", "text"}
    for path in page_files:
        page = json.loads(path.read_text(encoding="utf-8"))
        for piece in chunk_text(page["text"]):
            if len(piece) < 40:
                continue
            chunks.append({"url": page["url"], "title": page["title"], "text": piece})

    print(f"Built {len(chunks)} chunks from {len(page_files)} pages.")

    corpus = [c["text"] for c in chunks]
    vectorizer = TfidfVectorizer(stop_words="english", max_features=20000, ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(corpus)

    with open(INDEX_PATH, "wb") as f:
        pickle.dump({"chunks": chunks, "vectorizer": vectorizer, "matrix": matrix}, f)

    print(f"Saved index to {INDEX_PATH}")


if __name__ == "__main__":
    main()
