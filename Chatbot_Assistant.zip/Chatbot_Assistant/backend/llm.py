"""
Thin abstraction over the LLM providers the chatbot can answer with.

Supported providers:
- "gemini" (Google Gemini) — default
- "openai" (OpenAI GPT)

Pick the default with the LLM_PROVIDER env var; a request can also override
it per-call (see ChatRequest.provider in backend/app.py).

Both providers are given a search_providers tool backed by the real NPI
Registry (backend/providers.py) so the model can look up an actual doctor,
dentist, or specialist instead of guessing one.
"""

import json
import time
from functools import lru_cache

from fastapi import HTTPException

from backend.config import (
    DEFAULT_PROVIDER,
    GEMINI_API_KEY,
    GEMINI_MODEL,
    OPENAI_API_KEY,
    OPENAI_MODEL,
    VALID_PROVIDERS,
)
from backend.providers import search_providers

MAX_TOOL_ROUNDS = 3  # hard cap so a confused model can't loop forever

MAX_API_RETRIES = 3  # retries for transient Gemini server errors (503, etc.)
RETRY_BACKOFF_SECONDS = 1.5
_RETRYABLE_STATUS_CODES = {500, 502, 503, 504}

PROVIDER_TOOL_DESCRIPTION = (
    "Search for real, licensed healthcare providers by specialty and/or "
    "location, backed by the official NPI Registry. Use this whenever the "
    "user asks to find a doctor, dentist, specialist, or other provider. "
    "A result confirms the provider is real and licensed — it does NOT "
    "confirm they are in-network for the user's specific Aetna Student "
    "Health plan. Always tell the user to verify network status separately "
    "(the Aetna provider directory, or the number on their ID card)."
)


@lru_cache
def _gemini_client():
    from google import genai

    if not GEMINI_API_KEY:
        raise HTTPException(
            status_code=500,
            detail="GEMINI_API_KEY is not set. Add it to your .env file.",
        )
    return genai.Client(api_key=GEMINI_API_KEY)


@lru_cache
def _openai_client():
    from openai import OpenAI

    if not OPENAI_API_KEY:
        raise HTTPException(
            status_code=500,
            detail="OPENAI_API_KEY is not set. Add it to your .env file.",
        )
    return OpenAI(api_key=OPENAI_API_KEY)


_GEMINI_TOOL = {
    "function_declarations": [
        {
            "name": "search_providers",
            "description": PROVIDER_TOOL_DESCRIPTION,
            "parameters": {
                "type": "OBJECT",
                "properties": {
                    "specialty": {"type": "STRING", "description": "e.g. 'Family Medicine', 'Dentist', 'Pediatrics'"},
                    "city": {"type": "STRING"},
                    "state": {"type": "STRING", "description": "Two-letter US state code, e.g. 'MA'"},
                    "postal_code": {"type": "STRING"},
                    "last_name": {"type": "STRING"},
                    "first_name": {"type": "STRING"},
                },
            },
        }
    ]
}

_OPENAI_TOOL = {
    "type": "function",
    "function": {
        "name": "search_providers",
        "description": PROVIDER_TOOL_DESCRIPTION,
        "parameters": {
            "type": "object",
            "properties": {
                "specialty": {"type": "string", "description": "e.g. 'Family Medicine', 'Dentist', 'Pediatrics'"},
                "city": {"type": "string"},
                "state": {"type": "string", "description": "Two-letter US state code, e.g. 'MA'"},
                "postal_code": {"type": "string"},
                "last_name": {"type": "string"},
                "first_name": {"type": "string"},
            },
        },
    },
}


def _gemini_generate_with_retry(client, contents: list[dict], config):
    """Call generate_content, retrying transient server errors (503, etc.)
    with exponential backoff before giving up and raising to the caller."""
    from google.genai import errors as genai_errors

    delay = RETRY_BACKOFF_SECONDS
    for attempt in range(MAX_API_RETRIES):
        is_last_attempt = attempt == MAX_API_RETRIES - 1
        try:
            return client.models.generate_content(model=GEMINI_MODEL, contents=contents, config=config)
        except genai_errors.APIError as exc:
            if exc.code not in _RETRYABLE_STATUS_CODES or is_last_attempt:
                raise HTTPException(status_code=502, detail=f"Gemini API error: {exc}") from exc
        except Exception as exc:  # network failures, etc. — not a genai_errors.APIError
            if is_last_attempt:
                raise HTTPException(status_code=502, detail=f"Gemini request failed: {exc}") from exc
        time.sleep(delay)
        delay *= 2


def _openai_generate_with_retry(client, messages: list[dict]):
    """Call chat.completions.create, retrying transient server errors (503,
    etc.) with exponential backoff before giving up and raising to the caller."""
    import openai

    delay = RETRY_BACKOFF_SECONDS
    for attempt in range(MAX_API_RETRIES):
        is_last_attempt = attempt == MAX_API_RETRIES - 1
        try:
            return client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=messages,
                tools=[_OPENAI_TOOL],
                max_tokens=1024,
            )
        except openai.APIStatusError as exc:
            if exc.status_code not in _RETRYABLE_STATUS_CODES or is_last_attempt:
                raise HTTPException(status_code=502, detail=f"OpenAI API error: {exc}") from exc
        except Exception as exc:  # network failures, etc. — not an openai.APIStatusError
            if is_last_attempt:
                raise HTTPException(status_code=502, detail=f"OpenAI request failed: {exc}") from exc
        time.sleep(delay)
        delay *= 2


def _call_gemini(system: str, messages: list[dict]) -> str:
    from google import genai

    client = _gemini_client()

    # Gemini uses role "model" instead of "assistant", and each message's
    # text goes in a "parts" list rather than a plain "content" string.
    contents = [
        {
            "role": "model" if m["role"] == "assistant" else "user",
            "parts": [{"text": m["content"]}],
        }
        for m in messages
    ]

    config = genai.types.GenerateContentConfig(
        system_instruction=system,
        max_output_tokens=1024,
        tools=[_GEMINI_TOOL],
    )

    for _ in range(MAX_TOOL_ROUNDS):
        response = _gemini_generate_with_retry(client, contents, config)

        parts = response.candidates[0].content.parts if response.candidates else []
        function_calls = [p.function_call for p in parts if p.function_call is not None]

        if not function_calls:
            return (response.text or "").strip()

        contents.append({"role": "model", "parts": parts})
        response_parts = []
        for fc in function_calls:
            try:
                result = search_providers(**(fc.args or {}))
            except TypeError as exc:
                # The model passed an arg search_providers doesn't accept —
                # tell it so via the tool result instead of crashing the turn.
                result = {"error": f"Invalid search_providers arguments: {exc}"}
            response_parts.append({"function_response": {"name": fc.name, "response": {"result": result}}})
        contents.append({"role": "user", "parts": response_parts})

    return "Sorry, I wasn't able to finish that provider search. Please try rephrasing, or use Contact Us."


def _call_openai(system: str, messages: list[dict]) -> str:
    client = _openai_client()

    chat_messages = [{"role": "system", "content": system}] + [
        {"role": m["role"], "content": m["content"]} for m in messages
    ]

    for _ in range(MAX_TOOL_ROUNDS):
        response = _openai_generate_with_retry(client, chat_messages)
        message = response.choices[0].message

        if not message.tool_calls:
            return (message.content or "").strip()

        chat_messages.append(
            {
                "role": "assistant",
                "content": message.content,
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                    }
                    for tc in message.tool_calls
                ],
            }
        )
        for tc in message.tool_calls:
            try:
                args = json.loads(tc.function.arguments or "{}")
                result = search_providers(**args)
            except (TypeError, json.JSONDecodeError) as exc:
                # Malformed args from the model — tell it so via the tool
                # result instead of crashing the turn.
                result = {"error": f"Invalid search_providers arguments: {exc}"}
            chat_messages.append({"role": "tool", "tool_call_id": tc.id, "content": json.dumps(result)})

    return "Sorry, I wasn't able to finish that provider search. Please try rephrasing, or use Contact Us."


def generate_reply(system: str, messages: list[dict], provider: str | None = None) -> str:
    """Generate a reply using the given provider (or DEFAULT_PROVIDER if omitted)."""
    provider = (provider or DEFAULT_PROVIDER).strip().lower()

    if provider == "gemini":
        return _call_gemini(system, messages)
    if provider == "openai":
        return _call_openai(system, messages)

    raise HTTPException(
        status_code=400,
        detail=f"Unknown provider '{provider}'. Valid options: {sorted(VALID_PROVIDERS)}",
    )
