"""
Loads the pre-built TF-IDF index and retrieves the most relevant chunks
for a given user query.
"""

import pickle
from pathlib import Path

from sklearn.metrics.pairwise import cosine_similarity

INDEX_PATH = Path(__file__).resolve().parent.parent / "data" / "index.pkl"


class Retriever:
    def __init__(self, index_path: Path = INDEX_PATH):
        if not index_path.exists():
            raise FileNotFoundError(
                f"No index found at {index_path}. Run backend/build_index.py first."
            )
        with open(index_path, "rb") as f:
            data = pickle.load(f)
        self.chunks = data["chunks"]
        self.vectorizer = data["vectorizer"]
        self.matrix = data["matrix"]

    def search(
        self, query: str, top_k: int = 5, min_score: float = 0.05, max_per_source: int = 2
    ) -> list[dict]:
        query_vec = self.vectorizer.transform([query])
        scores = cosine_similarity(query_vec, self.matrix)[0]
        ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)

        results = []
        per_source_count: dict[str, int] = {}
        for i in ranked:
            if len(results) >= top_k:
                break
            if scores[i] < min_score:
                break
            chunk = self.chunks[i]
            url = chunk["url"]
            if per_source_count.get(url, 0) >= max_per_source:
                continue
            per_source_count[url] = per_source_count.get(url, 0) + 1
            results.append({**chunk, "score": float(scores[i])})
        return results
