"""
Single source of truth for environment-derived configuration.

Loads .env once, here, so every other module can just import the settings
it needs instead of each reaching into os.environ (and instead of app.py
having to import other backend modules after a load_dotenv() call, in a
particular order, just to make sure env vars exist in time).
"""

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

# --- LLM provider selection ---
DEFAULT_PROVIDER = os.environ.get("LLM_PROVIDER", "gemini").strip().lower()
VALID_PROVIDERS = {"gemini", "openai"}

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash")

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")

# --- HTTP / CORS ---
ALLOWED_ORIGINS = [o.strip() for o in os.environ.get("ALLOWED_ORIGINS", "*").split(",")]
