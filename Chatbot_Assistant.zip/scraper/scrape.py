"""
Fetches the curated Aetna Student Health pages and saves cleaned text
content as JSON files under data/pages/, one file per page.

Usage:
    python scraper/scrape.py
"""

import json
import re
import time
from pathlib import Path
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

from urls import FULL_URLS

OUT_DIR = Path(__file__).resolve().parent.parent / "data" / "pages"
OUT_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; AetnaStudentHealthChatbotBuilder/1.0; +https://www.aetnastudenthealth.com/)"
}

# Tags that never contain real page content.
STRIP_TAGS = ["script", "style", "noscript", "svg", "iframe", "nav", "footer", "header"]


def slug_for(url: str) -> str:
    path = urlparse(url).path.strip("/").replace("/", "_") or "index"
    return path.replace(".html", "")


def clean_text(soup: BeautifulSoup) -> str:
    for tag in soup.find_all(STRIP_TAGS):
        tag.decompose()

    main = soup.find("main") or soup.body or soup

    lines = []
    for el in main.find_all(["h1", "h2", "h3", "h4", "li", "p", "td"]):
        text = el.get_text(" ", strip=True)
        if not text:
            continue
        if el.name in ("h1", "h2", "h3", "h4"):
            lines.append(f"\n## {text}\n")
        elif el.name == "li":
            lines.append(f"- {text}")
        else:
            lines.append(text)

    text = "\n".join(lines)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def scrape_page(url: str) -> dict | None:
    try:
        resp = requests.get(url, headers=HEADERS, timeout=20)
        resp.raise_for_status()
    except requests.RequestException as exc:
        print(f"  ! failed: {url} ({exc})")
        return None

    soup = BeautifulSoup(resp.text, "html.parser")
    title_tag = soup.find("title")
    title = title_tag.get_text(strip=True) if title_tag else url

    text = clean_text(soup)
    if len(text) < 50:
        print(f"  ! skipped (too little content): {url}")
        return None

    return {"url": url, "title": title, "text": text}


def main():
    print(f"Scraping {len(FULL_URLS)} pages...")
    ok, failed = 0, 0
    for url in FULL_URLS:
        page = scrape_page(url)
        if page:
            out_path = OUT_DIR / f"{slug_for(url)}.json"
            out_path.write_text(json.dumps(page, indent=2), encoding="utf-8")
            print(f"  + saved {out_path.name} ({len(page['text'])} chars)")
            ok += 1
        else:
            failed += 1
        time.sleep(0.5)  # be polite

    print(f"\nDone. {ok} pages saved, {failed} failed/skipped.")


if __name__ == "__main__":
    main()
