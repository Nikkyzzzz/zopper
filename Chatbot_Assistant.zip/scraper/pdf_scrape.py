"""
Downloads the PDF documents (forms, claim instructions, brochures) linked
from the curated Aetna Student Health pages (scraper/urls.py) and extracts
their text into data/pdf_docs/, one file per PDF, in the same
{"url", "title", "text"} shape as data/pages/ so backend/build_index.py can
chunk and embed them the same way as scraped HTML pages.

Only real embedded-text PDFs are usable this way. Scanned/image-only PDFs
extract to little or no text and are skipped (OCR is out of scope).

Usage:
    python scraper/pdf_scrape.py
"""

import io
import json
import re
import time
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup
from pypdf import PdfReader

from urls import FULL_URLS

OUT_DIR = Path(__file__).resolve().parent.parent / "data" / "pdf_docs"
OUT_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; AetnaStudentHealthChatbotBuilder/1.0; +https://www.aetnastudenthealth.com/)"
}

MAX_PDF_BYTES = 15 * 1024 * 1024  # skip unusually large files
MIN_TEXT_CHARS = 200  # below this, treat as scanned/empty and skip


def slug_for(url: str) -> str:
    name = urlparse(url).path.rsplit("/", 1)[-1]
    name = re.sub(r"\.pdf$", "", name, flags=re.IGNORECASE)
    return re.sub(r"[^a-zA-Z0-9_-]+", "-", name).strip("-").lower() or "pdf"


def discover_pdf_links() -> dict[str, str]:
    """Scan every curated page for <a href="...pdf"> links. Returns {absolute_pdf_url: link_text}."""
    found: dict[str, str] = {}
    for page_url in FULL_URLS:
        try:
            resp = requests.get(page_url, headers=HEADERS, timeout=20)
            resp.raise_for_status()
        except requests.RequestException as exc:
            print(f"  ! failed to scan {page_url} ({exc})")
            continue
        soup = BeautifulSoup(resp.text, "html.parser")
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if href.split("?")[0].lower().endswith(".pdf"):
                pdf_url = urljoin(page_url, href).split("?")[0]
                label = a.get_text(" ", strip=True) or pdf_url
                found.setdefault(pdf_url, label)
        time.sleep(0.3)  # be polite
    return found


def extract_pdf_text(content: bytes) -> str:
    reader = PdfReader(io.BytesIO(content))
    pages = []
    for page in reader.pages:
        text = page.extract_text() or ""
        if text.strip():
            pages.append(text.strip())
    return "\n\n".join(pages)


def scrape_pdf(url: str, label: str) -> dict | None:
    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        resp.raise_for_status()
    except requests.RequestException as exc:
        print(f"  ! failed: {url} ({exc})")
        return None

    if len(resp.content) > MAX_PDF_BYTES:
        print(f"  ! skipped (too large, {len(resp.content)} bytes): {url}")
        return None

    try:
        text = extract_pdf_text(resp.content)
    except Exception as exc:
        print(f"  ! failed to parse PDF: {url} ({exc})")
        return None

    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if len(text) < MIN_TEXT_CHARS:
        print(f"  ! skipped (little/no extractable text, likely scanned): {url}")
        return None

    return {"url": url, "title": label, "text": text}


def main():
    print("Discovering PDF links across curated pages...")
    pdf_links = discover_pdf_links()
    print(f"Found {len(pdf_links)} unique PDFs.\n")

    ok, failed = 0, 0
    for url, label in pdf_links.items():
        page = scrape_pdf(url, label)
        if page:
            out_path = OUT_DIR / f"{slug_for(url)}.json"
            out_path.write_text(json.dumps(page, indent=2), encoding="utf-8")
            print(f"  + saved {out_path.name} ({len(page['text'])} chars)")
            ok += 1
        else:
            failed += 1
        time.sleep(0.3)  # be polite

    print(f"\nDone. {ok} PDFs saved, {failed} failed/skipped.")


if __name__ == "__main__":
    main()
