"""
Curated list of Aetna Student Health pages to scrape for the chatbot's
knowledge base. This is a fixed allowlist (not an open crawl) so we only
pull pages relevant to student Q&A and stay light on the site.
"""

BASE = "https://www.aetnastudenthealth.com"

PAGES = [
    "/en/index.html",
    "/en/contact-us.html",
    "/en/about-us.html",
    "/en/landing/insurance-basics.html",
    "/en/insurance-basics.html",
    "/en/insurance-basics/understanding-insurance.html",
    "/en/insurance-basics/insurance-international-students.html",
    "/en/insurance-basics/faqs.html",
    "/en/insurance-basics/videos.html",
    "/en/how-to-use-your-plan.html",
    "/en/get-id-card.html",
    "/en/dental.html",
    "/en/vision.html",
    "/en/telemedicine.html",
    "/en/prescriptions.html",
    "/en/specialty-pharmacy.html",
    "/en/additional-benefits.html",
    "/en/health-wellness-discounts.html",
    "/en/travel-assistance.html",
    "/en/plan-documents.html",
    "/en/resources-claims-forms.html",
    "/en/surprise-bills.html",
    "/en/health-app.html",
    "/en/accessibility-services.html",
    "/en/nondiscrimination-notice.html",
    "/en/health-data-privacy.html",
    "/en/health-data-access.html",
    "/en/landing/find-doctor.html",
    "/en/landing/find-pharmacy.html",
    "/en/landing/find-dental.html",
    "/en/landing/find-vision.html",
]

FULL_URLS = [BASE + p for p in PAGES]
