"""
Thin abstraction over the LLM providers the chatbot can answer with.

Supported providers:
- "gemini" (Google Gemini) — default
- "openai" (OpenAI GPT)

Pick the default with the LLM_PROVIDER env var; a request can also override
it per-call (see ChatRequest.provider in backend/app.py).

Both providers are given a search_providers tool backed by the real NPI
Registry (backend/providers.py) so the model can look up an actual doctor,
dentist, or specialist instead of guessing one.
"""

import json
import time
from functools import lru_cache

from fastapi import HTTPException

from backend.config import (
    DEFAULT_PROVIDER,
    GEMINI_API_KEY,
    GEMINI_MODEL,
    OPENAI_API_KEY,
    OPENAI_MODEL,
    VALID_PROVIDERS,
)
from backend.errors import ProviderError
from backend.providers import search_providers

MAX_TOOL_ROUNDS = 3  # hard cap so a confused model can't loop forever

# Low, not zero: this bot answers from retrieved context and should reproduce
# specifics (required fields, mandatory numbers, warnings) consistently
# instead of varying what it includes between otherwise-identical requests.
CHAT_TEMPERATURE = 0.2

MAX_API_RETRIES = 3  # retries for transient Gemini server errors (503, etc.)
RETRY_BACKOFF_SECONDS = 1.5
_RETRYABLE_STATUS_CODES = {500, 502, 503, 504}

PROVIDER_TOOL_DESCRIPTION = (
    "Search for real, licensed healthcare providers by specialty and/or "
    "location, backed by the official NPI Registry. Use this whenever the "
    "user asks to find a doctor, dentist, specialist, or other provider. "
    "A result confirms the provider is real and licensed — it does NOT "
    "confirm they are in-network for the user's specific Aetna Student "
    "Health plan. Always tell the user to verify network status separately "
    "(the Aetna provider directory, or the number on their ID card)."
)


@lru_cache
def _gemini_client():
    from google import genai

    if not GEMINI_API_KEY:
        raise ProviderError(
            status_code=500,
            detail="GEMINI_API_KEY is not set. Add it to your .env file.",
        )
    return genai.Client(api_key=GEMINI_API_KEY)


@lru_cache
def _openai_client():
    from openai import OpenAI

    if not OPENAI_API_KEY:
        raise ProviderError(
            status_code=500,
            detail="OPENAI_API_KEY is not set. Add it to your .env file.",
        )
    return OpenAI(api_key=OPENAI_API_KEY)


_GEMINI_TOOL = {
    "function_declarations": [
        {
            "name": "search_providers",
            "description": PROVIDER_TOOL_DESCRIPTION,
            "parameters": {
                "type": "OBJECT",
                "properties": {
                    "specialty": {"type": "STRING", "description": "e.g. 'Family Medicine', 'Dentist', 'Pediatrics'"},
                    "city": {"type": "STRING"},
                    "state": {"type": "STRING", "description": "Two-letter US state code, e.g. 'MA'"},
                    "postal_code": {"type": "STRING"},
                    "last_name": {"type": "STRING"},
                    "first_name": {"type": "STRING"},
                },
            },
        }
    ]
}

_OPENAI_TOOL = {
    "type": "function",
    "function": {
        "name": "search_providers",
        "description": PROVIDER_TOOL_DESCRIPTION,
        "parameters": {
            "type": "object",
            "properties": {
                "specialty": {"type": "string", "description": "e.g. 'Family Medicine', 'Dentist', 'Pediatrics'"},
                "city": {"type": "string"},
                "state": {"type": "string", "description": "Two-letter US state code, e.g. 'MA'"},
                "postal_code": {"type": "string"},
                "last_name": {"type": "string"},
                "first_name": {"type": "string"},
            },
        },
    },
}


def _gemini_generate_with_retry(client, contents: list[dict], config, stream: bool = False):
    """Call generate_content (or generate_content_stream), retrying transient
    server errors (503, etc.) with exponential backoff before giving up and
    raising to the caller. When streaming, only opening the stream is
    retried: a failure mid-stream surfaces while iterating."""
    from google.genai import errors as genai_errors

    generate = client.models.generate_content_stream if stream else client.models.generate_content
    delay = RETRY_BACKOFF_SECONDS
    for attempt in range(MAX_API_RETRIES):
        is_last_attempt = attempt == MAX_API_RETRIES - 1
        try:
            return generate(model=GEMINI_MODEL, contents=contents, config=config)
        except genai_errors.APIError as exc:
            if exc.code not in _RETRYABLE_STATUS_CODES or is_last_attempt:
                raise ProviderError(status_code=502, detail=f"Gemini API error: {exc}") from exc
        except Exception as exc:  # network failures, etc. — not a genai_errors.APIError
            if is_last_attempt:
                raise ProviderError(status_code=502, detail=f"Gemini request failed: {exc}") from exc
        time.sleep(delay)
        delay *= 2


def _openai_generate_with_retry(client, messages: list[dict], stream: bool = False):
    """Call chat.completions.create, retrying transient server errors (503,
    etc.) with exponential backoff before giving up and raising to the caller.
    When streaming, only opening the stream is retried: a failure mid-stream
    surfaces while iterating."""
    import openai

    delay = RETRY_BACKOFF_SECONDS
    for attempt in range(MAX_API_RETRIES):
        is_last_attempt = attempt == MAX_API_RETRIES - 1
        try:
            return client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=messages,
                tools=[_OPENAI_TOOL],
                max_tokens=1024,
                temperature=CHAT_TEMPERATURE,
                stream=stream,
            )
        except openai.APIStatusError as exc:
            if exc.status_code not in _RETRYABLE_STATUS_CODES or is_last_attempt:
                raise ProviderError(status_code=502, detail=f"OpenAI API error: {exc}") from exc
        except Exception as exc:  # network failures, etc. — not an openai.APIStatusError
            if is_last_attempt:
                raise ProviderError(status_code=502, detail=f"OpenAI request failed: {exc}") from exc
        time.sleep(delay)
        delay *= 2


TOOL_LIMIT_MESSAGE = "Sorry, I wasn't able to finish that provider search. Please try rephrasing, or use Contact Us."


def _gemini_request(system: str, messages: list[dict]):
    from google import genai

    # Gemini uses role "model" instead of "assistant", and each message's
    # text goes in a "parts" list rather than a plain "content" string.
    contents = [
        {
            "role": "model" if m["role"] == "assistant" else "user",
            "parts": [{"text": m["content"]}],
        }
        for m in messages
    ]

    config = genai.types.GenerateContentConfig(
        system_instruction=system,
        max_output_tokens=1024,
        tools=[_GEMINI_TOOL],
        temperature=CHAT_TEMPERATURE,
    )
    return contents, config


def _gemini_tool_results(function_calls) -> list[dict]:
    response_parts = []
    for fc in function_calls:
        try:
            result = search_providers(**(fc.args or {}))
        except TypeError as exc:
            # The model passed an arg search_providers doesn't accept —
            # tell it so via the tool result instead of crashing the turn.
            result = {"error": f"Invalid search_providers arguments: {exc}"}
        response_parts.append({"function_response": {"name": fc.name, "response": {"result": result}}})
    return response_parts


def _call_gemini(system: str, messages: list[dict]) -> str:
    client = _gemini_client()
    contents, config = _gemini_request(system, messages)

    for _ in range(MAX_TOOL_ROUNDS):
        response = _gemini_generate_with_retry(client, contents, config)

        parts = response.candidates[0].content.parts if response.candidates else []
        function_calls = [p.function_call for p in parts if p.function_call is not None]

        if not function_calls:
            return (response.text or "").strip()

        contents.append({"role": "model", "parts": parts})
        contents.append({"role": "user", "parts": _gemini_tool_results(function_calls)})

    return TOOL_LIMIT_MESSAGE


def _openai_tool_result(arguments: str | None):
    try:
        return search_providers(**json.loads(arguments or "{}"))
    except (TypeError, json.JSONDecodeError) as exc:
        # Malformed args from the model — tell it so via the tool
        # result instead of crashing the turn.
        return {"error": f"Invalid search_providers arguments: {exc}"}


def _call_openai(system: str, messages: list[dict]) -> str:
    client = _openai_client()

    chat_messages = [{"role": "system", "content": system}] + [
        {"role": m["role"], "content": m["content"]} for m in messages
    ]

    for _ in range(MAX_TOOL_ROUNDS):
        response = _openai_generate_with_retry(client, chat_messages)
        message = response.choices[0].message

        if not message.tool_calls:
            return (message.content or "").strip()

        chat_messages.append(
            {
                "role": "assistant",
                "content": message.content,
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                    }
                    for tc in message.tool_calls
                ],
            }
        )
        for tc in message.tool_calls:
            result = _openai_tool_result(tc.function.arguments)
            chat_messages.append({"role": "tool", "tool_call_id": tc.id, "content": json.dumps(result)})

    return TOOL_LIMIT_MESSAGE


# --- Streaming versions ---
# Same tool loop as above, but each piece of text is yielded as soon as the
# provider sends it, so the browser can show the reply while it's written.
# If the model calls search_providers, the tool runs between rounds and the
# answer carries on in the same stream.


def _stream_gemini(system: str, messages: list[dict]):
    client = _gemini_client()
    contents, config = _gemini_request(system, messages)
    wrote_text = False

    for _ in range(MAX_TOOL_ROUNDS):
        model_parts, function_calls = [], []
        round_started = False
        for chunk in _gemini_generate_with_retry(client, contents, config, stream=True):
            candidate = chunk.candidates[0] if chunk.candidates else None
            for part in (candidate.content.parts or []) if candidate and candidate.content else []:
                model_parts.append(part)
                if part.function_call is not None:
                    function_calls.append(part.function_call)
                elif part.text:
                    if wrote_text and not round_started:
                        yield "\n\n"  # keep text from before and after a tool call apart
                    round_started = wrote_text = True
                    yield part.text

        if not function_calls:
            return
        contents.append({"role": "model", "parts": model_parts})
        contents.append({"role": "user", "parts": _gemini_tool_results(function_calls)})

    yield TOOL_LIMIT_MESSAGE


def _stream_openai(system: str, messages: list[dict]):
    client = _openai_client()
    chat_messages = [{"role": "system", "content": system}] + [
        {"role": m["role"], "content": m["content"]} for m in messages
    ]
    wrote_text = False

    for _ in range(MAX_TOOL_ROUNDS):
        content_parts = []
        tool_calls: dict[int, dict] = {}  # streamed in fragments, keyed by index
        for chunk in _openai_generate_with_retry(client, chat_messages, stream=True):
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            if delta.content:
                if wrote_text and not content_parts:
                    yield "\n\n"  # keep text from before and after a tool call apart
                content_parts.append(delta.content)
                wrote_text = True
                yield delta.content
            for tc in delta.tool_calls or []:
                call = tool_calls.setdefault(tc.index, {"id": None, "name": "", "arguments": ""})
                if tc.id:
                    call["id"] = tc.id
                if tc.function and tc.function.name:
                    call["name"] += tc.function.name
                if tc.function and tc.function.arguments:
                    call["arguments"] += tc.function.arguments

        if not tool_calls:
            return
        calls = [tool_calls[i] for i in sorted(tool_calls)]
        chat_messages.append(
            {
                "role": "assistant",
                "content": "".join(content_parts) or None,
                "tool_calls": [
                    {"id": c["id"], "type": "function", "function": {"name": c["name"], "arguments": c["arguments"]}}
                    for c in calls
                ],
            }
        )
        for c in calls:
            chat_messages.append({"role": "tool", "tool_call_id": c["id"], "content": json.dumps(_openai_tool_result(c["arguments"]))})

    yield TOOL_LIMIT_MESSAGE


CARD_FIELDS = [
    "member_name",
    "member_id",
    "plan_name",
    "group_number",
    "payer_number",
    "pcp_election",
    "issuer_name",
    "phone_number",
]

CARD_EXTRACTION_PROMPT = (
    "Extract fields from this health insurance ID card image. Respond with "
    "ONLY a JSON object (no markdown, no extra text) with exactly these keys "
    f"(use null for any field not visible on the card): {', '.join(CARD_FIELDS)}."
)


def _parse_card_json(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
        cleaned = cleaned.strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=502, detail="Couldn't read structured data from that card image. Try a clearer photo.") from exc
    return {field: data.get(field) for field in CARD_FIELDS}


def _extract_card_gemini(image_bytes: bytes, mime_type: str) -> dict:
    from google import genai
    from google.genai import errors as genai_errors

    client = _gemini_client()
    part = genai.types.Part.from_bytes(data=image_bytes, mime_type=mime_type)
    try:
        response = client.models.generate_content(model=GEMINI_MODEL, contents=[part, CARD_EXTRACTION_PROMPT])
    except genai_errors.APIError as exc:
        raise ProviderError(status_code=502, detail=f"Gemini API error: {exc}") from exc
    return _parse_card_json(response.text or "")


def _extract_card_openai(image_bytes: bytes, mime_type: str) -> dict:
    import base64

    import openai

    client = _openai_client()
    b64 = base64.b64encode(image_bytes).decode("utf-8")
    try:
        response = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": CARD_EXTRACTION_PROMPT},
                        {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{b64}"}},
                    ],
                }
            ],
            max_tokens=500,
        )
    except openai.APIStatusError as exc:
        raise ProviderError(status_code=502, detail=f"OpenAI API error: {exc}") from exc
    return _parse_card_json(response.choices[0].message.content or "")


def extract_card_details(image_bytes: bytes, mime_type: str, provider: str | None = None) -> dict:
    """Read a photo of an insurance ID card and extract CARD_FIELDS from it.

    Nothing here is persisted — the image and extracted fields are processed
    in memory and returned directly to the caller."""
    provider = (provider or DEFAULT_PROVIDER).strip().lower()

    if provider == "gemini":
        return _extract_card_gemini(image_bytes, mime_type)
    if provider == "openai":
        return _extract_card_openai(image_bytes, mime_type)

    raise HTTPException(
        status_code=400,
        detail=f"Unknown provider '{provider}'. Valid options: {sorted(VALID_PROVIDERS)}",
    )


def stream_reply(system: str, messages: list[dict], provider: str | None = None):
    """Like generate_reply, but yields the reply in pieces as it's generated."""
    provider = (provider or DEFAULT_PROVIDER).strip().lower()

    if provider == "gemini":
        return _stream_gemini(system, messages)
    if provider == "openai":
        return _stream_openai(system, messages)

    raise HTTPException(
        status_code=400,
        detail=f"Unknown provider '{provider}'. Valid options: {sorted(VALID_PROVIDERS)}",
    )


def generate_reply(system: str, messages: list[dict], provider: str | None = None) -> str:
    """Generate a reply using the given provider (or DEFAULT_PROVIDER if omitted)."""
    provider = (provider or DEFAULT_PROVIDER).strip().lower()

    if provider == "gemini":
        return _call_gemini(system, messages)
    if provider == "openai":
        return _call_openai(system, messages)

    raise HTTPException(
        status_code=400,
        detail=f"Unknown provider '{provider}'. Valid options: {sorted(VALID_PROVIDERS)}",
    )
