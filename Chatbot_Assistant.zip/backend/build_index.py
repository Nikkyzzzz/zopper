"""
Builds the retrieval index for the chatbot:
1. Reads knowledge-base pages from data/pages/*.json (scraped site content),
   data/waiver/*.json (waiver-process knowledge, internal + external), and
   data/pdf_docs/*.json (text extracted from linked PDFs/forms by
   scraper/pdf_scrape.py)
2. Splits each page's text into overlapping chunks
3. Embeds every chunk (backend/embeddings.py) into a semantic vector space —
   this is why questions can match content that doesn't share keywords with
   it, unlike the earlier TF-IDF approach
4. Saves chunks + embedding matrix + which provider/model built them to
   data/index.pkl

Run this once after scraping, and again any time the scraped content
changes (or you deliberately want to switch EMBEDDING_PROVIDER — that
requires a full rebuild, since query embeddings must come from the same
model as the indexed chunks).

Usage (run as a module — it imports from the backend package):
    python -m backend.build_index
"""

import json
import pickle
from pathlib import Path

import numpy as np

from backend.config import EMBEDDING_PROVIDER, GEMINI_EMBEDDING_MODEL, OPENAI_EMBEDDING_MODEL
from backend.embeddings import embed_texts

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
PAGES_DIR = DATA_DIR / "pages"
WAIVER_DIR = DATA_DIR / "waiver"
PDF_DIR = DATA_DIR / "pdf_docs"
INDEX_PATH = DATA_DIR / "index.pkl"

CHUNK_SIZE = 800  # characters
CHUNK_OVERLAP = 150


def chunk_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping chunks, breaking on paragraph boundaries where possible."""
    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
    chunks = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 1 <= size:
            current = f"{current}\n{para}".strip()
        else:
            if current:
                chunks.append(current)
            # start new chunk, carrying overlap from the tail of the previous one
            tail = current[-overlap:] if current else ""
            current = f"{tail}\n{para}".strip()
            # if a single paragraph is itself longer than size, hard-split it
            while len(current) > size:
                chunks.append(current[:size])
                current = current[size - overlap:]

    if current:
        chunks.append(current)

    return chunks


def main():
    page_files = sorted(PAGES_DIR.glob("*.json")) + sorted(WAIVER_DIR.glob("*.json")) + sorted(PDF_DIR.glob("*.json"))
    if not page_files:
        raise SystemExit(f"No knowledge-base pages found in {PAGES_DIR}, {WAIVER_DIR}, or {PDF_DIR}. Run scraper/scrape.py first.")

    chunks = []  # list of {"url", "title", "text"}
    for path in page_files:
        page = json.loads(path.read_text(encoding="utf-8"))
        for piece in chunk_text(page["text"]):
            if len(piece) < 40:
                continue
            chunks.append({"url": page["url"], "title": page["title"], "text": piece})

    print(f"Built {len(chunks)} chunks from {len(page_files)} pages.")

    embedding_model = GEMINI_EMBEDDING_MODEL if EMBEDDING_PROVIDER == "gemini" else OPENAI_EMBEDDING_MODEL
    print(f"Embedding chunks with provider={EMBEDDING_PROVIDER!r} model={embedding_model!r}...")
    vectors = embed_texts([c["text"] for c in chunks], provider=EMBEDDING_PROVIDER)
    matrix = np.array(vectors)
    print(f"Got {matrix.shape[0]} embeddings of dimension {matrix.shape[1]}.")

    with open(INDEX_PATH, "wb") as f:
        pickle.dump(
            {
                "chunks": chunks,
                "matrix": matrix,
                "embedding_provider": EMBEDDING_PROVIDER,
                "embedding_model": embedding_model,
            },
            f,
        )

    print(f"Saved index to {INDEX_PATH}")


if __name__ == "__main__":
    main()
