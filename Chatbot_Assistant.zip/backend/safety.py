"""
Hard-coded safety/escalation layer.

Checks the user's message for medical emergencies, crisis/self-harm, and
abuse/assault before any model call is made. This runs as plain Python —
deliberately not something the model decides — so it can't be argued around
by anything earlier in the conversation and doesn't depend on the model
reliably following an instruction.

If a category matches, a fixed, non-generated reply is returned and the
caller should skip the model call entirely.
"""

import re

# Checked in order of urgency: a message matching an earlier category short
# circuits, so put the more urgent/specific patterns first.
_CATEGORIES = [
    (
        "emergency",
        re.compile(
            r"\b(heart attack|can'?t breathe|not breathing|choking|severe bleeding|"
            r"overdos(e|ing)|stroke|unconscious|unresponsive|seizure|"
            r"chest pain|calling 911|need an? ambulance)\b",
            re.IGNORECASE,
        ),
        "This sounds like it could be a medical emergency. Please call 911 "
        "(or your local emergency number) right away, or go to the nearest "
        "emergency room. I'm not able to help with emergencies myself.",
    ),
    (
        "crisis",
        re.compile(
            r"\b(suicid\w*|kill myself|end my life|want to die|hurt myself|"
            r"self.?harm|no reason to live|can'?t go on|"
            r"mental health crisis|having a crisis|in crisis)\b",
            re.IGNORECASE,
        ),
        "I'm really sorry you're going through this. Please reach out right "
        "now to the 988 Suicide & Crisis Lifeline (call or text 988), or the "
        "Crisis Text Line (text HOME to 741741). Both are free, confidential, "
        "and available 24/7. If you're in immediate danger, please call 911.",
    ),
    (
        "abuse",
        re.compile(
            r"\b(being abused|domestic violence|being assaulted|"
            r"sexual assault|raped|being trafficked)\b",
            re.IGNORECASE,
        ),
        "I'm sorry this is happening to you. Please consider reaching out to "
        "the National Domestic Violence Hotline (1-800-799-7233) or RAINN's "
        "National Sexual Assault Hotline (1-800-656-4673). Both are free, "
        "confidential, and available 24/7. If you're in immediate danger, "
        "please call 911.",
    ),
]


def check_safety(message: str) -> str | None:
    """Return a fixed escalation reply if the message matches a safety
    category, otherwise None (meaning it's safe to send to the model)."""
    for _category, pattern, reply in _CATEGORIES:
        if pattern.search(message):
            return reply
    return None
