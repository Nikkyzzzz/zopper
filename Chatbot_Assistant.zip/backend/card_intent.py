"""
Detects when a user's message is asking about something printed on their own
insurance ID card (member ID, group number, payer number, etc.) — details
the knowledge base can never answer since they're personal, not site content.

When this matches, the chat response includes a suggestion to use the
POST /api/extract-card upload feature instead of the model guessing or
just saying "I don't know." Deliberately a plain regex, not an LLM
judgment call, so the suggestion always appears for these questions.

Mentioning "my card"/"ID card" alone isn't enough: "how can I access my
insurance ID card" is a how-to question the knowledge base already answers
(the site explains how to request/view/download it), there is nothing to
extract from an upload yet. Only the personal-detail patterns (member ID,
group number, etc.) or a card mention NOT phrased as "how do I get/access/
download/obtain it" should trigger the upload suggestion.
"""

import re

_PERSONAL_DETAIL_PATTERN = re.compile(
    r"\b(member\s*id|member\s*number|group\s*number|group\s*#|payer\s*number|payer\s*#|"
    r"policy\s*number|pcp\s*election)\b",
    re.IGNORECASE,
)

_CARD_REFERENCE_PATTERN = re.compile(
    r"\b(my\s*(insurance\s*)?card|id\s*card|insurance\s*card)\b",
    re.IGNORECASE,
)

_OBTAIN_CARD_PATTERN = re.compile(
    r"\b(how\s*(can|do|to)\s*i\s*(access|get|download|receive|request|find|obtain)|"
    r"where\s*(can|do)\s*i\s*(get|find|access|download)|"
    r"how\s*to\s*(get|access|download|obtain|request))\b",
    re.IGNORECASE,
)


def mentions_card_details(message: str) -> bool:
    if _PERSONAL_DETAIL_PATTERN.search(message):
        return True
    return bool(_CARD_REFERENCE_PATTERN.search(message)) and not _OBTAIN_CARD_PATTERN.search(message)
