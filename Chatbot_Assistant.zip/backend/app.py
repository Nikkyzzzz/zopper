"""
FastAPI backend for the Aetna Student Health chatbot.

Exposes POST /api/chat, which:
0. Runs a hard-coded safety/escalation check first (backend/safety.py) for
   medical emergencies, crisis/self-harm, and abuse — if triggered, a fixed
   reply is returned immediately and the model is never called.
1. Otherwise retrieves the most relevant chunks of scraped site content for
   the user's message (embedding cosine similarity, see backend/retrieval.py).
2. Sends those chunks + conversation history to an LLM (Gemini or OpenAI,
   see backend/llm.py) as grounding context. The model also has a
   search_providers tool backed by the real NPI Registry (backend/providers.py).
3. Returns the model's answer plus the source pages it drew on.

POST /api/chat/stream does the same but streams the reply as it's written,
which is what the widget and React app use.

Also exposes GET /api/providers/search for direct provider lookups without
a model call, GET /api/schools for the waiver walkthrough's school list, and
POST /api/extract-card for reading an uploaded ID card.

Run with:
    uvicorn backend.app:app --reload --port 8731
"""

import json
import logging
import threading
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from backend import llm
from backend.card_intent import mentions_card_details
from backend.config import ALLOWED_ORIGINS
from backend.conversation_log import log_exchange
from backend.errors import PUBLIC_MESSAGE, ProviderError
from backend.prompts import SYSTEM_PROMPT
from backend.providers import search_providers
from backend.retrieval import Retriever
from backend.safety import check_safety
from backend.schools import SCHOOLS

logger = logging.getLogger("aetna.chat")

app = FastAPI(title="Aetna Student Health Chatbot API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_methods=["POST", "GET", "OPTIONS"],
    allow_headers=["*"],
)

@app.exception_handler(ProviderError)
def provider_error_handler(request, exc: ProviderError):
    # Full provider message (bad key, quota, outage) for whoever runs the
    # server; a plain message for the student.
    logger.error("AI provider error on %s: %s", request.url.path, exc.detail)
    return JSONResponse(status_code=exc.status_code, content={"detail": PUBLIC_MESSAGE})


WIDGET_DIR = Path(__file__).resolve().parent.parent / "widget"
if WIDGET_DIR.exists():
    app.mount("/widget", StaticFiles(directory=WIDGET_DIR), name="widget")

_retriever: Retriever | None = None
_retriever_lock = threading.Lock()


def get_retriever() -> Retriever:
    global _retriever
    if _retriever is None:
        with _retriever_lock:
            if _retriever is None:  # re-check: another request may have built it while we waited
                try:
                    _retriever = Retriever()
                except FileNotFoundError as exc:
                    raise HTTPException(
                        status_code=500,
                        detail="Knowledge base index not found. Run backend/build_index.py first.",
                    ) from exc
    return _retriever


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(..., min_length=1, max_length=4000)


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    history: list[ChatMessage] = Field(default_factory=list, max_length=20)
    provider: Literal["gemini", "openai"] | None = Field(
        default=None,
        description="Override the default LLM provider for this request (gemini or openai).",
    )

    @field_validator("message")
    @classmethod
    def message_not_blank(cls, v: str) -> str:
        stripped = v.strip()
        if not stripped:
            raise ValueError("message must not be blank")
        return stripped


class Source(BaseModel):
    title: str
    url: str


class ChatResponse(BaseModel):
    reply: str
    sources: list[Source]
    escalation: bool = Field(
        default=False,
        description="True when the reply came from the hard-coded safety layer, not the model.",
    )
    suggest_card_upload: bool = Field(
        default=False,
        description="True when the user's message asked about something printed on their own ID card "
        "(member ID, group number, etc.) — the UI should surface the upload-card option.",
    )


class ProviderResult(BaseModel):
    npi: str | None = None
    name: str
    credential: str = ""
    specialty: str = ""
    address: str = ""
    phone: str = ""


class CardDetails(BaseModel):
    member_name: str | None = None
    member_id: str | None = None
    plan_name: str | None = None
    group_number: str | None = None
    payer_number: str | None = None
    pcp_election: str | None = None
    issuer_name: str | None = None
    phone_number: str | None = None


MAX_CARD_IMAGE_BYTES = 8 * 1024 * 1024  # 8MB
MAX_CARD_PDF_BYTES = 15 * 1024 * 1024  # 15MB — Aetna emails the card as a PDF (see get-id-card.html)


def _pdf_first_page_to_png(pdf_bytes: bytes) -> bytes:
    """Render a PDF's first page to a PNG so it can go through the same
    image-based vision extraction as a photo — neither provider's chat
    vision input accepts raw PDF bytes the way it accepts an image."""
    import fitz  # PyMuPDF

    try:
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Couldn't open that PDF. Please try a different file.") from exc

    if doc.page_count == 0:
        raise HTTPException(status_code=400, detail="That PDF has no pages.")

    # 2x zoom for a sharper render — ID card text is small and dense.
    pix = doc[0].get_pixmap(matrix=fitz.Matrix(2, 2))
    return pix.tobytes("png")


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/")
def root():
    return {"status": "ok", "message": "Aetna Student Health Chatbot API. See /api/health and /api/chat."}


@app.get("/api/schools")
def get_schools():
    """Demo dataset of university-specific waiver requirements, used to drive
    the school-selection step in the waiver-eligibility walkthrough. Only
    "ut-austin", "ut-dallas", and "emory" are real, verified policies — see backend/schools.py."""
    return SCHOOLS


@app.get("/api/providers/search", response_model=list[ProviderResult])
def providers_search(
    specialty: str = "",
    city: str = "",
    state: str = "",
    postal_code: str = "",
    last_name: str = "",
    first_name: str = "",
):
    """Direct REST access to the same NPI Registry lookup the chat tool
    uses — handy for testing without spending a model call."""
    return search_providers(
        specialty=specialty, city=city, state=state,
        postal_code=postal_code, last_name=last_name, first_name=first_name,
    )


@app.post("/api/extract-card", response_model=CardDetails)
async def extract_card(file: UploadFile = File(...), provider: Literal["gemini", "openai"] | None = None):
    """Read a photo (or PDF) of an insurance ID card and extract its fields
    using the LLM provider's vision support. Nothing here is persisted — the
    image and extracted fields are processed in memory and returned
    directly; they are never written to disk, the conversation log, or
    anywhere else."""
    content_type = file.content_type or ""
    is_pdf = content_type == "application/pdf"
    if not (content_type.startswith("image/") or is_pdf):
        raise HTTPException(status_code=400, detail="Please upload an image (JPEG, PNG, etc.) or a PDF of your card.")

    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(status_code=400, detail="The uploaded file was empty.")

    if is_pdf:
        if len(file_bytes) > MAX_CARD_PDF_BYTES:
            raise HTTPException(status_code=413, detail="PDF is too large (max 15MB).")
        image_bytes = _pdf_first_page_to_png(file_bytes)
        mime_type = "image/png"
    else:
        if len(file_bytes) > MAX_CARD_IMAGE_BYTES:
            raise HTTPException(status_code=413, detail="Image is too large (max 8MB).")
        image_bytes = file_bytes
        mime_type = content_type

    try:
        fields = llm.extract_card_details(image_bytes, mime_type, provider=provider)
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error extracting card details")
        raise HTTPException(status_code=502, detail="Couldn't read that card image. Please try again.")

    return CardDetails(**fields)


def _prepare_chat(req: ChatRequest):
    """Everything /api/chat and /api/chat/stream do before the model call.

    Returns (escalation_reply, messages, sources, suggest_card_upload); when
    escalation_reply is set, the model must not be called at all.
    """
    # Hard-coded safety layer runs before any model call, unconditionally —
    # so it can't be argued around and doesn't depend on the model reliably
    # following an instruction.
    escalation_reply = check_safety(req.message)
    if escalation_reply:
        log_exchange(req.message, escalation_reply, sources=[], provider=None, escalation=True)
        return escalation_reply, None, [], False

    retriever = get_retriever()

    results = retriever.search(req.message, top_k=6)

    if results:
        context_block = "\n\n---\n\n".join(
            f"Source: {r['title']} ({r['url']})\n{r['text']}" for r in results
        )
    else:
        logger.info("No knowledge-base matches for query: %r", req.message)
        context_block = "(No relevant content found in the knowledge base for this question.)"

    user_content = f"Context:\n{context_block}\n\nUser question: {req.message}"

    messages = [{"role": m.role, "content": m.content} for m in req.history]
    messages.append({"role": "user", "content": user_content})

    seen = set()
    sources = []
    for r in results:
        if r["url"] not in seen:
            seen.add(r["url"])
            sources.append(Source(title=r["title"], url=r["url"]))

    return None, messages, sources, mentions_card_details(req.message)


UNAVAILABLE = PUBLIC_MESSAGE


@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    escalation_reply, messages, sources, suggest_card_upload = _prepare_chat(req)
    if escalation_reply:
        return ChatResponse(reply=escalation_reply, sources=[], escalation=True)

    try:
        reply_text = llm.generate_reply(SYSTEM_PROMPT, messages, provider=req.provider)
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error generating a reply")
        raise HTTPException(status_code=502, detail=UNAVAILABLE)

    log_exchange(
        req.message,
        reply_text,
        sources=[s.model_dump() for s in sources],
        provider=req.provider,
        escalation=False,
    )
    return ChatResponse(reply=reply_text, sources=sources, suggest_card_upload=suggest_card_upload)


def _event(payload: dict) -> str:
    return json.dumps(payload) + "\n"


@app.post("/api/chat/stream")
def chat_stream(req: ChatRequest):
    """Same as /api/chat, but streams the reply while it's generated, as
    newline-delimited JSON events:

      {"type": "delta", "text": "..."}   the next piece of the reply
      {"type": "done", "reply", "sources", "escalation", "suggest_card_upload"}
      {"type": "error", "detail": "..."} the model failed after streaming began

    Problems found before streaming starts (invalid request, missing index,
    embeddings failure) are ordinary HTTP errors, exactly as on /api/chat.
    """
    escalation_reply, messages, sources, suggest_card_upload = _prepare_chat(req)
    source_dicts = [s.model_dump() for s in sources]

    def events():
        if escalation_reply:
            yield _event({"type": "done", "reply": escalation_reply, "sources": [], "escalation": True, "suggest_card_upload": False})
            return

        parts = []
        try:
            for piece in llm.stream_reply(SYSTEM_PROMPT, messages, provider=req.provider):
                parts.append(piece)
                yield _event({"type": "delta", "text": piece})
        except ProviderError as exc:
            logger.error("AI provider error while streaming: %s", exc.detail)
            yield _event({"type": "error", "detail": PUBLIC_MESSAGE})
            return
        except HTTPException as exc:
            yield _event({"type": "error", "detail": exc.detail})
            return
        except Exception:
            logger.exception("Unexpected error streaming a reply")
            yield _event({"type": "error", "detail": UNAVAILABLE})
            return

        reply_text = "".join(parts).strip()
        log_exchange(req.message, reply_text, sources=source_dicts, provider=req.provider, escalation=False)
        yield _event(
            {"type": "done", "reply": reply_text, "sources": source_dicts, "escalation": False, "suggest_card_upload": suggest_card_upload}
        )

    return StreamingResponse(
        events(),
        media_type="application/x-ndjson",
        # Stop proxies (e.g. nginx) from holding pieces back until the end.
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
