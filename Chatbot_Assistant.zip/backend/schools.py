"""
Loads the per-university waiver requirements dataset from
data/college_req_waiver/*.json, used by the demo waiver-eligibility flow in
the widget and React frontend.

Only "ut-austin", "ut-dallas", and "emory" reflect real, verified policies
(see each one's source_url — for the UT schools, the same pages cited in
data/waiver/external_utaustin_waiver_policy.json and external_utdallas_
waiver_policy.json; Emory mirrors its auditor waiver checklist). The other
four are clearly-labeled fictional example schools, invented to show
that real requirements vary meaningfully between institutions (deductible
limits, coinsurance caps, ACA-compliance and evacuation/repatriation
requirements, and whether a J-1 waiver is even allowed) — they are NOT real
universities' actual policies and must never be presented as such.
"""

import json
from pathlib import Path

SCHOOLS_DIR = Path(__file__).resolve().parent.parent / "data" / "college_req_waiver"


def load_schools() -> list[dict]:
    return [json.loads(path.read_text(encoding="utf-8")) for path in sorted(SCHOOLS_DIR.glob("*.json"))]


SCHOOLS = load_schools()
