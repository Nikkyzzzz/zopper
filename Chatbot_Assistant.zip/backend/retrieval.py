"""
Loads the pre-built embedding index and retrieves the most relevant chunks
for a given user query, by cosine similarity in embedding space.
"""

import pickle
from pathlib import Path

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

from backend.embeddings import embed_texts

INDEX_PATH = Path(__file__).resolve().parent.parent / "data" / "index.pkl"


class Retriever:
    def __init__(self, index_path: Path = INDEX_PATH):
        if not index_path.exists():
            raise FileNotFoundError(
                f"No index found at {index_path}. Run backend/build_index.py first."
            )
        with open(index_path, "rb") as f:
            data = pickle.load(f)
        self.chunks = data["chunks"]
        self.matrix = data["matrix"]
        # The index always gets re-embedded with whatever provider built it,
        # regardless of the live EMBEDDING_PROVIDER setting — mixing vector
        # spaces from two different embedding models would make cosine
        # similarity meaningless.
        self.embedding_provider = data["embedding_provider"]

    def search(
        self, query: str, top_k: int = 6, min_score: float = 0.4, max_per_source: int = 3
    ) -> list[dict]:
        query_vec = np.array(embed_texts([query], provider=self.embedding_provider))
        scores = cosine_similarity(query_vec, self.matrix)[0]
        ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)

        results = []
        per_source_count: dict[str, int] = {}
        for i in ranked:
            if len(results) >= top_k:
                break
            if scores[i] < min_score:
                break
            chunk = self.chunks[i]
            url = chunk["url"]
            if per_source_count.get(url, 0) >= max_per_source:
                continue
            per_source_count[url] = per_source_count.get(url, 0) + 1
            results.append({**chunk, "score": float(scores[i])})
        return results
