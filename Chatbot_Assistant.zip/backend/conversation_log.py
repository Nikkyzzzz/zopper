"""
Local, append-only conversation logging for debugging and quality review.

Stores each chat exchange (message, reply, sources, provider, escalation
flag, timestamp) in a local SQLite database (data/conversations.db, git-
ignored). This is a lightweight dev/QA log, NOT a compliance-grade PHI
storage solution — before pointing this at real users, review retention,
encryption-at-rest, and access-control requirements with legal/compliance
(see README's "Known limitations").
"""

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "conversations.db"

logger = logging.getLogger("aetna.conversation_log")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    message TEXT NOT NULL,
    reply TEXT NOT NULL,
    provider TEXT,
    escalation INTEGER NOT NULL,
    sources TEXT NOT NULL
)
"""


def log_exchange(
    message: str,
    reply: str,
    sources: list[dict],
    provider: str | None = None,
    escalation: bool = False,
) -> None:
    """Append one chat exchange to the local log.

    Failures here are caught and logged, never raised — a logging problem
    must never break a chat response for the user.
    """
    try:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute(_SCHEMA)
            conn.execute(
                "INSERT INTO conversations (timestamp, message, reply, provider, escalation, sources) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    datetime.now(timezone.utc).isoformat(),
                    message,
                    reply,
                    provider,
                    int(escalation),
                    json.dumps(sources),
                ),
            )
    except Exception:
        logger.exception("Failed to log conversation exchange")
