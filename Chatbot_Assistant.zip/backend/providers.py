"""
Real provider search backed by the official NPI Registry
(https://npiregistry.cms.hhs.gov) — a free, public CMS API. No key needed,
no scraping involved.

Confirms a result is a real, licensed provider. It does NOT confirm the
provider is in-network for any specific Aetna Student Health plan — the
caller (system prompt / tool description) is responsible for saying so.
"""

import requests

NPI_API_URL = "https://npiregistry.cms.hhs.gov/api/"
TIMEOUT = 10


def search_providers(
    specialty: str = "",
    city: str = "",
    state: str = "",
    postal_code: str = "",
    last_name: str = "",
    first_name: str = "",
    limit: int = 5,
) -> list[dict]:
    """
    Search the NPI Registry for real, licensed healthcare providers.

    At least one of specialty, city, state, postal_code, or last_name should
    be given — an empty query returns no results. Returns a simplified list
    of provider dicts: name, credential, primary specialty, address, phone,
    and NPI number.
    """
    params = {"version": "2.1", "limit": max(1, min(limit, 20))}
    if specialty:
        params["taxonomy_description"] = specialty
    if city:
        params["city"] = city
    if state:
        params["state"] = state
    if postal_code:
        params["postal_code"] = postal_code
    if last_name:
        params["last_name"] = last_name
    if first_name:
        params["first_name"] = first_name

    if len(params) <= 2:  # only version + limit set, i.e. no real filter
        return []

    try:
        resp = requests.get(NPI_API_URL, params=params, timeout=TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
    except (requests.RequestException, ValueError):
        return []

    if not isinstance(data, dict):
        return []

    results = []
    for r in data.get("results", []):
        basic = r.get("basic", {})
        name = basic.get("organization_name") or " ".join(
            filter(None, [basic.get("first_name"), basic.get("last_name")])
        )

        taxonomies = r.get("taxonomies", [])
        primary_tax = next((t for t in taxonomies if t.get("primary")), taxonomies[0] if taxonomies else {})

        addresses = r.get("addresses", [])
        location = next((a for a in addresses if a.get("address_purpose") == "LOCATION"), addresses[0] if addresses else {})

        results.append(
            {
                "npi": r.get("number"),
                "name": name.strip(),
                "credential": basic.get("credential", ""),
                "specialty": primary_tax.get("desc", ""),
                "address": ", ".join(
                    filter(None, [location.get("address_1"), location.get("city"), location.get("state"), location.get("postal_code")])
                ),
                "phone": location.get("telephone_number", ""),
            }
        )

    return results
