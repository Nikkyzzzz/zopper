"""
Errors from the AI providers (OpenAI / Gemini).

Their messages can include account details (key fragments, quota info) and
mean nothing to a student, so the full text only goes to the server log;
the API returns PUBLIC_MESSAGE instead (see the handler in backend/app.py).
"""

from fastapi import HTTPException

PUBLIC_MESSAGE = "the assistant is temporarily unavailable"


class ProviderError(HTTPException):
    def __init__(self, detail: str, status_code: int = 502):
        super().__init__(status_code=status_code, detail=detail)
