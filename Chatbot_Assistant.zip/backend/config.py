"""
Single source of truth for environment-derived configuration.

Loads .env once, here, so every other module can just import the settings
it needs instead of each reaching into os.environ (and instead of app.py
having to import other backend modules after a load_dotenv() call, in a
particular order, just to make sure env vars exist in time).
"""

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

# --- LLM provider selection ---
DEFAULT_PROVIDER = os.environ.get("LLM_PROVIDER", "gemini").strip().lower()
VALID_PROVIDERS = {"gemini", "openai"}

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash")
GEMINI_EMBEDDING_MODEL = os.environ.get("GEMINI_EMBEDDING_MODEL", "gemini-embedding-001")

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
OPENAI_EMBEDDING_MODEL = os.environ.get("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")

# Which provider embeds text for retrieval — independent of LLM_PROVIDER
# (chat generation), since the index must be rebuilt if this ever changes.
# Defaults to OpenAI: Gemini's free-tier embedding quota is separate from,
# and easy to exhaust independently of, its chat quota.
EMBEDDING_PROVIDER = os.environ.get("EMBEDDING_PROVIDER", "openai").strip().lower()

# --- HTTP / CORS ---
ALLOWED_ORIGINS = [o.strip() for o in os.environ.get("ALLOWED_ORIGINS", "*").split(",")]
