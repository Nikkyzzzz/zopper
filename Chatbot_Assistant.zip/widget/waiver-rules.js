/**
 * Waiver-eligibility walkthrough rules, shared by the embeddable widget
 * (widget/widget.js) and the React frontend (frontend/src/App.jsx) so the
 * two can't drift apart. This file is the single source of truth for the
 * walkthrough's copy, question queue, answer parsing, and pass/fail checks;
 * each client only owns its own UI state and rendering.
 *
 * Deliberately a classic script that sets one global (AetnaWaiverRules)
 * rather than an ES module: the widget injects it with a plain <script>
 * tag, which works on any embedding page (no CORS needed for classic
 * scripts) and when widget/demo.html is opened straight from disk, where
 * browsers refuse to load modules from file:// URLs. The React app just
 * imports this file for its side effect and reads the global.
 *
 * The matching logic is plain rules, not an LLM judgment call. School
 * requirements come from GET /api/schools (data/college_req_waiver/*.json).
 */
(function (root) {
  "use strict";

  var FAQ_SOURCE = { title: "Frequently asked questions | Aetna Student Health", url: "https://www.aetnastudenthealth.com/en/insurance-basics/faqs.html" };
  var GENERIC_DEMO_SOURCES = [
    FAQ_SOURCE,
    { title: "How to Waive University Health Insurance in the US (ISOA)", url: "https://www.isoa.org/blog/how-to-waive-university-health-insurance-in-the-us" },
  ];
  var UT_AUSTIN_SOURCE = {
    title: "UT Austin's actual student health insurance waiver policy (real, school-specific example)",
    url: "https://global.utexas.edu/isss/advising-services/insurance/waivers",
  };

  var START_OPTION = { label: "📋 Check my waiver eligibility", value: "start-waiver" };
  var START_USER_TEXT = "Check my waiver eligibility";

  var YES_NO_OPTIONS = [
    { label: "Yes", value: "yes" },
    { label: "No", value: "no" },
  ];
  var VISA_OPTIONS = [
    { label: "US Student", value: "US" },
    { label: "F-1 Visa", value: "F-1" },
    { label: "J-1 Visa", value: "J-1" },
  ];

  var GATE_QUESTION =
    "Do you already have your own health insurance that might qualify for a waiver of the university's plan (for example, coverage through a parent's plan)?";
  var NOT_ELIGIBLE_NO_INSURANCE = {
    content:
      "Since you don't currently have your own comparable health insurance, you likely wouldn't be eligible to waive the university's plan, so you'd stay covered under it automatically. Waiver requirements are set by your specific school, so if you think this doesn't apply to you, contact your school directly.",
    sources: [FAQ_SOURCE],
  };
  var SCHOOL_QUESTION = "Let's check your plan against your specific school's waiver criteria. Which school are you at?";

  var YES_NO_REPROMPT = 'Sorry, I didn\'t catch that. Please tap Yes or No above, or type "yes" or "no".';
  var VISA_REPROMPT = "Sorry, I didn't catch that. Please choose US Student, F-1 Visa, or J-1 Visa from the buttons above, or type one of those.";
  var NUMBER_REPROMPT =
    "That doesn't look like a number. Please type just the number, with nothing else around it. If you're not sure, check your insurance card or policy documents; you can also upload your card with the 📎 button and I'll try to read it.";

  function visaQuestion(school) {
    return "Got it, " + school.name + ". Are you a US student, or an international student on an F-1 or J-1 visa?";
  }

  function visaLabel(visa) {
    return visa === "US" ? "US Student" : visa + " Visa";
  }

  // Federal J-1 insurance minimums (22 CFR 62.14), applied to every J-1
  // student on top of the school's own criteria.
  var J1_MAX_DEDUCTIBLE = 500;
  var J1_MAX_COINSURANCE_PERCENT = 25;

  // --- Question definitions used to build a per-school, per-visa queue ---
  // Coverage criteria (US-based insurer, local non-emergency care,
  // prescriptions, preventive care, maternity, catastrophic plans,
  // out-of-pocket maximum) come from real schools' published waiver rules,
  // e.g. UT Austin, Columbia, Case Western, WashU, Harvard, and Northwestern.
  // The audit checks asked at every school (deadline, active coverage,
  // non-insurance products, prior use of the school plan, and the documents
  // list) mirror the denial reasons waiver administrators publish: Gallagher
  // Student Health's denial codes, UnitedHealthcare StudentResources' waiver
  // standards, Wellfleet, and schools administered by Aetna Student Health.
  var ASK_OUT_OF_POCKET = { key: "outOfPocketMax", type: "number", content: "What's your plan's yearly out-of-pocket maximum for one person, in USD? Just type the number (e.g. 6000)." };
  var ASK_ACTIVE_COVERAGE = { key: "coverageActive", type: "yesno", content: "Is your coverage already active, or confirmed to start on or before the first day of the term? Waiver auditors check with your insurer that your coverage is active." };
  var ASK_TRAVEL_PLAN = { key: "isTravelPlan", type: "yesno", content: "Is your plan a travel, international-only, or short-term insurance plan (including month-to-month plans), rather than a standard ongoing health plan?" };
  var ASK_NON_INSURANCE = { key: "isNonInsuranceProduct", type: "yesno", content: "Is your coverage one of these instead of regular health insurance: a health care sharing ministry, a medical cost-sharing or co-op program, a medical discount program, a hospital indemnity plan, an accident-only plan, or an emergency-only plan?" };
  var ASK_CATASTROPHIC = { key: "isCatastrophicPlan", type: "yesno", content: "Is your plan a catastrophic-only plan (a very high deductible plan meant only for worst-case emergencies)?" };
  var ASK_US_INSURER = { key: "usBasedInsurer", type: "yesno", content: "Is your plan from a US-based insurance company or claim administrator, with a US phone number and claims address, and was the policy issued in the US?" };
  var ASK_PRESCRIPTION = { key: "prescriptionCovered", type: "yesno", content: "Does your plan cover prescription drugs?" };

  // Where the school needs care to be covered: its own area when the policy
  // names one (e.g. Emory: "Atlanta, GA and surrounding areas").
  function careArea(school) {
    return school.campus_area ? "in " + school.campus_area + " and surrounding areas" : "near campus";
  }

  function askFullCoverage(school) {
    var content = school.coverage_through
      ? "Does your plan provide continuous coverage, with no gaps, through " + school.coverage_through + "?"
      : "Does your plan cover the full semester or academic year, including breaks (not just partial dates)?";
    return { key: "fullCoverage", type: "yesno", content: content };
  }

  function askLocalCare(school) {
    return {
      key: "localNonEmergencyCare",
      type: "yesno",
      content:
        "Does your plan cover both emergency and non-emergency care, inpatient and outpatient (including lab tests, diagnostics, " +
        "primary and specialty care, and physical therapy), from providers " + careArea(school) + "? Many HMOs and out-of-state " +
        "Medicaid plans only cover emergencies away from home.",
    };
  }

  // Only asked at schools that accept Medicaid from just one state (Emory: Georgia).
  function askOtherStateMedicaid(school) {
    return {
      key: "isOtherStateMedicaid",
      type: "yesno",
      content: "Is your coverage a Medicaid plan from a state other than " + school.accepted_medicaid_state + "? (" +
        school.accepted_medicaid_state + " Medicaid is accepted.)",
    };
  }

  function askMentalHealth(school) {
    var content = school.requires_substance_use_coverage
      ? "Does your plan cover both inpatient and outpatient mental health treatment, and treatment for substance abuse (alcohol and drug)?"
      : "Does your plan include mental health coverage?";
    return { key: "mentalHealth", type: "yesno", content: content };
  }

  function askPreventive(school) {
    var content = school.preventive_care_at_no_cost
      ? "Does your plan cover preventive care, including vaccinations, at 100% (no cost to you) " + careArea(school) + "?"
      : "Does your plan cover preventive care, like annual checkups and vaccines?";
    return { key: "preventiveCovered", type: "yesno", content: content };
  }

  function askMaternity(school) {
    var content = school.maternity_female_students_only
      ? "Does your plan cover care related to pregnancy and delivery? (" + school.name + " requires this for female students; " +
        "if it doesn't apply to you, answer Yes.)"
      : "Does your plan cover maternity and newborn care?";
    return { key: "maternityCovered", type: "yesno", content: content };
  }

  function askContraceptives(school) {
    return {
      key: "contraceptivesCovered",
      type: "yesno",
      content: "Does your plan cover oral contraceptives (birth control pills) at 100% of usual and customary charges " + careArea(school) + "?",
    };
  }

  var ASK_EVACUATION_REPATRIATION = { key: "evacuationRepatriation", type: "yesno", content: "Does your plan include emergency medical evacuation and repatriation coverage, or have you bought a separate policy that covers them?" };
  var ASK_ACA = { key: "acaCompliant", type: "yesno", content: "Is your plan ACA-compliant (meets Affordable Care Act standards)?" };
  var ASK_PREEXISTING = { key: "preExisting", type: "yesno", content: "Does your plan cover pre-existing conditions (no exclusions for them)?" };
  var ASK_UNLIMITED_MAX_BENEFITS = { key: "unlimitedMaxBenefits", type: "yesno", content: "Does your plan have unlimited annual and lifetime benefits (no policy maximum on the total it will pay out)?" };
  var ASK_OUTPATIENT = { key: "outpatientCovered", type: "yesno", content: "Does your plan cover outpatient care, emergency room visits, and hospitalization?" };
  var ASK_J1_MEDICAL = { key: "meetsJ1Medical", type: "yesno", content: "Federal J-1 requirement: does your plan include at least $100,000 in medical benefits per accident or illness?" };
  var ASK_J1_REPATRIATION = { key: "meetsJ1Repatriation", type: "yesno", content: "Federal J-1 requirement: does your plan include at least $25,000 for repatriation of remains?" };
  var ASK_J1_EVACUATION = { key: "meetsJ1Evacuation", type: "yesno", content: "Federal J-1 requirement: does your plan include at least $50,000 for medical evacuation back to your home country?" };
  var ASK_J1_INSURER_RATING = { key: "meetsJ1InsurerRating", type: "yesno", content: "Federal J-1 requirement: is your insurer rated A- or better by A.M. Best (or A-1 by ISI, A- by Standard & Poor's, or B+ by Weiss), or is your plan backed by your home country's government? Your insurer can confirm this." };
  var ASK_USED_SCHOOL_PLAN = { key: "usedSchoolPlan", type: "yesno", content: "Last one: have you already used the school's insurance plan this term (for example, a doctor visit or prescription billed to it)?" };

  // --- Waiver deadlines ---
  // Schools with real dates list them in `deadline_dates` (one per term, in
  // order), so the deadline is checked against today's date instead of
  // asking. Dates compare by calendar day: a deadline counts as open through
  // the end of its date. Schools with only a relative deadline ("1st day of
  // classes") fall back to asking the student.
  var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  function isoDay(date) {
    var mm = String(date.getMonth() + 1).padStart(2, "0");
    var dd = String(date.getDate()).padStart(2, "0");
    return date.getFullYear() + "-" + mm + "-" + dd;
  }

  // e.g. "January 25, 2027, 5 p.m." (built by hand so it reads the same in every browser locale)
  function formatDeadline(d) {
    var parts = d.date.split("-");
    return MONTHS[Number(parts[1]) - 1] + " " + Number(parts[2]) + ", " + parts[0] + (d.time ? ", " + d.time : "");
  }

  // { mode: "open", deadline }  the next deadline that hasn't passed: no question needed
  // { mode: "closed", deadline } every posted deadline has passed and the school only waives once a year: stop
  // { mode: "ask", passed }     no dates, or later terms' dates aren't posted yet: ask the student
  function deadlineStatus(school, today) {
    var dates = school.deadline_dates || [];
    if (!dates.length) return { mode: "ask", passed: null };
    var todayIso = isoDay(today || new Date());
    for (var i = 0; i < dates.length; i++) {
      if (dates[i].date >= todayIso) return { mode: "open", deadline: dates[i] };
    }
    var last = dates[dates.length - 1];
    return school.annual_waiver_only ? { mode: "closed", deadline: last } : { mode: "ask", passed: last };
  }

  function deadlinePassedText(school) {
    return (
      "If you have a valid reason (for example, you enrolled after the deadline), contact " + school.name +
      "'s insurance office right away."
    );
  }

  // Checked as soon as the school is picked: when its (annual) deadline has
  // passed there's nothing to check, so the walkthrough ends there.
  function deadlineClosedMessage(school, today) {
    var status = deadlineStatus(school, today);
    if (status.mode !== "closed") return null;
    return {
      content:
        school.name + "'s waiver deadline for the " + status.deadline.term + " was " + formatDeadline(status.deadline) +
        ", and it has passed. " + school.name + " only accepts waivers once a year, so you stay enrolled in its plan for the " +
        "full academic year. " + deadlinePassedText(school),
      sources: schoolSources(school),
    };
  }

  // Questions that end the walkthrough early when answered with `exitOn`,
  // showing `exitMessage` instead of the pass/fail checklist.
  function askDeadlineOpen(school, status) {
    var content = status.passed
      ? school.name + "'s last posted waiver deadline (" + status.passed.term + ": " + formatDeadline(status.passed) +
        ") has passed, and dates for the next term haven't been posted yet. Is a waiver period open for you right now?"
      : "First, is " + school.name + "'s waiver deadline still open for you? The deadline is: " + school.deadline + ".";
    return {
      key: "deadlineOpen",
      type: "yesno",
      content: content,
      exitOn: false,
      exitMessage: {
        content:
          "Once the waiver deadline has passed, " + school.name + " keeps you enrolled in its plan for that term, and a late waiver " +
          "usually can't be accepted. " + deadlinePassedText(school) + " Some schools also don't let you waive later in the same " +
          "year, so check before the next term.",
        sources: schoolSources(school),
      },
    };
  }

  // How the result tells the student when to submit by.
  function deadlineForResult(school, today) {
    var status = deadlineStatus(school, today);
    if (status.mode === "open") return formatDeadline(status.deadline) + " (" + status.deadline.term + " deadline)";
    return school.deadline || null;
  }

  function askGovernmentSponsored(school) {
    return {
      key: "governmentSponsored",
      type: "yesno",
      content:
        "Is your coverage provided by a government sponsor (for example, your home country's government or a cultural mission) " +
        "or by a US exchange program such as Fulbright?",
      exitOn: true,
      exitMessage: {
        content:
          school.name + " accepts coverage from a government sponsor, but reviews each of these plans individually, so the regular " +
          "checklist doesn't apply and I can't predict the result. Submit your waiver with a written guarantee from your sponsor " +
          "that shows your coverage and its dates for the full term.",
        sources: schoolSources(school),
      },
    };
  }

  // The message that ends the walkthrough for this answer, or null to carry on.
  function exitMessageFor(question, answer) {
    return question.exitOn === answer ? question.exitMessage : null;
  }

  // Deductible and coinsurance are asked as yes/no against the strictest
  // limit that applies (the school's own, or the federal J-1 cap when that's
  // lower), so students don't need to know their plan's exact numbers.
  function strictestLimit(schoolLimit, visa, j1Cap) {
    if (visa === "J-1" && (schoolLimit == null || schoolLimit > j1Cap)) return j1Cap;
    return schoolLimit;
  }

  function deductibleLimit(school, visa) {
    return strictestLimit(school.max_deductible, visa, J1_MAX_DEDUCTIBLE);
  }

  function deductibleIsFederalCap(school, visa) {
    return deductibleLimit(school, visa) !== school.max_deductible;
  }

  function coinsuranceLimit(school, visa) {
    return strictestLimit(school.max_coinsurance_percent, visa, J1_MAX_COINSURANCE_PERCENT);
  }

  function coinsuranceIsFederalCap(school, visa) {
    return coinsuranceLimit(school, visa) !== school.max_coinsurance_percent;
  }

  function askCoinsurance(school, visa) {
    return {
      key: "coinsuranceWithinLimit",
      type: "yesno",
      content:
        "Is your plan's coinsurance " + coinsuranceLimit(school, visa) + "% or less, so the plan pays at least " +
        (100 - coinsuranceLimit(school, visa)) + "% of covered costs? (Coinsurance is the share of each bill you pay " +
        "after meeting your deductible. For example, 20% means you pay $20 of every $100.)",
    };
  }

  function askDeductible(school, visa) {
    var perClaim = deductibleIsFederalCap(school, visa) ? " per accident or illness" : "";
    return {
      key: "deductibleWithinLimit",
      type: "yesno",
      content:
        "Is your plan's deductible $" + deductibleLimit(school, visa) + " or less" + perClaim +
        "? (The deductible is the amount you pay yourself before your insurance starts paying.)",
    };
  }

  function buildQuestionQueue(school, visa, today) {
    var queue = [];
    // Gatekeepers first: no point checking coverage if the waiver can't be
    // filed any more, or if the plan goes to individual review anyway.
    var deadline = deadlineStatus(school, today);
    if (deadline.mode === "ask" && (school.deadline || deadline.passed)) queue.push(askDeadlineOpen(school, deadline));
    if (visa !== "US" && school.accepts_government_sponsored_plans) queue.push(askGovernmentSponsored(school));

    if (deductibleLimit(school, visa) != null) queue.push(askDeductible(school, visa));
    // J-1s always get the coinsurance question: federal rules cap it at 25%.
    if (coinsuranceLimit(school, visa) != null) queue.push(askCoinsurance(school, visa));
    if (school.max_out_of_pocket != null) queue.push(ASK_OUT_OF_POCKET);
    queue.push(ASK_ACTIVE_COVERAGE);
    queue.push(askFullCoverage(school));
    if (!school.travel_or_short_term_plans_accepted) queue.push(ASK_TRAVEL_PLAN);
    queue.push(ASK_NON_INSURANCE);
    if (school.accepted_medicaid_state) queue.push(askOtherStateMedicaid(school));
    if (school.rejects_catastrophic_plans) queue.push(ASK_CATASTROPHIC);
    if (school.requires_us_based_insurer) queue.push(ASK_US_INSURER);
    if (school.requires_local_nonemergency_coverage) queue.push(askLocalCare(school));
    queue.push(askMentalHealth(school));
    if (school.requires_prescription_coverage) queue.push(ASK_PRESCRIPTION);
    if (school.requires_preventive_care) queue.push(askPreventive(school));
    if (school.requires_maternity_coverage) queue.push(askMaternity(school));
    if (school.requires_contraceptive_coverage) queue.push(askContraceptives(school));
    if (school.requires_evacuation_repatriation && visa !== "J-1") queue.push(ASK_EVACUATION_REPATRIATION);
    if (school.aca_compliance_required) queue.push(ASK_ACA);
    if (school.requires_unlimited_max_benefits) queue.push(ASK_UNLIMITED_MAX_BENEFITS);
    if (school.requires_no_preexisting_exclusions) queue.push(ASK_PREEXISTING);

    if (visa === "F-1") queue.push(ASK_OUTPATIENT);
    else if (visa === "J-1") queue.push(ASK_J1_MEDICAL, ASK_J1_REPATRIATION, ASK_J1_EVACUATION, ASK_J1_INSURER_RATING);

    queue.push(ASK_USED_SCHOOL_PLAN);
    return queue;
  }

  function parseYesNo(text) {
    var t = text.trim().toLowerCase();
    if (/^(y|yes|yeah|yep|sure|correct)\b/.test(t)) return true;
    if (/^(n|no|nope|nah)\b/.test(t)) return false;
    return null;
  }

  function parseVisaChoice(text) {
    var t = text.toLowerCase();
    if (/\bj-?1\b/.test(t)) return "J-1";
    if (/\bf-?1\b/.test(t)) return "F-1";
    if (/\bus\b|u\.s\.?|american|domestic/.test(t)) return "US";
    return null;
  }

  // Strict on purpose: strips only cosmetic wrapping ($, commas, %, "USD"/
  // "dollars"), then requires what's left to be ENTIRELY numeric. A looser
  // "strip every non-digit character" approach would turn "not 400" or
  // "about 500" into 400/500 as if the user had stated that value, silently
  // accepting the opposite of (or a guess at) what they meant.
  function parseNumericAnswer(text) {
    var cleaned = text
      .trim()
      .replace(/^\$/, "")
      .replace(/,/g, "")
      .replace(/%$/, "")
      .replace(/\s*(usd|dollars?)\s*$/i, "")
      .trim();
    if (!/^\d+(\.\d+)?$/.test(cleaned)) return null;
    var amount = parseFloat(cleaned);
    return Number.isFinite(amount) ? amount : null;
  }

  function schoolSources(school) {
    if (school.source_url) return [{ title: school.name + "'s waiver policy", url: school.source_url }];
    return GENERIC_DEMO_SOURCES;
  }

  function buildJ1NotAllowedMessage(school) {
    var content = school.is_real
      ? school.name +
        "'s actual published policy states that J-1 exchange students are generally not eligible to waive its student health insurance plan at all, regardless of what other coverage you have. You'd need to contact your school's international student office directly rather than pursue a waiver."
      : "In this demo, " +
        school.name +
        "'s example policy doesn't allow J-1 visa holders to waive its plan at all, regardless of other coverage. (This particular school is invented for the demo, but it reflects something real: actual schools like UT Austin do restrict or disallow J-1 waivers entirely.) You'd need to contact your school's international student office directly.";
    return { content: content, sources: school.is_real ? schoolSources(school) : [UT_AUSTIN_SOURCE] };
  }

  function buildResultMessage(school, visa, answers, today) {
    var checks = [];
    var dedLimit = deductibleLimit(school, visa);
    if (dedLimit != null) {
      checks.push({
        label:
          "Deductible $" + dedLimit + " or less" +
          (deductibleIsFederalCap(school, visa) ? " per accident or illness (J-1 federal requirement)" : " (" + school.name + "'s max)"),
        pass: answers.deductibleWithinLimit,
      });
    }
    var coinLimit = coinsuranceLimit(school, visa);
    if (coinLimit != null) {
      checks.push({
        label:
          "Coinsurance " + coinLimit + "% or less" +
          (coinsuranceIsFederalCap(school, visa) ? " (J-1 federal requirement)" : " (" + school.name + "'s max)"),
        pass: answers.coinsuranceWithinLimit,
      });
    }
    if (school.max_out_of_pocket != null) {
      checks.push({
        label: "Out-of-pocket maximum ($" + answers.outOfPocketMax + " vs. max $" + school.max_out_of_pocket + ")",
        pass: Number.isFinite(answers.outOfPocketMax) && answers.outOfPocketMax <= school.max_out_of_pocket,
      });
    }
    checks.push({ label: "Coverage is active (or starts by the first day of the term)", pass: answers.coverageActive });
    checks.push({
      label: school.coverage_through
        ? "Continuous coverage through " + school.coverage_through
        : "Covers the full semester/academic year, including breaks",
      pass: answers.fullCoverage,
    });
    if (!school.travel_or_short_term_plans_accepted) {
      checks.push({ label: "Is not a travel, short-term, month-to-month, or international-only plan", pass: answers.isTravelPlan === false });
    }
    checks.push({
      label: "Is real health insurance, not a health-share, cost-sharing/co-op, discount, hospital indemnity, accident-only, or emergency-only plan",
      pass: answers.isNonInsuranceProduct === false,
    });
    if (school.accepted_medicaid_state) {
      checks.push({
        label: "Not Medicaid from another state (only " + school.accepted_medicaid_state + " Medicaid is accepted)",
        pass: answers.isOtherStateMedicaid === false,
      });
    }
    if (school.rejects_catastrophic_plans) {
      checks.push({ label: "Is not a catastrophic-only plan", pass: answers.isCatastrophicPlan === false });
    }
    if (school.requires_us_based_insurer) {
      checks.push({ label: "US-based insurer or claim administrator, US phone and claims address, policy issued in the US", pass: answers.usBasedInsurer });
    }
    if (school.requires_local_nonemergency_coverage) {
      checks.push({ label: "Covers emergency and non-emergency care " + careArea(school) + ", not just emergencies", pass: answers.localNonEmergencyCare });
    }
    checks.push({
      label: school.requires_substance_use_coverage
        ? "Covers inpatient and outpatient mental health and substance abuse treatment"
        : "Includes mental health coverage",
      pass: answers.mentalHealth,
    });
    if (school.requires_prescription_coverage) {
      checks.push({ label: "Covers prescription drugs", pass: answers.prescriptionCovered });
    }
    if (school.requires_preventive_care) {
      checks.push({
        label: school.preventive_care_at_no_cost ? "Covers preventive care, including vaccinations, at 100%" : "Covers preventive care",
        pass: answers.preventiveCovered,
      });
    }
    if (school.requires_maternity_coverage) {
      checks.push({
        label: school.maternity_female_students_only ? "Covers pregnancy and delivery care" : "Covers maternity and newborn care",
        pass: answers.maternityCovered,
      });
    }
    if (school.requires_contraceptive_coverage) {
      checks.push({ label: "Covers oral contraceptives at 100% " + careArea(school), pass: answers.contraceptivesCovered });
    }
    // Warnings are shown with the checks but don't change the verdict.
    var warnings = [];
    if (school.requires_evacuation_repatriation && visa !== "J-1") {
      if (!answers.evacuationRepatriation && school.evacuation_repatriation_fallback) {
        // Some schools (e.g. UT Austin) let you buy it separately instead of failing the waiver.
        warnings.push(
          "No evacuation and repatriation coverage yet: " + school.name + " requires you to buy it through " +
            school.evacuation_repatriation_fallback + " to complete your waiver"
        );
      } else {
        checks.push({ label: "Has emergency evacuation and repatriation coverage (in your plan or a separate policy)", pass: answers.evacuationRepatriation });
      }
    }
    if (school.aca_compliance_required) {
      checks.push({ label: "ACA-compliant", pass: answers.acaCompliant });
    }
    if (school.requires_unlimited_max_benefits) {
      checks.push({ label: "Has unlimited annual and lifetime benefits (no policy maximum)", pass: answers.unlimitedMaxBenefits });
    }
    if (school.requires_no_preexisting_exclusions) {
      checks.push({ label: "Covers pre-existing conditions (no exclusions)", pass: answers.preExisting });
    }

    if (visa === "F-1") {
      checks.push({ label: "Covers outpatient care, ER visits, and hospitalization", pass: answers.outpatientCovered });
    } else if (visa === "J-1") {
      checks.push({ label: "Meets $100k medical minimum (J-1 federal requirement)", pass: answers.meetsJ1Medical });
      checks.push({ label: "Meets $25k repatriation minimum (J-1 federal requirement)", pass: answers.meetsJ1Repatriation });
      checks.push({ label: "Meets $50k evacuation minimum (J-1 federal requirement)", pass: answers.meetsJ1Evacuation });
      checks.push({ label: "Insurer rated A- or better, or government-backed (J-1 federal requirement)", pass: answers.meetsJ1InsurerRating });
    }

    if (answers.usedSchoolPlan) {
      warnings.push(
        "You've already used the school plan this term. Some schools deny the waiver or bill you for those claims, so ask " +
          school.name + "'s insurance office how it handles this"
      );
    }

    var allPass = checks.every(function (c) {
      return c.pass;
    });
    var lines = checks
      .map(function (c) {
        return (c.pass ? "✅ " : "❌ ") + c.label;
      })
      .concat(
        warnings.map(function (w) {
          return "⚠️ " + w;
        })
      )
      .join("\n");
    var exampleNote = school.is_real ? "" : " (example criteria)";
    var submitBy = deadlineForResult(school, today);
    var verdict = allPass
      ? "Based on what you've told me, your plan looks like it would meet " +
        school.name +
        "'s requirements" +
        exampleNote +
        ". Next step: submit your waiver " +
        (submitBy ? "by the deadline, " + submitBy : "before the school's deadline") +
        ". Have these documents ready for the auditor:\n" +
        auditDocuments(school, visa)
      : "Based on what you've told me, your plan doesn't meet all of " +
        school.name +
        "'s requirements" +
        exampleNote +
        ". See which item(s) above didn't pass. You may want to check with your insurer about upgrading coverage, or contact your school's insurance office directly.";

    return { content: lines + "\n\n" + verdict, sources: schoolSources(school) };
  }

  // What waiver auditors ask students to provide. Bullets use "•" rather
  // than "- " so the chat's Markdown renderer shows them as plain lines.
  function auditDocuments(school, visa) {
    var docs = [
      "Front and back of your current insurance ID card. The member ID and group number you enter must match it exactly.",
      "A verification of coverage letter from your insurer, on its letterhead, with your name and your coverage dates.",
      "A benefits summary showing your deductible, coinsurance, and what's covered.",
    ];
    if (visa !== "US") {
      docs.push("Proof that your insurer has a US claims address.");
      if (school.requires_evacuation_repatriation || visa === "J-1") {
        docs.push("Proof of your evacuation and repatriation coverage, if it's a separate policy.");
      }
    }
    docs.push("Use the insurance company's exact name on the waiver form, matching these documents.");
    return docs
      .map(function (d) {
        return "• " + d;
      })
      .join("\n");
  }

  // --- Waiver status helper ---
  // Fixed, sourced next steps for a waiver that's already been submitted,
  // based on the reasons waiver administrators publish for pending and
  // denied waivers (Gallagher Student Health's denial codes, UC Irvine's
  // Academic HealthPlans audit process, Harvard's post-approval audit).
  // Nothing the student says here is stored or sent anywhere.
  var GALLAGHER_DENIALS_SOURCE = {
    title: "Gallagher Student Health: why waivers are denied and how to fix it",
    url: "https://www.gallagherstudent.com/miscforms/Waiver%20Denial%20Explanation%20Remediation.pdf",
  };
  var UCI_AUDIT_SOURCE = { title: "UC Irvine: how waiver audits and statuses work", url: "https://studenthealth.uci.edu/waiving-uc-irvine-ship/" };
  var HARVARD_AUDIT_SOURCE = { title: "Harvard: approved waivers are audited later", url: "https://hushp.harvard.edu/waiver-eligibility-application-process/" };

  var STATUS_OPTION = { label: "📬 Help with my waiver status", value: "status-help" };
  var STATUS_USER_TEXT = "Help with my waiver status";
  var STATUS_QUESTION = "I can help with a waiver you've already submitted. What does your waiver status say right now?";
  var STATUS_OPTIONS = [
    { label: "⏳ Pending", value: "pending" },
    { label: "❌ Denied", value: "denied" },
    { label: "✅ Approved", value: "approved" },
  ];
  var STATUS_REPROMPT = 'Sorry, I didn\'t catch that. Please tap Pending, Denied, or Approved above, or type one of those.';
  var DENIAL_QUESTION = "Sorry to hear that. What reason did the denial email or portal give?";
  var DENIAL_OPTIONS = [
    { label: "Coverage not active / couldn't verify", value: "inactive" },
    { label: "Info doesn't match my card", value: "mismatch" },
    { label: "Plan doesn't meet requirements", value: "inadequate" },
    { label: "International or travel plan", value: "international" },
    { label: "Not an insurance plan", value: "notInsurance" },
    { label: "Deadline passed", value: "deadline" },
    { label: "Not sure", value: "unsure" },
  ];

  var LETTER =
    "a \"Verification of Active Coverage\" letter from your insurer (on its letterhead, with your name and your coverage dates; " +
    "most insurers let you download it from their website or send it if you call member services)";
  var RESUBMIT =
    "Log in to the waiver portal your school uses, open your submitted waiver, fix or upload what's needed, and resubmit before " +
    "the waiver or appeal deadline.";

  var STATUS_GUIDANCE = {
    pending: [
      "⏳ Pending means the auditor needs more information before deciding. Here's what to do:",
      "• Check your email and the waiver portal for exactly what's missing. It's often " + LETTER + ", a benefits summary, or the front and back of your insurance card.",
      "• Upload it as soon as you can, before the deadline. Some administrators send a reminder every 7 days (up to 3 times), and a waiver left pending can end up denied.",
      "• A review usually takes about 7 to 10 business days after you respond.",
    ],
    approved: [
      "✅ Great news! Here's what happens next:",
      "• The insurance charge is usually removed from your student account within 5 to 10 business days.",
      "• Keep your plan active for the whole year. Approved waivers can be audited later, and if your coverage has ended, the waiver can be reversed and the charge put back.",
      "• If your school requires it, you'll need to waive again next year (or next term).",
      "• If you get financial aid, let the financial aid office know, since your cost of attendance changes.",
    ],
    inactive: [
      "❌ \"Coverage not active\" or \"unable to verify\" means your insurer couldn't confirm your coverage when the auditor checked. (Gallagher codes 1001 and 1004.)",
      "• Make sure you entered the details from your current insurance card, not an old one.",
      "• Get " + LETTER + ".",
      "• " + RESUBMIT,
    ],
    mismatch: [
      "❌ \"Invalid or missing data\" means what you entered doesn't match your insurer's records. (Gallagher code 1002.)",
      "• Compare your member ID, group number, name, and date of birth with your current insurance card, character by character.",
      "• If something was wrong, correct it and resubmit.",
      "• If everything matches, the insurer's electronic check may have failed. Upload " + LETTER + ".",
    ],
    inadequate: [
      "❌ \"Plan doesn't meet requirements\" usually means one of these (Gallagher code 1003):",
      "• Your plan is an HMO or out-of-state Medicaid that only covers emergencies near your school.",
      "• It's a short-term or month-to-month plan that can't be confirmed for the whole year.",
      "• Its benefits are below your school's minimums.",
      "What to do: if you believe your plan does qualify, upload a benefits summary or a letter from your insurer showing the coverage your school requires near campus. You can also ask your insurer about an out-of-area option, though these are often limited. Otherwise, you stay on your school's plan.",
    ],
    international: [
      "❌ International plans are often denied because they're travel plans, or because they aren't US-based or ACA-compliant, which many schools require. (Gallagher code 1005.)",
      "• If your school requires a US-based plan, you'll need a US-based, ACA-compliant plan. The school's own plan is often the simplest option.",
      "• If your plan does have a US claims address and meets the benefit requirements, upload three things: a benefits summary, a document showing the US billing or claims address, and " + LETTER + ".",
    ],
    notInsurance: [
      "❌ Health care sharing ministries, cost-sharing, and co-op programs aren't insurance, so they can't be used to waive. (Gallagher code 1006.)",
      "• You'll need a real insurance plan in place by your school's required date, or you'll stay on the school's plan.",
      "• If your product actually is an insurance plan, upload documents showing it's an ACA-compliant insurance policy filed to do business in the US (the benefits summary usually shows a policy number).",
    ],
    deadline: [
      "❌ Once the waiver or appeal deadline has passed, you're usually enrolled in the school's plan for that term and a waiver can't be accepted. (Gallagher codes 1007 and 1008.)",
      "• If you have a valid reason (for example, you enrolled after the deadline), contact your school's insurance office right away.",
      "• Check when the next waiver period opens. Some schools only allow waiving once a year.",
    ],
    unsure: [
      "The denial email or waiver portal should list the reason. The most common ones are:",
      "• Coverage not active or couldn't be verified: get a verification of coverage letter from your insurer.",
      "• Details don't match your card: fix your member ID or group number and resubmit.",
      "• Plan doesn't meet the school's requirements (often an HMO, out-of-state Medicaid, or short-term plan).",
      "• International, travel, or non-insurance plans (like health-share ministries).",
      "• The deadline passed.",
      "In most cases you can edit and resubmit, or appeal with documents, before the deadline. Your school's insurance office can tell you exactly what's missing.",
    ],
  };

  function statusGuidance(key) {
    var lines = STATUS_GUIDANCE[key] || STATUS_GUIDANCE.unsure;
    var sources = [GALLAGHER_DENIALS_SOURCE];
    if (key === "pending") sources = [UCI_AUDIT_SOURCE, GALLAGHER_DENIALS_SOURCE];
    if (key === "approved") sources = [HARVARD_AUDIT_SOURCE, UCI_AUDIT_SOURCE];
    return { content: lines.join("\n"), sources: sources };
  }

  // Loose parsing for answers typed while the status helper is asking.
  function parseStatus(text) {
    var t = text.toLowerCase();
    if (/pending|review|waiting|more info|additional info/.test(t)) return "pending";
    if (/denied|deny|reject|declin|not approved|refused/.test(t)) return "denied";
    if (/approved|accepted|approve/.test(t)) return "approved";
    return null;
  }

  var DENIAL_CODES = { 1001: "inactive", 1002: "mismatch", 1003: "inadequate", 1004: "inactive", 1005: "international", 1006: "notInsurance", 1007: "deadline", 1008: "deadline" };

  function parseDenialReason(text) {
    var t = text.toLowerCase();
    var code = t.match(/\b(100[1-8])\b/);
    if (code) return DENIAL_CODES[code[1]];
    if (/deadline|\blate\b|\bmissed\b/.test(t)) return "deadline";
    if (/not active|inactive|unable to verify|couldn'?t verify|could not verify|not found|verif/.test(t)) return "inactive";
    if (/match|typo|invalid|missing data|wrong (id|number)|member id|group/.test(t)) return "mismatch";
    if (/international|travel|foreign|abroad/.test(t)) return "international";
    if (/sharing|ministry|co-?op|not (an )?insurance|non-insurance/.test(t)) return "notInsurance";
    if (/hmo|medicaid|comparable|inadequate|requirement|criteria|benefit|coverage|network|short.?term|month/.test(t)) return "inadequate";
    if (/not sure|unsure|don'?t know|no idea|\bother\b/.test(t)) return "unsure";
    return null;
  }

  // Free-typed chat messages about a waiver that was already submitted, so
  // the client can answer them with the fixed guidance instead of the LLM.
  // Deliberately narrow: "will my waiver be approved?" is a question for the
  // eligibility walkthrough or the chat, not a status update.
  // Returns { status, reason } or null.
  function detectStatusIntent(text) {
    var t = text.toLowerCase();
    var code = t.match(/\bcode\s*#?\s*(100[1-8])\b/);
    if (code) return { status: "denied", reason: DENIAL_CODES[code[1]] };
    if (!/waiv/.test(t)) return null;
    if (/(waiver|waive)\w*\s+(request\s+)?(was|is|got|has been|been|status\s+(is|says))?\s*(denied|rejected|declined|not approved)|(denied|rejected|declined)\s+(my\s+)?waiver/.test(t)) {
      return { status: "denied", reason: parseDenialReason(t.replace(/denied|rejected|declined|not approved/g, "")) };
    }
    if (/(waiver|waive)\w*\s+(request\s+)?(is|was|still|status\s+(is|says))?\s*(still\s+)?(pending|under review|in review|on hold)|pending\s+waiver/.test(t)) {
      return { status: "pending", reason: null };
    }
    if (/(waiver|waive)\w*\s+(request\s+)?(was|is|got|has been|been|status\s+(is|says))\s*(approved|accepted)|(approved|accepted)\s+(my\s+)?waiver|waiver approved/.test(t)) {
      return { status: "approved", reason: null };
    }
    return null;
  }

  // --- Pre-check summary ---
  // A print-ready page the student can "Save as PDF" and attach to their real
  // waiver. Built entirely in the browser from the answers already on screen;
  // nothing is uploaded or stored.
  function escapeHtml(text) {
    return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function answerText(question, answer) {
    if (question.type === "number") return answer == null ? "(not answered)" : String(answer);
    return answer === true ? "Yes" : answer === false ? "No" : "(not answered)";
  }

  function summaryFileName(school, today) {
    return "waiver-precheck-" + school.id + "-" + isoDay(today || new Date()) + ".html";
  }

  function buildSummaryHtml(school, visa, answers, today) {
    today = today || new Date();
    var result = buildResultMessage(school, visa, answers, today);
    var parts = result.content.split("\n\n");
    var checklist = parts[0].split("\n");
    var verdictLines = parts.slice(1).join("\n\n").split("\n");
    var questions = buildQuestionQueue(school, visa, today).filter(function (q) {
      return Object.prototype.hasOwnProperty.call(answers, q.key);
    });
    var generated = MONTHS[today.getMonth()] + " " + today.getDate() + ", " + today.getFullYear();

    var rows = questions
      .map(function (q, i) {
        return "<tr><td>" + (i + 1) + "</td><td>" + escapeHtml(q.content) + "</td><td class=\"ans\">" + escapeHtml(answerText(q, answers[q.key])) + "</td></tr>";
      })
      .join("");
    var checks = checklist
      .map(function (line) {
        return "<li>" + escapeHtml(line) + "</li>";
      })
      .join("");
    var verdict = verdictLines
      .map(function (line) {
        return line.indexOf("• ") === 0 ? "<li>" + escapeHtml(line.slice(2)) + "</li>" : "<p>" + escapeHtml(line) + "</p>";
      })
      .join("")
      .replace(/(<li>[\s\S]*<\/li>)/, "<ul>$1</ul>");

    return (
      "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\">" +
      "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
      "<title>Waiver pre-check: " + escapeHtml(school.name) + "</title><style>" +
      "body{font-family:Arial,Helvetica,sans-serif;color:#222;max-width:820px;margin:24px auto;padding:0 16px;line-height:1.45}" +
      "h1{color:#7d2e8b;font-size:22px;margin-bottom:4px}h2{font-size:16px;margin-top:24px;color:#7d2e8b}" +
      ".meta{color:#555;font-size:14px}.note{background:#fff6e0;border:1px solid #e8c77a;border-radius:8px;padding:10px 12px;font-size:13px}" +
      "table{border-collapse:collapse;width:100%;font-size:13px}td,th{border:1px solid #ddd;padding:6px 8px;vertical-align:top;text-align:left}" +
      "th{background:#f3eef6}td.ans{white-space:nowrap;font-weight:bold}ul{padding-left:20px}li{margin:3px 0}" +
      "ul.checks{list-style:none;padding-left:0}button{background:#7d2e8b;color:#fff;border:none;border-radius:16px;padding:8px 16px;font-size:14px;cursor:pointer}" +
      "@media print{.noprint{display:none}body{margin:0}}" +
      "</style></head><body>" +
      "<p class=\"noprint\"><button onclick=\"window.print()\">Print / Save as PDF</button></p>" +
      "<h1>Waiver pre-check summary</h1>" +
      "<p class=\"meta\"><b>School:</b> " + escapeHtml(school.name) + " &nbsp;·&nbsp; <b>Student type:</b> " + escapeHtml(visaLabel(visa)) +
      " &nbsp;·&nbsp; <b>Checked on:</b> " + escapeHtml(generated) + "</p>" +
      "<p class=\"note\"><b>This is not a waiver approval.</b> It's a self-check made from the student's own answers in the " +
      "Aetna Student Health assistant. The school's insurance administrator decides every waiver after verifying the coverage " +
      "directly with the insurer." + (school.is_real ? "" : " This school uses example criteria for the demo.") + "</p>" +
      "<h2>Result</h2><ul class=\"checks\">" + checks + "</ul>" + verdict +
      "<h2>Questions and answers</h2><table><thead><tr><th>#</th><th>Question</th><th>Answer</th></tr></thead><tbody>" + rows + "</tbody></table>" +
      (school.source_url ? "<p class=\"meta\">School waiver policy: " + escapeHtml(school.source_url) + "</p>" : "") +
      "</body></html>"
    );
  }

  // Opens the summary in a new tab (with a Print / Save as PDF button), or
  // downloads it as a file if the browser blocks the new tab.
  function openSummary(school, visa, answers, today) {
    var html = buildSummaryHtml(school, visa, answers, today);
    var url = URL.createObjectURL(new Blob([html], { type: "text/html" }));
    var win = window.open(url, "_blank");
    if (!win) {
      var link = document.createElement("a");
      link.href = url;
      link.download = summaryFileName(school, today);
      document.body.appendChild(link);
      link.click();
      link.remove();
    }
    setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 60000);
  }

  var SUMMARY_OPTION = { label: "📄 Download my pre-check summary", value: "download-summary" };

  root.AetnaWaiverRules = {
    START_OPTION: START_OPTION,
    START_USER_TEXT: START_USER_TEXT,
    YES_NO_OPTIONS: YES_NO_OPTIONS,
    VISA_OPTIONS: VISA_OPTIONS,
    GATE_QUESTION: GATE_QUESTION,
    NOT_ELIGIBLE_NO_INSURANCE: NOT_ELIGIBLE_NO_INSURANCE,
    SCHOOL_QUESTION: SCHOOL_QUESTION,
    YES_NO_REPROMPT: YES_NO_REPROMPT,
    VISA_REPROMPT: VISA_REPROMPT,
    NUMBER_REPROMPT: NUMBER_REPROMPT,
    visaQuestion: visaQuestion,
    visaLabel: visaLabel,
    buildQuestionQueue: buildQuestionQueue,
    exitMessageFor: exitMessageFor,
    deadlineClosedMessage: deadlineClosedMessage,
    STATUS_OPTION: STATUS_OPTION,
    STATUS_USER_TEXT: STATUS_USER_TEXT,
    STATUS_QUESTION: STATUS_QUESTION,
    STATUS_OPTIONS: STATUS_OPTIONS,
    STATUS_REPROMPT: STATUS_REPROMPT,
    DENIAL_QUESTION: DENIAL_QUESTION,
    DENIAL_OPTIONS: DENIAL_OPTIONS,
    statusGuidance: statusGuidance,
    parseStatus: parseStatus,
    parseDenialReason: parseDenialReason,
    detectStatusIntent: detectStatusIntent,
    SUMMARY_OPTION: SUMMARY_OPTION,
    buildSummaryHtml: buildSummaryHtml,
    summaryFileName: summaryFileName,
    openSummary: openSummary,
    parseYesNo: parseYesNo,
    parseVisaChoice: parseVisaChoice,
    parseNumericAnswer: parseNumericAnswer,
    buildJ1NotAllowedMessage: buildJ1NotAllowedMessage,
    buildResultMessage: buildResultMessage,
  };
})(typeof window !== "undefined" ? window : globalThis);
