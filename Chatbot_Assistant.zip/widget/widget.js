/**
 * Aetna Student Health chatbot widget.
 *
 * Embed on any page with:
 *   <script src="https://your-backend-host/widget/widget.js"
 *           data-api-url="https://your-backend-host/api/chat"></script>
 *
 * Renders a floating chat bubble in the bottom-right corner that expands
 * into a chat panel talking to the FastAPI backend.
 */
(function () {
  "use strict";

  // Minimal, dependency-free Markdown renderer for assistant replies (the
  // LLM consistently outputs **bold**, "- "/"* " bullets, "1. " numbered
  // lists, and "## " headings). Text is HTML-escaped first, so this can
  // only ever produce the tags this function itself adds.
  function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function renderMarkdown(text) {
    var lines = escapeHtml(text)
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, function (_, label, url) {
        var safeUrl = url.replace(/"/g, "&quot;");
        return '<a href="' + safeUrl + '" target="_blank" rel="noopener noreferrer">' + label + "</a>";
      })
      .split("\n");
    var html = "";
    var inList = false;
    lines.forEach(function (line, i) {
      var heading = line.match(/^#{1,6}\s+(.*)$/);
      var item = line.match(/^\s*(?:[-*]|\d+\.)\s+(.*)$/);
      if (item) {
        if (!inList) {
          html += '<ul style="margin:4px 0;padding-left:18px;">';
          inList = true;
        }
        html += "<li>" + item[1] + "</li>";
      } else {
        if (inList) {
          html += "</ul>";
          inList = false;
        }
        html += heading ? "<strong>" + heading[1] + "</strong>\n" : line + (i < lines.length - 1 ? "\n" : "");
      }
    });
    if (inList) html += "</ul>";
    return html;
  }

  var scriptTag = document.currentScript;
  // Default to an API on the same origin the widget script was loaded from
  // (e.g. the backend serving both /widget/widget.js and /api/chat). Pass
  // data-api-url explicitly when the backend lives on a different host.
  var DEFAULT_API_URL = scriptTag ? new URL("/api/chat", scriptTag.src).href : "/api/chat";
  var API_URL = (scriptTag && scriptTag.getAttribute("data-api-url")) || DEFAULT_API_URL;
  var SCHOOLS_URL = API_URL.replace(/\/api\/chat$/, "/api/schools");
  var EXTRACT_CARD_URL = API_URL.replace(/\/api\/chat$/, "/api/extract-card");
  var STREAM_URL = API_URL.replace(/\/api\/chat$/, "/api/chat/stream");

  // Reads the newline-delimited JSON events from /api/chat/stream, calling
  // onEvent for each one as soon as it arrives.
  function readEvents(res, onEvent) {
    var reader = res.body.getReader();
    var decoder = new TextDecoder();
    var buffer = "";
    function pump() {
      return reader.read().then(function (chunk) {
        if (chunk.done) {
          if (buffer.trim()) onEvent(JSON.parse(buffer));
          return;
        }
        buffer += decoder.decode(chunk.value, { stream: true });
        var newline;
        while ((newline = buffer.indexOf("\n")) >= 0) {
          var line = buffer.slice(0, newline).trim();
          buffer = buffer.slice(newline + 1);
          if (line) onEvent(JSON.parse(line));
        }
        return pump();
      });
    }
    return pump();
  }

  var CARD_FIELD_LABELS = [
    ["member_name", "Name"],
    ["member_id", "Member ID"],
    ["plan_name", "Plan"],
    ["group_number", "Group #"],
    ["payer_number", "Payer #"],
    ["pcp_election", "PCP"],
    ["issuer_name", "Issuer"],
    ["phone_number", "Phone"],
  ];

  function formatCardMessage(fields) {
    var lines = CARD_FIELD_LABELS.filter(function (pair) {
      return fields[pair[0]];
    }).map(function (pair) {
      return pair[1] + ": " + fields[pair[0]];
    });
    if (lines.length === 0) {
      return "I couldn't read any details from that card image. Try a clearer photo with the whole card in frame.";
    }
    return "Here's what I found on your ID card:\n" + lines.join("\n") + "\n\nDouble-check these against the physical card before using them for anything official.";
  }

  var history = []; // {role, content}

  // Must match ChatRequest/ChatMessage limits in backend/app.py — anything
  // over them gets the whole request rejected with a 422.
  var MAX_HISTORY_MESSAGES = 20;
  var MAX_HISTORY_CONTENT_CHARS = 4000;

  function buildHistory(list) {
    return list
      .filter(function (m) {
        return m.content && m.content.trim();
      })
      .slice(-MAX_HISTORY_MESSAGES)
      .map(function (m) {
        return { role: m.role, content: m.content.slice(0, MAX_HISTORY_CONTENT_CHARS) };
      });
  }

  // FastAPI's HTTPException detail is a string, but a 422 validation error's
  // detail is an array of {msg, ...} objects.
  function errorDetail(errData, status) {
    var detail = errData && errData.detail;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail) && detail[0] && detail[0].msg) return detail[0].msg;
    return "Request failed: " + status;
  }

  // greeting | gate | school | visa | queue | done | status | statusDenied
  var waiverStep = "greeting";
  var waiverAnswers = {};
  var selectedSchool = null;
  var selectedVisa = null;
  var questionQueue = [];
  var queueIndex = 0;
  var schools = [];
  var activeQuickReplyWrap = null;

  fetch(SCHOOLS_URL)
    .then(function (res) {
      return res.json();
    })
    .then(function (data) {
      schools = data;
    })
    .catch(function () {
      schools = [];
    });

  var GREETING =
    "Hi! I can answer questions about Aetna Student Health plans, benefits, and how to use them. What would you like to know? Or, if you want to check whether you can waive the university's insurance, use the button below.";
  // Waiver walkthrough rules are shared with the React frontend and live in
  // waiver-rules.js next to this file. Loaded as a classic script (see that
  // file for why); until it arrives, the waiver button just isn't offered.
  var rules = null;
  var rulesScript = document.createElement("script");
  rulesScript.src = scriptTag ? new URL("waiver-rules.js", scriptTag.src).href : "waiver-rules.js";
  rulesScript.onload = function () {
    rules = window.AetnaWaiverRules || null;
    maybeOfferWaiverButton();
  };
  document.head.appendChild(rulesScript);

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      if (key === "style") {
        Object.assign(node.style, attrs[key]);
      } else if (key.indexOf("on") === 0) {
        node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
      } else {
        node.setAttribute(key, attrs[key]);
      }
    });
    (children || []).forEach(function (child) {
      node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
    });
    return node;
  }

  var launcher = el(
    "button",
    {
      "aria-label": "Open chat assistant",
      style: {
        position: "fixed",
        bottom: "20px",
        right: "20px",
        width: "60px",
        height: "60px",
        borderRadius: "50%",
        border: "none",
        background: "#7d2e8b",
        color: "#fff",
        fontSize: "26px",
        cursor: "pointer",
        boxShadow: "0 4px 14px rgba(0,0,0,0.25)",
        zIndex: 999999,
      },
    },
    ["💬"]
  );

  var messagesEl = el("div", {
    style: {
      flex: "1",
      overflowY: "auto",
      padding: "12px",
      display: "flex",
      flexDirection: "column",
      gap: "8px",
      background: "#f7f5fa",
    },
  });

  var input = el("input", {
    type: "text",
    placeholder: "Ask about your plan, benefits, or coverage...",
    style: {
      flex: "1",
      border: "1px solid #ccc",
      borderRadius: "18px",
      padding: "8px 14px",
      fontSize: "14px",
      outline: "none",
    },
  });

  var sendBtn = el(
    "button",
    {
      style: {
        border: "none",
        background: "#7d2e8b",
        color: "#fff",
        borderRadius: "18px",
        padding: "8px 16px",
        marginLeft: "8px",
        cursor: "pointer",
        fontSize: "14px",
      },
      onClick: function () {
        sendMessage();
      },
    },
    ["Send"]
  );

  var fileInput = el("input", {
    type: "file",
    accept: "image/*,application/pdf",
    style: { display: "none" },
    onChange: function () {
      handleCardUpload();
    },
  });

  var uploadBtn = el(
    "button",
    {
      title: "Upload your insurance ID card (photo or PDF)",
      "aria-label": "Upload your insurance ID card (photo or PDF)",
      style: {
        border: "1px solid #ccc",
        background: "#fff",
        color: "#7d2e8b",
        borderRadius: "50%",
        width: "36px",
        height: "36px",
        flex: "none",
        marginRight: "8px",
        cursor: "pointer",
        fontSize: "16px",
      },
      onClick: function () {
        fileInput.click();
      },
    },
    ["📎"]
  );

  var panel = el(
    "div",
    {
      style: {
        position: "fixed",
        bottom: "90px",
        right: "20px",
        width: "420px",
        maxWidth: "92vw",
        height: "620px",
        maxHeight: "85vh",
        background: "#fff",
        borderRadius: "12px",
        boxShadow: "0 8px 30px rgba(0,0,0,0.3)",
        display: "none",
        flexDirection: "column",
        overflow: "hidden",
        zIndex: 999999,
        fontFamily: "Arial, Helvetica, sans-serif",
      },
    },
    [
      el(
        "div",
        {
          style: {
            background: "#7d2e8b",
            color: "#fff",
            padding: "12px 14px",
            fontWeight: "bold",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          },
        },
        [
          "Aetna Student Health Assistant",
          el(
            "button",
            {
              "aria-label": "Close chat",
              style: {
                background: "none",
                border: "none",
                color: "#fff",
                fontSize: "18px",
                cursor: "pointer",
              },
              onClick: function () {
                togglePanel(false);
              },
            },
            ["✕"]
          ),
        ]
      ),
      messagesEl,
      el(
        "div",
        {
          style: {
            display: "flex",
            padding: "10px",
            borderTop: "1px solid #eee",
            background: "#fff",
          },
        },
        [fileInput, uploadBtn, input, sendBtn]
      ),
    ]
  );

  document.body.appendChild(panel);
  document.body.appendChild(launcher);

  function togglePanel(forceOpen) {
    var isOpen = panel.style.display === "flex";
    var next = typeof forceOpen === "boolean" ? forceOpen : !isOpen;
    panel.style.display = next ? "flex" : "none";
    if (next && messagesEl.children.length === 0) {
      addBubble("assistant", GREETING);
      greetingShown = true;
      maybeOfferWaiverButton();
    }
  }

  var greetingShown = false;
  var waiverButtonOffered = false;

  function maybeOfferWaiverButton() {
    if (!rules || !greetingShown || waiverButtonOffered) return;
    waiverButtonOffered = true;
    addQuickReplies([rules.START_OPTION, rules.STATUS_OPTION]);
  }

  function removeActiveQuickReplies() {
    if (activeQuickReplyWrap) {
      activeQuickReplyWrap.remove();
      activeQuickReplyWrap = null;
    }
  }

  function addQuickReplies(options) {
    var wrap = el("div", { style: { display: "flex", gap: "8px", flexWrap: "wrap", alignSelf: "flex-start" } });
    options.forEach(function (opt) {
      var btn = el(
        "button",
        {
          style: {
            border: "1px solid #7d2e8b",
            background: "#fff",
            color: "#7d2e8b",
            borderRadius: "14px",
            padding: "6px 16px",
            fontSize: "13px",
            cursor: "pointer",
          },
          onClick: function () {
            wrap.remove();
            activeQuickReplyWrap = null;
            var handler = STEP_HANDLERS[waiverStep];
            if (handler) handler(opt.value);
          },
        },
        [opt.label]
      );
      wrap.appendChild(btn);
    });
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    activeQuickReplyWrap = wrap;
    return wrap;
  }

  function addSchoolDropdown() {
    var select = el("select", {
      style: {
        flex: "1",
        minWidth: "0",
        border: "1px solid #ccc",
        borderRadius: "8px",
        padding: "6px 8px",
        fontSize: "13px",
      },
    });
    select.appendChild(el("option", { value: "", disabled: "", selected: "" }, ["Choose your school..."]));
    schools.forEach(function (s) {
      select.appendChild(el("option", { value: s.id }, [s.name]));
    });

    var wrap = el("div", { style: { display: "flex", gap: "8px", alignSelf: "flex-start", maxWidth: "100%" } });
    var confirmBtn = el(
      "button",
      {
        style: {
          border: "none",
          background: "#7d2e8b",
          color: "#fff",
          borderRadius: "14px",
          padding: "6px 14px",
          fontSize: "13px",
          cursor: "pointer",
          flex: "none",
        },
        onClick: function () {
          if (!select.value) return;
          wrap.remove();
          handleSchoolAnswer(select.value);
        },
      },
      ["Continue"]
    );

    wrap.appendChild(select);
    wrap.appendChild(confirmBtn);
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return wrap;
  }

  function say(role, text) {
    addBubble(role, text);
    history.push({ role: role, content: text });
  }

  function sayWithSources(message) {
    say("assistant", message.content);
    addSources(message.sources);
  }

  function currentQuestion() {
    return questionQueue[queueIndex];
  }

  function askCurrentQuestion() {
    var q = currentQuestion();
    say("assistant", q.content);
    if (q.type === "yesno") addQuickReplies(rules.YES_NO_OPTIONS);
    else input.focus();
  }

  function advanceQueueAfterAnswer() {
    if (queueIndex + 1 < questionQueue.length) {
      queueIndex += 1;
      askCurrentQuestion();
    } else {
      finishWithResult();
    }
  }

  function handleStartWaiver() {
    say("user", rules.START_USER_TEXT);
    say("assistant", rules.GATE_QUESTION);
    addQuickReplies(rules.YES_NO_OPTIONS);
    waiverStep = "gate";
  }

  function handleGateAnswer(value, userLabel) {
    var label = userLabel || (value === "no" ? "No" : "Yes");
    if (value === "no") {
      say("user", label);
      sayWithSources(rules.NOT_ELIGIBLE_NO_INSURANCE);
      waiverStep = "done";
      return;
    }
    say("user", label);
    say("assistant", rules.SCHOOL_QUESTION);
    addSchoolDropdown();
    waiverStep = "school";
  }

  function handleSchoolAnswer(schoolId) {
    var school = schools.filter(function (s) {
      return s.id === schoolId;
    })[0];
    if (!school) return;
    selectedSchool = school;
    say("user", school.name);
    // A school whose once-a-year deadline has passed has nothing left to check.
    var closed = rules.deadlineClosedMessage(school);
    if (closed) {
      sayWithSources(closed);
      waiverStep = "done";
      return;
    }
    say("assistant", rules.visaQuestion(school));
    addQuickReplies(rules.VISA_OPTIONS);
    waiverStep = "visa";
  }

  function handleVisaAnswer(value, userLabel) {
    selectedVisa = value;
    say("user", userLabel || rules.visaLabel(value));

    if (value === "J-1" && !selectedSchool.j1_waiver_allowed) {
      sayWithSources(rules.buildJ1NotAllowedMessage(selectedSchool));
      waiverStep = "done";
      return;
    }

    questionQueue = rules.buildQuestionQueue(selectedSchool, value);
    queueIndex = 0;
    waiverAnswers = {};
    waiverStep = "queue";
    askCurrentQuestion();
  }

  function handleQueueButtonAnswer(value, userLabel) {
    var q = currentQuestion();
    if (!q) return;
    say("user", userLabel || (value === "yes" ? "Yes" : "No"));
    // Some answers end the walkthrough early (e.g. the deadline has passed).
    var exit = rules.exitMessageFor(q, value === "yes");
    if (exit) {
      sayWithSources(exit);
      waiverStep = "done";
      return;
    }
    waiverAnswers[q.key] = value === "yes";
    advanceQueueAfterAnswer();
  }

  function finishWithResult() {
    sayWithSources(rules.buildResultMessage(selectedSchool, selectedVisa, waiverAnswers));
    waiverStep = "done";
    // Snapshot this result so the button keeps working after later chats.
    var school = selectedSchool;
    var visa = selectedVisa;
    var answers = Object.assign({}, waiverAnswers);
    addActionButton(rules.SUMMARY_OPTION.label, function () {
      rules.openSummary(school, visa, answers);
    });
  }

  // --- Waiver status helper (for a waiver already submitted) ---
  function handleStatusStart() {
    say("user", rules.STATUS_USER_TEXT);
    say("assistant", rules.STATUS_QUESTION);
    addQuickReplies(rules.STATUS_OPTIONS);
    waiverStep = "status";
  }

  function optionLabel(options, value) {
    var match = options.filter(function (o) {
      return o.value === value;
    })[0];
    return match ? match.label : value;
  }

  function handleStatusAnswer(value, userLabel) {
    var label = userLabel || optionLabel(rules.STATUS_OPTIONS, value);
    if (value === "denied") askDenialReason(label);
    else showStatusGuidance(value, label);
  }

  function askDenialReason(userLabel) {
    say("user", userLabel);
    say("assistant", rules.DENIAL_QUESTION);
    addQuickReplies(rules.DENIAL_OPTIONS);
    waiverStep = "statusDenied";
  }

  function handleDenialReason(value, userLabel) {
    showStatusGuidance(value, userLabel || optionLabel(rules.DENIAL_OPTIONS, value));
  }

  // Shows the guidance, then offers both starting points again.
  function showStatusGuidance(key, userLabel) {
    say("user", userLabel);
    sayWithSources(rules.statusGuidance(key));
    addQuickReplies([rules.START_OPTION, rules.STATUS_OPTION]);
    waiverStep = "greeting";
  }

  function handleGreetingButton(value) {
    if (value === rules.STATUS_OPTION.value) handleStatusStart();
    else handleStartWaiver();
  }

  var STEP_HANDLERS = {
    greeting: handleGreetingButton,
    gate: handleGateAnswer,
    school: handleSchoolAnswer,
    visa: handleVisaAnswer,
    queue: handleQueueButtonAnswer,
    status: handleStatusAnswer,
    statusDenied: handleDenialReason,
  };

  launcher.addEventListener("click", function () {
    togglePanel();
  });

  function setBubbleContent(bubble, role, text) {
    if (role === "assistant") {
      bubble.innerHTML = renderMarkdown(text);
    } else {
      bubble.textContent = text;
    }
  }

  function formatTime(date) {
    return date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  }

  function timeCaption(align) {
    return el("div", { style: { fontSize: "15px", color: "#888", marginTop: "2px", padding: "0 4px", alignSelf: align } }, [formatTime(new Date())]);
  }

  function addBubble(role, text) {
    var bubbleStyle = {
      alignSelf: role === "user" ? "flex-end" : "flex-start",
      background: role === "user" ? "#7d2e8b" : "#ffffff",
      color: role === "user" ? "#fff" : "#222",
      border: role === "user" ? "none" : "1px solid #e0dbe5",
      padding: "8px 12px",
      borderRadius: "14px",
      maxWidth: role === "user" ? "92%" : "80%",
      fontSize: "14px",
      lineHeight: "1.4",
      whiteSpace: "pre-wrap",
      overflowWrap: "anywhere",
    };

    if (role === "user") {
      var userBubble = el("div", { style: bubbleStyle });
      userBubble.dataset.role = role;
      setBubbleContent(userBubble, role, text);
      var userCol = el("div", { style: { display: "flex", flexDirection: "column", alignItems: "flex-end" } }, [
        userBubble,
        timeCaption("flex-end"),
      ]);
      messagesEl.appendChild(userCol);
      messagesEl.scrollTop = messagesEl.scrollHeight;
      return userBubble;
    }

    var avatar = el(
      "div",
      {
        style: {
          flex: "none",
          width: "28px",
          height: "28px",
          borderRadius: "50%",
          background: "linear-gradient(135deg, #c77dd1, #7d2e8b)",
          color: "#fff",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "14px",
          marginTop: "2px",
        },
      },
      ["♥"]
    );
    bubbleStyle.maxWidth = "calc(80% - 36px)";
    var bubble = el("div", { style: bubbleStyle });
    bubble.dataset.role = role;
    setBubbleContent(bubble, role, text);
    var assistantCol = el("div", { style: { display: "flex", flexDirection: "column", alignItems: "flex-start" } }, [
      bubble,
      timeCaption("flex-start"),
    ]);
    var row = el(
      "div",
      { style: { display: "flex", gap: "8px", alignItems: "flex-start", alignSelf: "flex-start", maxWidth: "100%" } },
      [avatar, assistantCol]
    );
    messagesEl.appendChild(row);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return bubble;
  }

  function addSources(sources) {
    if (!sources || sources.length === 0) return;
    var links = sources.map(function (s) {
      return el("a", { href: s.url, target: "_blank", rel: "noopener", style: { color: "#7d2e8b", display: "block", fontSize: "12px" } }, [s.title]);
    });
    var wrap = el(
      "div",
      { style: { alignSelf: "flex-start", fontSize: "12px", color: "#666", maxWidth: "80%" } },
      ["Learn more:"].concat(links)
    );
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function addUploadSuggestion() {
    addActionButton("📎 Upload your ID card (photo or PDF)", function () {
      fileInput.click();
    });
  }

  // A button that stays in the chat (unlike quick replies, which disappear once used).
  function addActionButton(label, onClick) {
    var wrap = el("div", { style: { display: "flex", alignSelf: "flex-start" } });
    var btn = el(
      "button",
      {
        style: {
          border: "1px solid #7d2e8b",
          background: "#fff",
          color: "#7d2e8b",
          borderRadius: "14px",
          padding: "6px 16px",
          fontSize: "13px",
          cursor: "pointer",
        },
        onClick: onClick,
      },
      [label]
    );
    wrap.appendChild(btn);
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function sendMessage() {
    var text = input.value.trim();
    if (!text) return;
    input.value = "";

    if (waiverStep === "queue" && currentQuestion() && currentQuestion().type === "number") {
      var amount = rules.parseNumericAnswer(text);
      say("user", text);
      if (amount === null) {
        say("assistant", rules.NUMBER_REPROMPT);
        return;
      }
      waiverAnswers[currentQuestion().key] = amount;
      advanceQueueAfterAnswer();
      return;
    }

    if (waiverStep === "gate" || (waiverStep === "queue" && currentQuestion() && currentQuestion().type === "yesno")) {
      var yn = rules.parseYesNo(text);
      if (yn === null) {
        say("user", text);
        say("assistant", rules.YES_NO_REPROMPT);
        return;
      }
      if (activeQuickReplyWrap) {
        activeQuickReplyWrap.remove();
        activeQuickReplyWrap = null;
      }
      if (waiverStep === "gate") handleGateAnswer(yn ? "yes" : "no", text);
      else handleQueueButtonAnswer(yn ? "yes" : "no", text);
      return;
    }

    if (waiverStep === "visa") {
      var visa = rules.parseVisaChoice(text);
      if (!visa) {
        say("user", text);
        say("assistant", rules.VISA_REPROMPT);
        return;
      }
      if (activeQuickReplyWrap) {
        activeQuickReplyWrap.remove();
        activeQuickReplyWrap = null;
      }
      handleVisaAnswer(visa, text);
      return;
    }

    if (waiverStep === "status") {
      var status = rules.parseStatus(text);
      if (!status) {
        say("user", text);
        say("assistant", rules.STATUS_REPROMPT);
        return;
      }
      removeActiveQuickReplies();
      handleStatusAnswer(status, text);
      return;
    }

    if (waiverStep === "statusDenied") {
      removeActiveQuickReplies();
      handleDenialReason(rules.parseDenialReason(text) || "unsure", text);
      return;
    }

    // "My waiver was denied" and similar get the fixed, sourced guidance
    // instead of going to the model.
    var statusIntent = rules && (waiverStep === "greeting" || waiverStep === "done") && rules.detectStatusIntent(text);
    if (statusIntent) {
      removeActiveQuickReplies();
      if (statusIntent.status === "denied" && !statusIntent.reason) askDenialReason(text);
      else showStatusGuidance(statusIntent.reason || statusIntent.status, text);
      return;
    }

    addBubble("user", text);
    history.push({ role: "user", content: text });

    // The "..." bubble turns into the reply as its words stream in.
    var typing = addBubble("assistant", "...");
    var reply = "";
    var finished = false;

    fetch(STREAM_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, history: buildHistory(history.slice(0, -1)) }),
    })
      .then(function (res) {
        if (!res.ok) {
          return res
            .json()
            .catch(function () {
              return {};
            })
            .then(function (errData) {
              throw new Error(errorDetail(errData, res.status));
            });
        }
        return readEvents(res, function (event) {
          if (event.type === "delta") {
            reply += event.text;
            setBubbleContent(typing, "assistant", reply);
            messagesEl.scrollTop = messagesEl.scrollHeight;
          } else if (event.type === "done") {
            finished = true;
            setBubbleContent(typing, "assistant", event.reply);
            history.push({ role: "assistant", content: event.reply });
            addSources(event.sources);
            if (event.suggest_card_upload) addUploadSuggestion();
          } else if (event.type === "error") {
            throw new Error(event.detail);
          }
        });
      })
      .then(function () {
        if (!finished) throw new Error("the connection closed before the answer finished");
      })
      .catch(function (err) {
        var detail = err && err.message ? err.message : "unknown error";
        var message = "Sorry, something went wrong: " + detail + ". Please try again or use Contact Us.";
        // Keep any words that already arrived; put the error in its own bubble.
        if (reply) addBubble("assistant", message);
        else setBubbleContent(typing, "assistant", message);
      });
  }

  function handleCardUpload() {
    var file = fileInput.files && fileInput.files[0];
    fileInput.value = ""; // allow re-selecting the same file later
    if (!file) return;

    addBubble("user", "📎 Uploaded: " + file.name);

    var typing = addBubble("assistant", "...");
    var formData = new FormData();
    formData.append("file", file);

    fetch(EXTRACT_CARD_URL, { method: "POST", body: formData })
      .then(function (res) {
        if (!res.ok) {
          return res
            .json()
            .catch(function () {
              return {};
            })
            .then(function (errData) {
              throw new Error(errorDetail(errData, res.status));
            });
        }
        return res.json();
      })
      .then(function (fields) {
        setBubbleContent(typing, "assistant", formatCardMessage(fields));
      })
      .catch(function (err) {
        var detail = err && err.message ? err.message : "unknown error";
        setBubbleContent(typing, "assistant", "Sorry, I couldn't read that card: " + detail);
      });
  }

  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter") sendMessage();
  });
})();
