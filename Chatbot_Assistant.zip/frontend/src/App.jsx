import { useEffect, useRef, useState } from 'react'
import './App.css'
// Shared with the embeddable widget; sets globalThis.AetnaWaiverRules (see that file for why it's not an ES module).
import '../../widget/waiver-rules.js'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8731/api/chat'
const API_BASE = API_URL.replace(/\/api\/chat$/, '')
const SCHOOLS_URL = `${API_BASE}/api/schools`
const EXTRACT_CARD_URL = `${API_BASE}/api/extract-card`
const STREAM_URL = `${API_BASE}/api/chat/stream`

// Reads the newline-delimited JSON events from /api/chat/stream, calling
// onEvent for each one as soon as it arrives.
async function readEvents(res, onEvent) {
  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  for (;;) {
    const { value, done } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    let newline
    while ((newline = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, newline).trim()
      buffer = buffer.slice(newline + 1)
      if (line) onEvent(JSON.parse(line))
    }
  }
  if (buffer.trim()) onEvent(JSON.parse(buffer))
}

// Must match ChatRequest/ChatMessage limits in backend/app.py — anything
// over them gets the whole request rejected with a 422.
const MAX_HISTORY_MESSAGES = 20
const MAX_HISTORY_CONTENT_CHARS = 4000

function buildHistory(messages) {
  return messages
    .filter((m) => (m.role === 'user' || m.role === 'assistant') && m.content?.trim())
    .slice(-MAX_HISTORY_MESSAGES)
    .map((m) => ({ role: m.role, content: m.content.slice(0, MAX_HISTORY_CONTENT_CHARS) }))
}

// FastAPI's HTTPException detail is a string, but a 422 validation error's
// detail is an array of {msg, ...} objects.
function errorDetail(errData, status) {
  const detail = errData?.detail
  if (typeof detail === 'string') return detail
  if (Array.isArray(detail) && detail[0]?.msg) return detail[0].msg
  return `Request failed (${status})`
}

// Minimal, dependency-free Markdown renderer for assistant replies (the LLM
// consistently outputs **bold**, "- "/"* " bullets, "1. " numbered lists,
// and "## " headings — plain-text rendering showed these literally). Text
// is HTML-escaped first, so this can only ever produce the tags this
// function itself adds — it can't be used to inject real markup.
function escapeHtml(text) {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function renderMarkdown(text) {
  const lines = escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, label, url) => {
      const safeUrl = url.replace(/"/g, '&quot;')
      return `<a href="${safeUrl}" target="_blank" rel="noopener noreferrer">${label}</a>`
    })
    .split('\n')
  let html = ''
  let inList = false
  lines.forEach((line, i) => {
    const heading = line.match(/^#{1,6}\s+(.*)$/)
    const item = line.match(/^\s*(?:[-*]|\d+\.)\s+(.*)$/)
    if (item) {
      if (!inList) {
        html += '<ul style="margin:4px 0;padding-left:18px;">'
        inList = true
      }
      html += `<li>${item[1]}</li>`
    } else {
      if (inList) {
        html += '</ul>'
        inList = false
      }
      html += heading ? `<strong>${heading[1]}</strong>\n` : line + (i < lines.length - 1 ? '\n' : '')
    }
  })
  if (inList) html += '</ul>'
  return html
}

const CARD_FIELD_LABELS = {
  member_name: 'Name',
  member_id: 'Member ID',
  plan_name: 'Plan',
  group_number: 'Group #',
  payer_number: 'Payer #',
  pcp_election: 'PCP',
  issuer_name: 'Issuer',
  phone_number: 'Phone',
}

// Shared constant messages (GREETING, WAIVER_QUESTION, the ASK_* queue
// questions, etc.) are singleton objects reused across every conversation —
// they can't carry a hardcoded time. withTime() clones a message and stamps
// it with "now" at the moment it's actually shown, whether it's a constant
// or a freshly built object.
function withTime(msg) {
  return { ...msg, time: new Date() }
}

function formatTime(date) {
  return date ? date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : ''
}

function formatCardMessage(fields) {
  const lines = Object.entries(CARD_FIELD_LABELS)
    .filter(([key]) => fields[key])
    .map(([key, label]) => `${label}: ${fields[key]}`)
  if (lines.length === 0) {
    return "I couldn't read any details from that card image. Try a clearer photo with the whole card in frame."
  }
  return `Here's what I found on your ID card:\n${lines.join('\n')}\n\nDouble-check these against the physical card before using them for anything official.`
}

const GREETING_ID = 'greeting'
const WAIVER_GATE_ID = 'waiver-gate'
const SCHOOL_SELECT_ID = 'waiver-school-select'
const VISA_SELECT_ID = 'waiver-visa-select'
const QUEUE_QUESTION_ID = 'waiver-queue-question'
const STATUS_QUESTION_ID = 'waiver-status-question'
const DENIAL_QUESTION_ID = 'waiver-denial-question'

const waiver = globalThis.AetnaWaiverRules

const GREETING = {
  id: GREETING_ID,
  role: 'assistant',
  content:
    "Hi! I can answer questions about Aetna Student Health plans, benefits, and how to use them. What would you like to know? Or, if you want to check whether you can waive the university's insurance, use the button below.",
  sources: [],
  buttons: [waiver.START_OPTION, waiver.STATUS_OPTION],
}

const WAIVER_QUESTION = {
  id: WAIVER_GATE_ID,
  role: 'assistant',
  content: waiver.GATE_QUESTION,
  sources: [],
  buttons: waiver.YES_NO_OPTIONS,
}

export default function App() {
  const [messages, setMessages] = useState([withTime(GREETING)])
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [streaming, setStreaming] = useState(false) // true once the reply's first words have arrived
  const [chatOpen, setChatOpen] = useState(false)
  const [schools, setSchools] = useState([])
  const [waiverStep, setWaiverStep] = useState('greeting') // greeting | gate | school | visa | queue | done | status | statusDenied
  const [selectedSchool, setSelectedSchool] = useState(null)
  const [selectedVisa, setSelectedVisa] = useState(null)
  const [questionQueue, setQuestionQueue] = useState([])
  const [queueIndex, setQueueIndex] = useState(0)
  const [waiverAnswers, setWaiverAnswers] = useState({})
  const [schoolChoice, setSchoolChoice] = useState('')
  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)
  const fileInputRef = useRef(null)
  const replyCount = useRef(0) // gives each streamed reply its own message id

  useEffect(() => {
    fetch(SCHOOLS_URL)
      .then((res) => res.json())
      .then(setSchools)
      .catch(() => setSchools([]))
  }, [])

  useEffect(() => {
    if (chatOpen) messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, chatOpen])

  useEffect(() => {
    if (chatOpen) inputRef.current?.focus()
  }, [chatOpen])

  function stripButtons(prev, id) {
    return prev.map((m) => (m.id === id ? { ...m, buttons: null, schoolSelect: false } : m))
  }

  function currentQuestion() {
    return questionQueue[queueIndex]
  }

  function advanceQueueAfterAnswer(nextAnswers) {
    if (queueIndex + 1 < questionQueue.length) {
      const next = questionQueue[queueIndex + 1]
      setMessages((p) => [
        ...stripButtons(p, QUEUE_QUESTION_ID),
        withTime({ id: QUEUE_QUESTION_ID, role: 'assistant', content: next.content, sources: [], buttons: next.type === 'yesno' ? waiver.YES_NO_OPTIONS : null }),
      ])
      setQueueIndex((i) => i + 1)
      if (next.type === 'number') inputRef.current?.focus()
    } else {
      setMessages((p) => [
        ...stripButtons(p, QUEUE_QUESTION_ID),
        withTime({ role: 'assistant', ...waiver.buildResultMessage(selectedSchool, selectedVisa, nextAnswers), buttons: [waiver.SUMMARY_OPTION] }),
      ])
      setWaiverStep('done')
    }
  }

  async function sendMessage() {
    const text = input.trim()
    if (!text || sending) return

    if (waiverStep === 'queue' && currentQuestion()?.type === 'number') {
      const amount = waiver.parseNumericAnswer(text)
      setInput('')
      setMessages((p) => [...p, withTime({ role: 'user', content: text })])
      if (amount === null) {
        setMessages((p) => [
          ...p,
          withTime({
            role: 'assistant',
            content: waiver.NUMBER_REPROMPT,
            sources: [],
          }),
        ])
        return
      }
      // Compute the next answers snapshot directly (not via a setState
      // updater) before advancing the queue — advanceQueueAfterAnswer has
      // side effects (setMessages/setQueueIndex/setWaiverStep), and calling
      // it from inside an updater breaks under StrictMode's deliberate
      // double-invocation of updaters, silently desyncing queueIndex.
      const next = { ...waiverAnswers, [currentQuestion().key]: amount }
      setWaiverAnswers(next)
      advanceQueueAfterAnswer(next)
      return
    }

    if (waiverStep === 'gate' || (waiverStep === 'queue' && currentQuestion()?.type === 'yesno')) {
      const parsed = waiver.parseYesNo(text)
      setInput('')
      if (parsed === null) {
        setMessages((p) => [
          ...p,
          withTime({ role: 'user', content: text }),
          withTime({ role: 'assistant', content: waiver.YES_NO_REPROMPT, sources: [] }),
        ])
        return
      }
      if (waiverStep === 'gate') handleGateAnswer(parsed ? 'yes' : 'no', text)
      else handleQueueButtonAnswer(parsed ? 'yes' : 'no', text)
      return
    }

    if (waiverStep === 'visa') {
      const visa = waiver.parseVisaChoice(text)
      setInput('')
      if (!visa) {
        setMessages((p) => [
          ...p,
          withTime({ role: 'user', content: text }),
          withTime({ role: 'assistant', content: waiver.VISA_REPROMPT, sources: [] }),
        ])
        return
      }
      handleVisaAnswer(visa, text)
      return
    }

    if (waiverStep === 'status') {
      const status = waiver.parseStatus(text)
      setInput('')
      if (!status) {
        setMessages((p) => [
          ...p,
          withTime({ role: 'user', content: text }),
          withTime({ role: 'assistant', content: waiver.STATUS_REPROMPT, sources: [] }),
        ])
        return
      }
      handleStatusAnswer(status, text)
      return
    }

    if (waiverStep === 'statusDenied') {
      setInput('')
      handleDenialReason(waiver.parseDenialReason(text) || 'unsure', text)
      return
    }

    // "My waiver was denied" and similar get the fixed, sourced guidance
    // instead of going to the model.
    const statusIntent = (waiverStep === 'greeting' || waiverStep === 'done') && waiver.detectStatusIntent(text)
    if (statusIntent) {
      setInput('')
      if (statusIntent.status === 'denied' && !statusIntent.reason) {
        askDenialReason(text, GREETING_ID)
      } else {
        showStatusGuidance(statusIntent.reason || statusIntent.status, text, GREETING_ID)
      }
      return
    }

    const history = buildHistory(messages)

    setMessages((prev) => [...prev, withTime({ role: 'user', content: text })])
    setInput('')
    setSending(true)

    // The reply streams into one message that's added on its first words
    // and updated as more arrive.
    const replyId = `reply-${++replyCount.current}`
    const upsertReply = (fields) =>
      setMessages((prev) =>
        prev.some((m) => m.id === replyId)
          ? prev.map((m) => (m.id === replyId ? { ...m, ...fields } : m))
          : [...prev, withTime({ id: replyId, role: 'assistant', sources: [], ...fields })],
      )

    try {
      const res = await fetch(STREAM_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history }),
      })
      if (!res.ok) {
        let errData = null
        try {
          errData = await res.json()
        } catch {
          // response body wasn't JSON — fall back to the generic detail
        }
        throw new Error(errorDetail(errData, res.status))
      }
      let reply = ''
      let finished = false
      await readEvents(res, (event) => {
        if (event.type === 'delta') {
          reply += event.text
          setStreaming(true)
          upsertReply({ content: reply })
        } else if (event.type === 'done') {
          finished = true
          upsertReply({
            content: event.reply,
            sources: event.sources || [],
            escalation: event.escalation,
            suggestCardUpload: event.suggest_card_upload,
          })
        } else if (event.type === 'error') {
          throw new Error(event.detail)
        }
      })
      if (!finished) throw new Error('the connection closed before the answer finished')
    } catch (err) {
      const detail = err instanceof Error && err.message ? err.message : 'unknown error'
      setMessages((prev) => [
        ...prev,
        withTime({
          role: 'assistant',
          content: `Sorry, something went wrong: ${detail}. Please try again or use Contact Us.`,
          sources: [],
        }),
      ])
    } finally {
      setSending(false)
      setStreaming(false)
    }
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter') sendMessage()
  }

  async function handleCardUpload(e) {
    const file = e.target.files?.[0]
    e.target.value = '' // allow re-selecting the same file later
    if (!file) return

    setMessages((prev) => [...prev, withTime({ role: 'user', content: `📎 Uploaded: ${file.name}` })])
    setSending(true)

    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch(EXTRACT_CARD_URL, { method: 'POST', body: formData })
      if (!res.ok) {
        let errData = null
        try {
          errData = await res.json()
        } catch {
          // response body wasn't JSON — fall back to the generic detail
        }
        throw new Error(errorDetail(errData, res.status))
      }
      const fields = await res.json()
      setMessages((prev) => [...prev, withTime({ role: 'assistant', content: formatCardMessage(fields), sources: [] })])
    } catch (err) {
      const detail = err instanceof Error && err.message ? err.message : 'unknown error'
      setMessages((prev) => [...prev, withTime({ role: 'assistant', content: `Sorry, I couldn't read that card: ${detail}`, sources: [] })])
    } finally {
      setSending(false)
    }
  }

  // --- Waiver status helper (for a waiver already submitted) ---
  function handleStatusStart() {
    setMessages((prev) => [
      ...stripButtons(prev, GREETING_ID),
      withTime({ role: 'user', content: waiver.STATUS_USER_TEXT }),
      withTime({ id: STATUS_QUESTION_ID, role: 'assistant', content: waiver.STATUS_QUESTION, sources: [], buttons: waiver.STATUS_OPTIONS }),
    ])
    setWaiverStep('status')
  }

  function handleStatusAnswer(value, userLabel) {
    const label = userLabel ?? waiver.STATUS_OPTIONS.find((o) => o.value === value)?.label
    if (value === 'denied') askDenialReason(label, STATUS_QUESTION_ID)
    else showStatusGuidance(value, label, STATUS_QUESTION_ID)
  }

  function askDenialReason(userLabel, stripId) {
    setMessages((prev) => [
      ...stripButtons(prev, stripId),
      withTime({ role: 'user', content: userLabel }),
      withTime({ id: DENIAL_QUESTION_ID, role: 'assistant', content: waiver.DENIAL_QUESTION, sources: [], buttons: waiver.DENIAL_OPTIONS }),
    ])
    setWaiverStep('statusDenied')
  }

  function handleDenialReason(value, userLabel) {
    const label = userLabel ?? waiver.DENIAL_OPTIONS.find((o) => o.value === value)?.label
    showStatusGuidance(value, label, DENIAL_QUESTION_ID)
  }

  // Shows the guidance, then offers both starting points again.
  function showStatusGuidance(key, userLabel, stripId) {
    setMessages((prev) => [
      ...stripButtons(prev, stripId),
      withTime({ role: 'user', content: userLabel }),
      withTime({ id: GREETING_ID, role: 'assistant', ...waiver.statusGuidance(key), buttons: [waiver.START_OPTION, waiver.STATUS_OPTION] }),
    ])
    setWaiverStep('greeting')
  }

  function handleGreetingButton(value) {
    if (value === waiver.STATUS_OPTION.value) handleStatusStart()
    else handleStartWaiver()
  }

  function handleStartWaiver() {
    setMessages((prev) => [
      ...stripButtons(prev, GREETING_ID),
      withTime({ role: 'user', content: waiver.START_USER_TEXT }),
      withTime(WAIVER_QUESTION),
    ])
    setWaiverStep('gate')
  }

  function handleGateAnswer(value, userLabel) {
    const label = userLabel ?? (value === 'no' ? 'No' : 'Yes')
    if (value === 'no') {
      setMessages((prev) => [...stripButtons(prev, WAIVER_GATE_ID), withTime({ role: 'user', content: label }), withTime({ role: 'assistant', ...waiver.NOT_ELIGIBLE_NO_INSURANCE })])
      setWaiverStep('done')
      return
    }
    setMessages((prev) => [
      ...stripButtons(prev, WAIVER_GATE_ID),
      withTime({ role: 'user', content: label }),
      withTime({
        id: SCHOOL_SELECT_ID,
        role: 'assistant',
        content: waiver.SCHOOL_QUESTION,
        sources: [],
        schoolSelect: true,
      }),
    ])
    setWaiverStep('school')
  }

  function handleSchoolAnswer(schoolId) {
    const school = schools.find((s) => s.id === schoolId)
    if (!school) return
    setSelectedSchool(school)
    setSchoolChoice('')
    // A school whose once-a-year deadline has passed has nothing left to check.
    const closed = waiver.deadlineClosedMessage(school)
    if (closed) {
      setMessages((prev) => [
        ...stripButtons(prev, SCHOOL_SELECT_ID),
        withTime({ role: 'user', content: school.name }),
        withTime({ role: 'assistant', ...closed }),
      ])
      setWaiverStep('done')
      return
    }
    setMessages((prev) => [
      ...stripButtons(prev, SCHOOL_SELECT_ID),
      withTime({ role: 'user', content: school.name }),
      withTime({
        id: VISA_SELECT_ID,
        role: 'assistant',
        content: waiver.visaQuestion(school),
        sources: [],
        buttons: waiver.VISA_OPTIONS,
      }),
    ])
    setWaiverStep('visa')
  }

  function handleVisaAnswer(value, userLabel) {
    setSelectedVisa(value)
    const label = userLabel ?? waiver.visaLabel(value)

    if (value === 'J-1' && !selectedSchool.j1_waiver_allowed) {
      setMessages((prev) => [...stripButtons(prev, VISA_SELECT_ID), withTime({ role: 'user', content: label }), withTime({ role: 'assistant', ...waiver.buildJ1NotAllowedMessage(selectedSchool) })])
      setWaiverStep('done')
      return
    }

    const queue = waiver.buildQuestionQueue(selectedSchool, value)
    setQuestionQueue(queue)
    setQueueIndex(0)
    setWaiverAnswers({})
    const first = queue[0]
    setMessages((prev) => [
      ...stripButtons(prev, VISA_SELECT_ID),
      withTime({ role: 'user', content: label }),
      withTime({ id: QUEUE_QUESTION_ID, role: 'assistant', content: first.content, sources: [], buttons: first.type === 'yesno' ? waiver.YES_NO_OPTIONS : null }),
    ])
    setWaiverStep('queue')
    if (first.type === 'number') inputRef.current?.focus()
  }

  function handleQueueButtonAnswer(value, userLabel) {
    const q = currentQuestion()
    if (!q) return
    const parsed = value === 'yes'
    const label = userLabel ?? (value === 'yes' ? 'Yes' : 'No')
    setMessages((p) => [...stripButtons(p, QUEUE_QUESTION_ID), withTime({ role: 'user', content: label })])
    // Some answers end the walkthrough early (e.g. the deadline has passed).
    const exit = waiver.exitMessageFor(q, parsed)
    if (exit) {
      setMessages((p) => [...p, withTime({ role: 'assistant', ...exit })])
      setWaiverStep('done')
      return
    }
    const next = { ...waiverAnswers, [q.key]: parsed }
    setWaiverAnswers(next)
    advanceQueueAfterAnswer(next)
  }

  const BUTTON_HANDLERS = {
    greeting: handleGreetingButton,
    gate: handleGateAnswer,
    school: handleSchoolAnswer,
    visa: handleVisaAnswer,
    queue: handleQueueButtonAnswer,
    status: handleStatusAnswer,
    statusDenied: handleDenialReason,
  }

  function handleButton(value) {
    // The summary button stays on the result, so it works at any step.
    if (value === waiver.SUMMARY_OPTION.value) {
      if (selectedSchool) waiver.openSummary(selectedSchool, selectedVisa, waiverAnswers)
      return
    }
    BUTTON_HANDLERS[waiverStep]?.(value)
  }

  return (
    <div className="chat-page">
      <div className="hero">
        <div className="hero-text">
          <h1>Welcome to Aetna Student Health</h1>
          <p>
            Health plans created with you in mind. We're here to support your
            well-being. With expert care. Extra support. A simple experience.
            Choose your school to get started with enrollment, waiver options,
            and more.
          </p>
        </div>
      </div>

      {chatOpen && (
        <div className="chat-panel">
          <header className="chat-header">
            Aetna Student Health Assistant
            <button className="chat-close" aria-label="Close chat" onClick={() => setChatOpen(false)}>
              ✕
            </button>
          </header>

          <div className="chat-messages">
            {messages.map((m, i) => (
              <div key={i} className={`bubble-row ${m.role}`}>
                {m.role === 'assistant' && <div className="avatar">♥</div>}
                <div className="bubble-content">
                  {m.role === 'assistant' ? (
                    <div
                      className={`bubble ${m.role} ${m.escalation ? 'escalation' : ''}`}
                      dangerouslySetInnerHTML={{ __html: renderMarkdown(m.content) }}
                    />
                  ) : (
                    <div className={`bubble ${m.role}`}>{m.content}</div>
                  )}
                  {m.time && <div className="msg-time">{formatTime(m.time)}</div>}
                  {m.sources && m.sources.length > 0 && (
                    <div className="sources">
                      Learn more:
                      {m.sources.map((s) => (
                        <a key={s.url} href={s.url} target="_blank" rel="noopener noreferrer">
                          {s.title}
                        </a>
                      ))}
                    </div>
                  )}
                  {m.buttons && (
                    <div className="quick-replies">
                      {m.buttons.map((b) => (
                        <button key={b.value} onClick={() => handleButton(b.value)}>
                          {b.label}
                        </button>
                      ))}
                    </div>
                  )}
                  {m.schoolSelect && (
                    <div className="school-select-row">
                      <select value={schoolChoice} onChange={(e) => setSchoolChoice(e.target.value)}>
                        <option value="" disabled>
                          Choose your school...
                        </option>
                        {schools.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name}
                          </option>
                        ))}
                      </select>
                      <button onClick={() => schoolChoice && handleSchoolAnswer(schoolChoice)} disabled={!schoolChoice}>
                        Continue
                      </button>
                    </div>
                  )}
                  {m.suggestCardUpload && (
                    <div className="quick-replies">
                      <button onClick={() => fileInputRef.current?.click()}>📎 Upload your ID card (photo or PDF)</button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {sending && !streaming && (
              <div className="bubble-row assistant">
                <div className="avatar">♥</div>
                <div className="bubble assistant typing">...</div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="chat-input-row">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,application/pdf"
              hidden
              onChange={handleCardUpload}
            />
            <button
              type="button"
              className="upload-btn"
              title="Upload your insurance ID card (photo or PDF)"
              aria-label="Upload your insurance ID card (photo or PDF)"
              onClick={() => fileInputRef.current?.click()}
              disabled={sending}
            >
              📎
            </button>
            <input
              ref={inputRef}
              type="text"
              placeholder="Ask about your plan, benefits, or coverage..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={sending}
            />
            <button onClick={sendMessage} disabled={sending}>
              Send
            </button>
          </div>
        </div>
      )}

      <button
        className="chat-launcher"
        aria-label={chatOpen ? 'Close chat' : 'Open chat'}
        onClick={() => setChatOpen((open) => !open)}
      >
        {chatOpen ? '✕' : '💬'}
      </button>
    </div>
  )
}
