import react from '@vitejs/plugin-react'
import { defineConfig, searchForWorkspaceRoot } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    fs: {
      // The waiver rules live in ../widget/waiver-rules.js so the widget and
      // this app share one copy. Allow just that folder, not the whole repo.
      allow: [searchForWorkspaceRoot(process.cwd()), '../widget'],
    },
  },
})
