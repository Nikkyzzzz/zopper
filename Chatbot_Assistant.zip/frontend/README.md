# Aetna Student Health — React Frontend

A standalone React (Vite) page that mirrors the embeddable widget's own UX —
same pink hero landing section as `widget/demo.html`, plus a floating chat
button that opens the chat as an overlay panel. Useful for a shareable
full-page preview instead of embedding the widget script into an existing
page. See the [root README](../README.md) for the full project (backend,
widget, knowledge base).

## Setup

```bash
npm install
npm run dev
```

Opens at `http://localhost:5173` (or the next free port). Requires the
backend running first (see the root README) — copy `.env.example` to `.env`
if it's not on the default `http://localhost:8731`:

```
VITE_API_URL=http://localhost:8731/api/chat
```

The other endpoints the app calls (`/api/schools`, `/api/extract-card`) are
derived from this same base URL, so you only need to set the one variable.

## What's in `src/App.jsx`

- **Hero landing** — pink section with the real scraped homepage copy.
- **Floating chat panel** — toggled by the 💬 button, talks to `POST /api/chat`.
- **Waiver-eligibility walkthrough** — a deterministic, rule-based demo flow
  (not left to the LLM): Yes/No insurance gate → pick your school from a
  dropdown (fetched live from `GET /api/schools`) → visa type → a dynamically
  built question queue matching that specific school's requirements
  (deductible, coinsurance, ACA-compliance, evacuation/repatriation,
  visa-specific minimums, etc.) → a pass/fail result citing real sources.
  Only `ut-austin` and `ut-dallas` reflect real, verified school policies —
  the rest are clearly-labeled fictional demo schools.
- **ID card upload** — the 📎 button (always visible, plus a suggestion
  button that appears under any reply about your member ID, group number,
  etc.) uploads a photo to `POST /api/extract-card`, which reads it with the
  LLM's vision support and returns structured fields. Nothing is persisted.

## Building

```bash
npm run build
```

Outputs to `dist/` (git-ignored) — a static build you can serve from
anywhere, pointed at a deployed backend via `VITE_API_URL`.
